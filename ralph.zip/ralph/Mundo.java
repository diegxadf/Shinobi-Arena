import greenfoot.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Escenario del juego: ahora el jugador es RALPH.
 *
 * Objetivo de Ralph (dos rutas de victoria):
 *   - COLAPSO: llevar la barra de DANO al 100% rompiendo ventanas y, sobre todo,
 *     las vigas (puntos estructurales), cuyo dano es permanente.
 *   - CIMA: con el edificio ya danado (UMBRAL_CIMA), subir a la azotea y derribar
 *     el letrero para llevarse el pastel de la victoria.
 *
 * Derrotas:
 *   - Felix llena su barra de REPARACION: el edificio queda blindado y Ralph
 *     es arrojado al lodo.
 *   - La ENERGIA de Ralph llega a cero por los ladrillos de los vecinos, los
 *     martillazos de Felix o el desgaste del tiempo: cae del edificio.
 *
 * El mundo concentra la geometria y el estado global; los actores solo consultan
 * lo que necesitan (mantenibilidad).
 */
public class Mundo extends World
{
    // ---------- Geometria del escenario ----------
    public static final int ANCHO = 800;
    public static final int ALTO  = 500;

    public static final int EDIFICIO_X1 = 130;
    public static final int EDIFICIO_X2 = 670;

    /** Coordenada y de la superficie de cada piso (indice 0 = piso inferior). */
    public static final int[] SUPERFICIE_PISO = { 452, 364, 276, 188 };
    /** Superficie de la azotea (cara superior de la losa). */
    public static final int SUPERFICIE_TECHO = 88;
    public static final int LOSA_ALTO = 12;
    /** Centro x de cada columna de ventanas. */
    public static final int[] COLUMNA_X = { 184, 292, 400, 508, 616 };
    /** Centro x de la viga de cada piso (en los huecos entre ventanas). */
    public static final int[] VIGA_X = { 238, 346, 454, 562 };
    /** Altura del charco de lodo. */
    public static final int NIVEL_LODO = 470;

    public static final int PISOS       = SUPERFICIE_PISO.length;
    public static final int COLUMNAS    = COLUMNA_X.length;
    public static final int PISO_AZOTEA = PISOS;          // la azotea es un piso mas

    // ---------- Reglas ----------
    public static final int DANIO_VENTANA     = 4;    // reparable por Felix
    public static final int DANIO_VIGA        = 15;   // permanente
    public static final int DANIO_META        = 100;
    public static final int UMBRAL_CIMA       = 60;   // dano que desbloquea el letrero
    /**
     * Ciclos que Felix necesita, sin que Ralph destroce nada, para blindar.
     *
     * Contar reparaciones sueltas no servia: cada ventana rota acaba siendo una
     * reparacion, asi que destruir acercaba al jugador a su propia derrota.
     * Tampoco basta con exigir el edificio entero, porque entonces atacar vigas
     * (que Felix no puede reparar) dejaba subir la barra igualmente.
     *
     * La regla final es la que se entiende sola: la barra avanza mientras no
     * quede ninguna ventana rota, y CUALQUIER destrozo de Ralph la pone a cero.
     * O sea: solo pierdes por aqui si dejas de demoler unos diez segundos.
     */
    public static final int CICLOS_BLINDAJE = 600;

    private static final int VENTANAS_ROTAS_INICIALES = 2;
    private static final int INTERVALO_VECINOS_BASE   = 130;
    private static final int INTERVALO_VECINOS_MINIMO = 55;

    // ---------- Estado de la partida ----------
    private Ventana[][] ventanas = new Ventana[PISOS][COLUMNAS];
    private Ralph ralph;
    private Felix felix;
    private Hud hud;

    private int danioPermanente = 0;
    private int reparaciones = 0;      // total, solo para las estadisticas finales
    private int blindaje = 0;          // ciclos seguidos con el edificio entero
    private int destrozos = 0;
    private int tiempo = 0;
    private int contadorVecinos = 0;

    private boolean cimaAvisada = false;  // el aviso sonoro de la cima suena una vez
    private boolean terminando = false;   // Ralph esta cayendo al lodo
    private boolean terminado  = false;
    private boolean victoria   = false;
    private String resultado   = "";

    public Mundo()
    {
        super(ANCHO, ALTO, 1);
        setPaintOrder(Hud.class, Proyectil.class, Ralph.class, Felix.class,
                      Letrero.class, Viga.class, Ventana.class, Plataforma.class);
        dibujarFondo();
        prepararMundo();
    }

    // ------------------------------------------------------------------
    // Construccion del escenario
    // ------------------------------------------------------------------

    private void prepararMundo()
    {
        crearPlataformas();
        crearVentanas();
        crearVigas();

        addObject(new Letrero(), (EDIFICIO_X1 + EDIFICIO_X2) / 2,
                  SUPERFICIE_TECHO - Letrero.ALTO / 2 - 2);

        ralph = new Ralph();
        addObject(ralph, COLUMNA_X[0], SUPERFICIE_PISO[0] - Ralph.ALTO / 2);
        ralph.colocarEnPiso(0);

        felix = new Felix();
        addObject(felix, COLUMNA_X[4], SUPERFICIE_PISO[1] - Felix.ALTO / 2);
        felix.colocarEnPiso(1);

        hud = new Hud();
        addObject(hud, ANCHO / 2, ALTO / 2);

        romperVentanasIniciales(VENTANAS_ROTAS_INICIALES);
    }

    private void crearPlataformas()
    {
        int ancho = EDIFICIO_X2 - EDIFICIO_X1;

        for (int piso = 0; piso < PISOS; piso++)
        {
            Plataforma p = new Plataforma(ancho, piso);
            addObject(p, (EDIFICIO_X1 + EDIFICIO_X2) / 2,
                      SUPERFICIE_PISO[piso] + Plataforma.ALTO / 2);
        }

        // La azotea tambien es una plataforma: solo Ralph puede subir.
        Plataforma azotea = new Plataforma(ancho + 28, PISO_AZOTEA);
        addObject(azotea, (EDIFICIO_X1 + EDIFICIO_X2) / 2,
                  SUPERFICIE_TECHO + Plataforma.ALTO / 2);
    }

    private void crearVentanas()
    {
        for (int piso = 0; piso < PISOS; piso++)
        {
            for (int col = 0; col < COLUMNAS; col++)
            {
                Ventana v = new Ventana(piso, col);
                ventanas[piso][col] = v;
                addObject(v, COLUMNA_X[col], SUPERFICIE_PISO[piso] - 34);
            }
        }
    }

    private void crearVigas()
    {
        for (int piso = 0; piso < PISOS; piso++)
        {
            addObject(new Viga(piso), VIGA_X[piso],
                      SUPERFICIE_PISO[piso] - Viga.ALTO / 2);
        }
    }

    private void romperVentanasIniciales(int cantidad)
    {
        for (int i = 0; i < cantidad; i++)
        {
            Ventana v = ventanaIntactaAleatoria();
            if (v != null)
            {
                v.romper();
            }
        }
    }

    private void dibujarFondo()
    {
        GreenfootImage fondo = getBackground();

        // Cielo nocturno.
        fondo.setColor(new Color(24, 26, 58));
        fondo.fillRect(0, 0, ANCHO, ALTO);

        fondo.setColor(new Color(200, 200, 230));
        for (int x = 20; x < ANCHO; x += 67)
        {
            fondo.fillRect(x, 44 + (x % 40), 2, 2);
        }

        // Calle.
        fondo.setColor(new Color(60, 60, 70));
        fondo.fillRect(0, 460, ANCHO, ALTO - 460);

        dibujarCharco(fondo);

        // Fachada, en el tono de piedra clara de las hojas de sprites.
        int techoFachada = SUPERFICIE_TECHO + LOSA_ALTO;
        fondo.setColor(new Color(255, 220, 170));
        fondo.fillRect(EDIFICIO_X1, techoFachada, EDIFICIO_X2 - EDIFICIO_X1,
                       460 - techoFachada);
        fondo.setColor(new Color(196, 148, 96));
        fondo.drawRect(EDIFICIO_X1, techoFachada, EDIFICIO_X2 - EDIFICIO_X1 - 1,
                       460 - techoFachada - 1);

        // Losa de la azotea.
        fondo.setColor(new Color(205, 145, 95));
        fondo.fillRect(EDIFICIO_X1 - 14, SUPERFICIE_TECHO,
                       EDIFICIO_X2 - EDIFICIO_X1 + 28, LOSA_ALTO);

        // Banda superior para las barras del HUD.
        fondo.setColor(new Color(12, 12, 30));
        fondo.fillRect(0, 0, ANCHO, 32);
    }

    /**
     * Charco de lodo: no es un rectangulo liso, sino la textura de tierra
     * recortada de la hoja, con el cartel del vertedero clavado a un lado.
     */
    private void dibujarCharco(GreenfootImage fondo)
    {
        int ancho = EDIFICIO_X2 - EDIFICIO_X1 + 120;
        int alto = ALTO - NIVEL_LODO;

        GreenfootImage lodo = Recursos.cargar("lodo.png",
                              Recursos.bloque(ancho, alto, new Color(78, 52, 26),
                                                           new Color(60, 40, 20)));
        fondo.drawImage(lodo, EDIFICIO_X1 - 60, NIVEL_LODO);

        GreenfootImage cartel = Recursos.cargar("cartel_lodo.png",
                                Recursos.bloque(1, 1, new Color(0, 0, 0, 0),
                                                      new Color(0, 0, 0, 0)));
        if (cartel.getWidth() > 1)
        {
            fondo.drawImage(cartel, EDIFICIO_X1 - 50, NIVEL_LODO - cartel.getHeight() + 10);
        }
    }

    // ------------------------------------------------------------------
    // Ciclo principal del mundo
    // ------------------------------------------------------------------

    public void act()
    {
        if (!estaActivo())
        {
            return;
        }

        tiempo++;
        Sonidos.avanzarCiclo();
        Sonidos.atenderTeclaSilencio();
        avisarDeLaCima();
        actualizarBlindaje();
        atenderVecinos();
        comprobarColapso();
    }

    /** Cuando el dano abre la ruta de la cima, suena una vez para avisar. */
    private void avisarDeLaCima()
    {
        if (!cimaAvisada && cimaDesbloqueada())
        {
            cimaAvisada = true;
            Sonidos.reproducir("cima.wav");
        }
    }

    /** Los vecinos lanzan objetos cada vez mas seguido segun crece el dano. */
    private void atenderVecinos()
    {
        contadorVecinos++;

        if (contadorVecinos < intervaloVecinos())
        {
            return;
        }
        contadorVecinos = 0;

        Ventana origen = ventanaParaLanzar();
        if (origen == null)
        {
            return;
        }

        Actor proyectil = Greenfoot.getRandomNumber(10) < 7 ? new Ladrillo()
                                                            : new Pastel();
        addObject(proyectil, origen.getX(), origen.getY() + 34);
    }

    private int intervaloVecinos()
    {
        return Math.max(INTERVALO_VECINOS_MINIMO, INTERVALO_VECINOS_BASE - getDanio());
    }

    /** Prefiere una ventana sana por encima de Ralph, para que el objeto le caiga. */
    private Ventana ventanaParaLanzar()
    {
        List<Ventana> arriba = new ArrayList<Ventana>();
        List<Ventana> otras  = new ArrayList<Ventana>();

        for (int piso = 0; piso < PISOS; piso++)
        {
            for (int col = 0; col < COLUMNAS; col++)
            {
                Ventana v = ventanas[piso][col];
                if (v.estaRota())
                {
                    continue;
                }
                if (ralph != null && piso > ralph.getPiso())
                {
                    arriba.add(v);
                }
                else
                {
                    otras.add(v);
                }
            }
        }

        List<Ventana> candidatas = !arriba.isEmpty() ? arriba : otras;
        if (candidatas.isEmpty())
        {
            return null;
        }
        return candidatas.get(Greenfoot.getRandomNumber(candidatas.size()));
    }

    private void comprobarColapso()
    {
        if (getDanio() >= DANIO_META)
        {
            victoria("El edificio colapso: dano estructural del 100%");
        }
    }

    // ------------------------------------------------------------------
    // Barras de progreso
    // ------------------------------------------------------------------

    /** Dano del edificio: el de las vigas es permanente, el de las ventanas no. */
    public int getDanio()
    {
        int total = danioPermanente + DANIO_VENTANA * ventanasRotas();
        return Math.min(DANIO_META, total);
    }

    /**
     * Lo cerca que esta Felix de blindar el edificio, en porcentaje.
     *
     * Sube mientras no queda ninguna ventana rota y baja deprisa en cuanto Ralph
     * rompe algo: es una pugna, no un contador de reparaciones.
     */
    public int getReparacion()
    {
        return Math.min(100, blindaje * 100 / CICLOS_BLINDAJE);
    }

    public boolean cimaDesbloqueada()
    {
        return getDanio() >= UMBRAL_CIMA;
    }

    // ------------------------------------------------------------------
    // Avisos de los actores
    // ------------------------------------------------------------------

    /** Ralph rompio algo reparable (ventana o golpe parcial a una viga). */
    public void registrarDestrozo()
    {
        destrozos++;
        blindaje = 0;      // mientras Ralph destroce, Felix no consolida nada
    }

    public void registrarVigaDestruida()
    {
        destrozos++;
        danioPermanente += DANIO_VIGA;
        comprobarColapso();
    }

    public void registrarReparacion()
    {
        reparaciones++;
    }

    /** Felix gana si mantiene las veinte ventanas sanas el tiempo suficiente. */
    private void actualizarBlindaje()
    {
        if (ventanasRotas() > 0)
        {
            blindaje = Math.max(0, blindaje - 6);   // Ralph recupera terreno rapido
            return;
        }

        blindaje++;
        if (blindaje >= CICLOS_BLINDAJE)
        {
            derrota("Felix blindo el edificio y arrojo a Ralph al lodo");
        }
    }

    // ------------------------------------------------------------------
    // Final de la partida
    // ------------------------------------------------------------------

    public void victoria(String motivo)
    {
        if (!estaActivo())
        {
            return;
        }
        terminando = true;
        victoria = true;
        resultado = motivo;
        Sonidos.reproducir("victoria.wav");
        confirmarFinal();
    }

    /** La derrota no es inmediata: primero se ve caer a Ralph al lodo. */
    public void derrota(String motivo)
    {
        if (!estaActivo())
        {
            return;
        }
        terminando = true;
        victoria = false;
        resultado = motivo;

        if (ralph != null)
        {
            ralph.arrojarAlLodo();
        }
        else
        {
            confirmarFinal();
        }
    }

    /** Cierra la partida; lo llama Ralph al tocar el lodo. */
    public void confirmarFinal()
    {
        terminado = true;

        if (!victoria)
        {
            Sonidos.reproducir("derrota.wav");
        }

        if (hud != null)
        {
            hud.refrescar();   // el mensaje final debe verse antes de detenerse
        }
        Greenfoot.stop();
    }

    // ------------------------------------------------------------------
    // Consultas
    // ------------------------------------------------------------------

    public Ventana ventanaEn(int piso, int columna)
    {
        if (piso < 0 || piso >= PISOS || columna < 0 || columna >= COLUMNAS)
        {
            return null;
        }
        return ventanas[piso][columna];
    }

    public int ventanasRotas()
    {
        int total = 0;
        for (int piso = 0; piso < PISOS; piso++)
        {
            for (int col = 0; col < COLUMNAS; col++)
            {
                if (ventanas[piso][col].estaRota())
                {
                    total++;
                }
            }
        }
        return total;
    }

    public Ventana ventanaIntactaAleatoria()
    {
        ArrayList<Ventana> sanas = new ArrayList<Ventana>();

        for (int piso = 0; piso < PISOS; piso++)
        {
            for (int col = 0; col < COLUMNAS; col++)
            {
                if (!ventanas[piso][col].estaRota())
                {
                    sanas.add(ventanas[piso][col]);
                }
            }
        }
        if (sanas.isEmpty())
        {
            return null;
        }
        return sanas.get(Greenfoot.getRandomNumber(sanas.size()));
    }

    public int vigasDestruidas()
    {
        int total = 0;
        for (Viga viga : getObjects(Viga.class))
        {
            if (viga.estaDestruida())
            {
                total++;
            }
        }
        return total;
    }

    /** La partida sigue en marcha (ni terminada ni en la caida final). */
    public boolean estaActivo()   { return !terminado && !terminando; }
    public boolean estaTerminado(){ return terminado; }
    public boolean hayVictoria()  { return victoria; }
    public String  getResultado() { return resultado; }
    public int getTiempo()        { return tiempo; }
    public int getDestrozos()     { return destrozos; }
    public int getReparaciones()  { return reparaciones; }
    public Ralph getRalph()       { return ralph; }
    public Felix getFelix()       { return felix; }
}
