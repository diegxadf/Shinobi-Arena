import greenfoot.*;

/**
 * Ventana del edificio. Es el objeto sobre el que gira todo el juego:
 * Ralph la rompe y Felix la repara.
 *
 * Tiene un estado logico (rota / intacta) asociado siempre a una imagen,
 * de modo que lo que se ve coincide con lo que el programa sabe (consistencia).
 */
public class Ventana extends Actor
{
    // Medidas del recorte de la hoja (marco + cristal + alfeizar, al doble).
    public static final int ANCHO = 48;
    public static final int ALTO  = 50;

    private enum Estado
    {
        INTACTA,
        ROTA
    }

    private Estado estado = Estado.INTACTA;
    private final int piso;
    private final int columna;

    private GreenfootImage imagenIntacta;
    private GreenfootImage imagenRota;

    public Ventana(int piso, int columna)
    {
        this.piso = piso;
        this.columna = columna;
        cargarImagenes();
        actualizarImagen();
    }

    private void cargarImagenes()
    {
        imagenIntacta = Recursos.cargar("ventana_intacta.png", dibujarIntacta());
        imagenRota    = Recursos.cargar("ventana_rota.png", dibujarRota());
    }

    private GreenfootImage dibujarIntacta()
    {
        GreenfootImage img = Recursos.bloque(ANCHO, ALTO, new Color(130, 205, 235),
                                                          new Color(230, 230, 240));
        img.setColor(new Color(230, 230, 240));
        img.fillRect(ANCHO / 2 - 2, 0, 4, ALTO);       // marco vertical
        img.fillRect(0, ALTO / 2 - 2, ANCHO, 4);       // marco horizontal
        return img;
    }

    private GreenfootImage dibujarRota()
    {
        GreenfootImage img = Recursos.bloque(ANCHO, ALTO, new Color(35, 30, 45),
                                                          new Color(160, 150, 120));
        img.setColor(new Color(120, 200, 230));
        img.drawLine(4, 4, ANCHO - 8, ALTO - 6);       // grietas
        img.drawLine(ANCHO - 6, 6, 8, ALTO - 4);
        img.drawLine(ANCHO / 2, 2, ANCHO / 3, ALTO - 2);
        return img;
    }

    private void actualizarImagen()
    {
        setImage(estado == Estado.ROTA ? imagenRota : imagenIntacta);
    }

    /** Ralph rompe la ventana. Devuelve false si ya estaba rota. */
    public boolean romper()
    {
        if (estado == Estado.ROTA)
        {
            return false;
        }
        estado = Estado.ROTA;
        actualizarImagen();
        return true;
    }

    /** Felix termina de martillar. Devuelve false si no habia nada que reparar. */
    public boolean reparar()
    {
        if (estado == Estado.INTACTA)
        {
            return false;
        }
        estado = Estado.INTACTA;
        actualizarImagen();
        return true;
    }

    public boolean estaRota()
    {
        return estado == Estado.ROTA;
    }

    public int getPiso()
    {
        return piso;
    }

    public int getColumna()
    {
        return columna;
    }
}
