import greenfoot.*;

/**
 * Felix: ahora lo controla la computadora.
 *
 * Su IA es una maquina de estados sencilla con dos prioridades:
 *   1. si Ralph esta cerca en su mismo piso, lo persigue para darle un martillazo
 *      (lo congela y le quita energia);
 *   2. si no, busca la ventana rota mas cercana, camina o salta hasta ella y la
 *      repara, llenando la barra de REPARACION.
 *
 * Usa la misma fisica que Ralph porque las dos clases heredan de Personaje.
 */
public class Felix extends Personaje
{
    // Tamano del lienzo de los sprites recortados de la hoja del arcade.
    public static final int ANCHO = 20;
    public static final int ALTO  = 37;

    private static final int    VELOCIDAD_HORIZONTAL = 3;
    private static final int    VELOCIDAD_PERSECUCION = 4;
    private static final double VELOCIDAD_INICIAL     = 13.5;  // v0
    private static final double GRAVEDAD              = 1.0;   // g
    private static final int    CICLOS_POR_FRAME      = 6;

    private static final int DISTANCIA_PERSECUCION = 170;
    private static final int ALCANCE_REPARACION    = 40;
    private static final int DURACION_REPARACION   = 22;
    private static final int DANIO_MARTILLAZO      = 10;
    private static final int ESPERA_MARTILLAZO     = 90;

    private enum Estado
    {
        QUIETO,
        CAMINANDO_DERECHA,
        CAMINANDO_IZQUIERDA,
        SALTANDO,
        CAYENDO,
        REPARANDO,
        PERSIGUIENDO
    }

    private Estado estado = Estado.QUIETO;
    private boolean mirandoIzquierda = false;

    // ---------- Imagenes ----------
    private GreenfootImage quietoDer, quietoIzq;
    private GreenfootImage[] caminarDer, caminarIzq;
    private GreenfootImage saltoDer, saltoIzq;
    private GreenfootImage caidaDer, caidaIzq;
    private GreenfootImage[] martilloDer, martilloIzq;

    private int frameActual = 0;
    private int contadorAnimacion = 0;

    // ---------- IA ----------
    private Ventana ventanaObjetivo;
    private int contadorReparacion = 0;
    private int esperaMartillazo = 0;

    public Felix()
    {
        super(ANCHO, ALTO, VELOCIDAD_INICIAL, GRAVEDAD);
        cargarImagenes();
    }

    // ------------------------------------------------------------------
    // Imagenes
    // ------------------------------------------------------------------

    private void cargarImagenes()
    {
        quietoDer = Recursos.cargar("felix_idle.png", cuerpo(0));

        caminarDer = new GreenfootImage[4];
        caminarDer[0] = Recursos.cargar("felix_walk1.png", cuerpo(0));
        caminarDer[1] = Recursos.cargar("felix_walk2.png", cuerpo(1));
        caminarDer[2] = Recursos.cargar("felix_walk3.png", cuerpo(0));
        caminarDer[3] = Recursos.cargar("felix_walk4.png", cuerpo(1));

        saltoDer = Recursos.cargar("felix_jump.png", cuerpo(1));
        caidaDer = Recursos.cargar("felix_fall.png", cuerpo(0));

        martilloDer = new GreenfootImage[2];
        martilloDer[0] = Recursos.cargar("felix_fix1.png", conMartillo(0));
        martilloDer[1] = Recursos.cargar("felix_fix2.png", conMartillo(1));

        quietoIzq   = espejo(quietoDer);
        saltoIzq    = espejo(saltoDer);
        caidaIzq    = espejo(caidaDer);
        caminarIzq  = espejo(caminarDer);
        martilloIzq = espejo(martilloDer);

        setImage(quietoDer);
    }

    private GreenfootImage cuerpo(int fase)
    {
        return Recursos.personaje(ANCHO, ALTO, new Color(60, 110, 200),
                                               new Color(240, 200, 170), fase);
    }

    private GreenfootImage conMartillo(int fase)
    {
        GreenfootImage img = cuerpo(fase);
        img.setColor(new Color(210, 180, 60));

        if (fase == 0)
        {
            img.fillRect(ANCHO - 8, 6, 8, 5);
        }
        else
        {
            img.fillRect(ANCHO - 8, ALTO / 2, 8, 5);
        }
        return img;
    }

    private GreenfootImage espejo(GreenfootImage original)
    {
        GreenfootImage copia = new GreenfootImage(original);
        copia.mirrorHorizontally();
        return copia;
    }

    private GreenfootImage[] espejo(GreenfootImage[] originales)
    {
        GreenfootImage[] copias = new GreenfootImage[originales.length];
        for (int i = 0; i < originales.length; i++)
        {
            copias[i] = espejo(originales[i]);
        }
        return copias;
    }

    // ------------------------------------------------------------------
    // Ciclo principal
    // ------------------------------------------------------------------

    public void act()
    {
        Mundo mundo = getMundo();
        if (mundo == null || !mundo.estaActivo())
        {
            return;   // durante la caida final de Ralph, Felix ya no trabaja
        }

        actualizarTemporizadores();

        if (estado != Estado.REPARANDO)
        {
            decidirQueHacer();
        }

        actualizarVertical();
        actualizarAnimacion();
    }

    private void actualizarTemporizadores()
    {
        if (esperaMartillazo > 0)
        {
            esperaMartillazo--;
        }

        if (estado == Estado.REPARANDO)
        {
            contadorReparacion--;
            if (contadorReparacion <= 0)
            {
                terminarReparacion();
            }
        }
    }

    // ------------------------------------------------------------------
    // Inteligencia artificial
    // ------------------------------------------------------------------

    private void decidirQueHacer()
    {
        Ralph ralph = getMundo().getRalph();

        if (debePerseguir(ralph))
        {
            perseguir(ralph);
            return;
        }

        ventanaObjetivo = buscarVentanaRota();

        if (ventanaObjetivo == null)
        {
            if (!estaEnAire())
            {
                estado = Estado.QUIETO;
            }
            return;
        }

        irHacia(ventanaObjetivo);
    }

    private boolean debePerseguir(Ralph ralph)
    {
        return ralph != null
               && !estaEnAire()
               && ralph.getPiso() == pisoActual
               && Math.abs(ralph.getX() - getX()) <= DISTANCIA_PERSECUCION;
    }

    private void perseguir(Ralph ralph)
    {
        estado = Estado.PERSIGUIENDO;
        caminarHacia(ralph.getX(), VELOCIDAD_PERSECUCION);

        if (esperaMartillazo <= 0 && intersects(ralph))
        {
            ralph.recibirMartillazo(DANIO_MARTILLAZO);
            esperaMartillazo = ESPERA_MARTILLAZO;
        }
    }

    /** Ventana rota mas conveniente: primero las del piso actual. */
    private Ventana buscarVentanaRota()
    {
        Mundo mundo = getMundo();
        Ventana mejor = null;
        int mejorCosto = Integer.MAX_VALUE;

        for (Ventana v : mundo.getObjects(Ventana.class))
        {
            if (!v.estaRota())
            {
                continue;
            }

            // Cambiar de piso cuesta mucho mas que caminar.
            int costo = Math.abs(v.getPiso() - pisoActual) * 400
                        + Math.abs(v.getX() - getX());

            if (costo < mejorCosto)
            {
                mejorCosto = costo;
                mejor = v;
            }
        }
        return mejor;
    }

    private void irHacia(Ventana objetivo)
    {
        if (objetivo.getPiso() > pisoActual)
        {
            estado = Estado.SALTANDO;
            caminarHacia(objetivo.getX(), VELOCIDAD_HORIZONTAL);
            iniciarSalto();
            return;
        }

        if (objetivo.getPiso() < pisoActual)
        {
            caminarHacia(objetivo.getX(), VELOCIDAD_HORIZONTAL);
            iniciarCaida();
            return;
        }

        if (Math.abs(objetivo.getX() - getX()) <= ALCANCE_REPARACION && !estaEnAire())
        {
            iniciarReparacion(objetivo);
        }
        else
        {
            caminarHacia(objetivo.getX(), VELOCIDAD_HORIZONTAL);
        }
    }

    private void caminarHacia(int destinoX, int velocidad)
    {
        int diferencia = destinoX - getX();

        if (Math.abs(diferencia) <= velocidad)
        {
            if (!estaEnAire() && estado != Estado.PERSIGUIENDO)
            {
                estado = Estado.QUIETO;
            }
            return;
        }

        int paso = diferencia > 0 ? velocidad : -velocidad;
        moverHorizontal(paso);
        mirandoIzquierda = paso < 0;

        if (!estaEnAire() && estado != Estado.PERSIGUIENDO)
        {
            estado = paso > 0 ? Estado.CAMINANDO_DERECHA : Estado.CAMINANDO_IZQUIERDA;
        }
    }

    // ------------------------------------------------------------------
    // Reparacion
    // ------------------------------------------------------------------

    private void iniciarReparacion(Ventana objetivo)
    {
        ventanaObjetivo = objetivo;
        contadorReparacion = DURACION_REPARACION;
        estado = Estado.REPARANDO;
        frameActual = 0;
        contadorAnimacion = 0;
    }

    private void terminarReparacion()
    {
        if (ventanaObjetivo != null && ventanaObjetivo.reparar())
        {
            Sonidos.reproducir("reparar.wav");
            getMundo().registrarReparacion();
        }
        ventanaObjetivo = null;
        estado = Estado.QUIETO;
    }

    /** Felix nunca sube a la azotea: ese terreno es solo de Ralph. */
    protected boolean puedeApoyarseEn(Plataforma p)
    {
        return p.getPiso() != Mundo.PISO_AZOTEA;
    }

    // ------------------------------------------------------------------
    // Avisos de la fisica (clase Personaje)
    // ------------------------------------------------------------------

    protected void alSubir()
    {
        estado = Estado.SALTANDO;
    }

    protected void alCaer()
    {
        estado = Estado.CAYENDO;
    }

    protected void alAterrizar()
    {
        if (estado == Estado.SALTANDO || estado == Estado.CAYENDO)
        {
            estado = Estado.QUIETO;
        }
    }

    // ------------------------------------------------------------------
    // Representacion visual: Estado -> Sprite
    // ------------------------------------------------------------------

    private void actualizarAnimacion()
    {
        switch (estado)
        {
            case QUIETO:
                setImage(mirandoIzquierda ? quietoIzq : quietoDer);
                break;
            case CAMINANDO_DERECHA:
                animarCaminata(false);
                break;
            case CAMINANDO_IZQUIERDA:
                animarCaminata(true);
                break;
            case PERSIGUIENDO:
                animarCaminata(mirandoIzquierda);
                break;
            case SALTANDO:
                setImage(mirandoIzquierda ? saltoIzq : saltoDer);
                break;
            case CAYENDO:
                setImage(mirandoIzquierda ? caidaIzq : caidaDer);
                break;
            case REPARANDO:
                animarMartillo();
                break;
        }
    }

    private void animarCaminata(boolean izquierda)
    {
        contadorAnimacion++;

        if (contadorAnimacion >= CICLOS_POR_FRAME)
        {
            frameActual++;
            if (frameActual >= caminarDer.length)
            {
                frameActual = 0;
            }
            contadorAnimacion = 0;
        }

        setImage(izquierda ? caminarIzq[frameActual] : caminarDer[frameActual]);
    }

    private void animarMartillo()
    {
        contadorAnimacion++;

        if (contadorAnimacion >= 5)
        {
            frameActual = (frameActual + 1) % martilloDer.length;
            contadorAnimacion = 0;
        }

        setImage(mirandoIzquierda ? martilloIzq[frameActual] : martilloDer[frameActual]);
    }
}
