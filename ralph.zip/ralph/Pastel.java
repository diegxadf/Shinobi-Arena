import greenfoot.*;

/**
 * Pastel lanzado por los vecinos: no quita energia, pero deja a Ralph
 * ralentizado y sin poder golpear durante unos segundos.
 */
public class Pastel extends Proyectil
{
    public static final int ANCHO = 16;
    public static final int ALTO  = 16;

    public Pastel()
    {
        super(3.0, 0.5, -6);
        setImage(Recursos.cargar("pastel.png", dibujarPastel()));
    }

    private static GreenfootImage dibujarPastel()
    {
        GreenfootImage img = new GreenfootImage(ANCHO, ALTO);

        img.setColor(new Color(250, 245, 225));
        img.fillOval(0, 0, ANCHO, ALTO);
        img.setColor(new Color(225, 120, 150));
        img.fillOval(ANCHO / 4, ALTO / 4, ANCHO / 2, ALTO / 2);
        img.setColor(new Color(150, 100, 60));
        img.drawOval(0, 0, ANCHO - 1, ALTO - 1);

        return img;
    }

    protected void efecto(Ralph ralph)
    {
        ralph.recibirPastel();
    }
}
