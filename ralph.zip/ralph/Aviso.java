import greenfoot.*;

/**
 * Numero flotante que aparece sobre Ralph cuando pierde energia.
 *
 * Sin esto, el jugador ve bajar la barra sin entender por que: el ladrillo cae
 * muy rapido y el martillazo dura un instante. El aviso sube unos pixeles, se
 * desvanece y desaparece solo.
 */
public class Aviso extends Actor
{
    private static final int DURACION = 45;

    private final GreenfootImage original;
    private int vida = DURACION;

    public Aviso(String texto, Color color)
    {
        original = new GreenfootImage(texto, 18, color, new Color(0, 0, 0, 0),
                                      new Color(0, 0, 0, 180));
        setImage(new GreenfootImage(original));
    }

    public void act()
    {
        vida--;

        if (vida <= 0)
        {
            getWorld().removeObject(this);
            return;
        }

        setLocation(getX(), getY() - 1);

        // Se desvanece en la ultima mitad de su vida.
        GreenfootImage copia = new GreenfootImage(original);
        copia.setTransparency(Math.min(255, 255 * vida * 2 / DURACION));
        setImage(copia);
    }
}
