import greenfoot.*;

/**
 * Capa de informacion: las tres barras de la partida (DANO, REPARACION y
 * ENERGIA), los avisos de estado y el mensaje final.
 *
 * Se dibuja como un actor transparente del tamano del mundo, encima de todo.
 * Separar el HUD del resto evita que los actores mezclen su logica con la
 * presentacion de datos.
 */
public class Hud extends Actor
{
    private static final Font FUENTE        = new Font("Monospaced", true, false, 13);
    private static final Font FUENTE_AVISO  = new Font("Monospaced", true, false, 14);
    private static final Font FUENTE_GRANDE = new Font("Monospaced", true, false, 34);

    private static final int BARRA_ANCHO = 120;
    private static final int BARRA_ALTO  = 12;

    private String ultimaFirma = "";

    public Hud()
    {
        setImage(new GreenfootImage(Mundo.ANCHO, Mundo.ALTO));
    }

    public void act()
    {
        refrescar();
    }

    protected void addedToWorld(World mundo)
    {
        refrescar();
    }

    /**
     * Redibuja el marcador. Es publico porque el mundo lo invoca al terminar la
     * partida: asi el mensaje final alcanza a dibujarse antes de detenerse.
     */
    public void refrescar()
    {
        Mundo mundo = (Mundo) getWorld();
        if (mundo == null)
        {
            return;
        }

        Ralph ralph = mundo.getRalph();
        int energia = ralph == null ? 0 : ralph.getSalud();

        // Solo se redibuja cuando cambia algo (rendimiento).
        String firma = mundo.getDanio() + "/" + mundo.getReparacion() + "/" + energia
                       + "/" + (mundo.getTiempo() / 60) + "/" + mundo.estaTerminado()
                       + "/" + mundo.estaActivo()
                       + "/" + (ralph != null && ralph.estaEmpastelado())
                       + "/" + mundo.cimaDesbloqueada();
        if (firma.equals(ultimaFirma))
        {
            return;
        }
        ultimaFirma = firma;

        GreenfootImage img = getImage();
        img.clear();
        img.setFont(FUENTE);

        barra(img, 14, 78, "DANO", mundo.getDanio(), new Color(220, 90, 70), 0);
        barra(img, 262, 340, "REPARA", mundo.getReparacion(),
              new Color(90, 160, 235), 0);

        // La energia va marcada en diez bloques: asi se ve de un vistazo cuantos
        // golpes quedan, en vez de una barra continua que baja sin mas.
        barra(img, 524, 602, "ENERGIA", energia, new Color(110, 200, 110), 10);

        dibujarAvisos(img, mundo, ralph);

        if (mundo.estaTerminado())
        {
            dibujarMensajeFinal(img, mundo);
        }
    }

    /**
     * Etiqueta + barra de progreso con su porcentaje.
     *
     * Con segmentos > 1 la barra se divide en bloques, como vidas.
     */
    private void barra(GreenfootImage img, int x, int inicio, String etiqueta,
                       int porcentaje, Color color, int segmentos)
    {
        img.setColor(Color.WHITE);
        img.drawString(etiqueta, x, 21);

        img.setColor(new Color(45, 45, 60));
        img.fillRect(inicio, 10, BARRA_ANCHO, BARRA_ALTO);

        img.setColor(color);
        img.fillRect(inicio, 10, BARRA_ANCHO * porcentaje / 100, BARRA_ALTO);

        if (segmentos > 1)
        {
            img.setColor(new Color(18, 18, 32));
            for (int i = 1; i < segmentos; i++)
            {
                img.fillRect(inicio + BARRA_ANCHO * i / segmentos - 1, 10, 2, BARRA_ALTO);
            }
        }

        img.setColor(new Color(200, 200, 220));
        img.drawRect(inicio, 10, BARRA_ANCHO - 1, BARRA_ALTO - 1);
        img.drawString(porcentaje + "%", inicio + BARRA_ANCHO + 6, 21);
    }

    private void dibujarAvisos(GreenfootImage img, Mundo mundo, Ralph ralph)
    {
        img.setFont(FUENTE_AVISO);

        if (!mundo.estaActivo())
        {
            return;   // en el desenlace la franja de abajo se deja libre
        }

        // Los avisos van sobre el cielo, a los lados del letrero: abajo se
        // confundian con la textura del lodo.
        if (mundo.cimaDesbloqueada())
        {
            img.setColor(new Color(255, 220, 90));
            img.drawString("CIMA ABIERTA: sube y rompe el letrero", 16, 50);
        }
        else
        {
            img.setColor(new Color(190, 190, 210));
            img.drawString("Pilares: +" + Mundo.DANIO_VIGA + "% y no se reparan  ("
                           + mundo.vigasDestruidas() + "/" + Mundo.PISOS + ")", 16, 50);
        }

        dibujarAlerta(img, mundo, ralph);

        img.setColor(Color.WHITE);
        img.drawString((mundo.getTiempo() / 60) + "s", 752, 50);
    }

    /**
     * Un unico aviso a la vez, el mas urgente. Mostrarlos todos a la vez llenaba
     * la pantalla de texto y al final no se leia ninguno.
     */
    private void dibujarAlerta(GreenfootImage img, Mundo mundo, Ralph ralph)
    {
        int energia = ralph == null ? 0 : ralph.getSalud();

        if (energia <= 30)
        {
            img.setColor(new Color(255, 90, 90));
            img.drawString("ENERGIA BAJA: esquiva ladrillos", 456, 50);
        }
        else if (mundo.getReparacion() >= 70)
        {
            img.setColor(new Color(130, 190, 255));
            img.drawString("FELIX BLINDA: rompe algo ya", 456, 50);
        }
        else if (ralph != null && ralph.estaEmpastelado())
        {
            img.setColor(new Color(255, 170, 200));
            img.drawString("EMPASTELADO: no golpeas", 456, 50);
        }
    }

    private void dibujarMensajeFinal(GreenfootImage img, Mundo mundo)
    {
        boolean gano = mundo.hayVictoria();

        img.setColor(new Color(0, 0, 0, 175));
        img.fillRect(0, 190, Mundo.ANCHO, 116);

        img.setFont(FUENTE_GRANDE);
        img.setColor(gano ? new Color(255, 220, 90) : new Color(255, 110, 110));
        img.drawString(gano ? "RALPH GANA" : "RALPH PIERDE", 250, 240);

        img.setFont(FUENTE_AVISO);
        img.setColor(Color.WHITE);
        img.drawString(mundo.getResultado(), 60, 275);
        img.drawString("Destrozos: " + mundo.getDestrozos()
                       + "   Reparaciones de Felix: " + mundo.getReparaciones()
                       + "   Tiempo: " + (mundo.getTiempo() / 60) + "s", 60, 296);
    }
}
