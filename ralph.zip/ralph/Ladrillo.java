import greenfoot.*;

/**
 * Ladrillo lanzado por los vecinos: le quita energia a Ralph y lo sacude.
 */
public class Ladrillo extends Proyectil
{
    public static final int ANCHO = 16;
    public static final int ALTO  = 16;

    private static final int DANIO = 12;

    public Ladrillo()
    {
        super(2.0, 0.6, 8);
        setImage(Recursos.cargar("ladrillo.png",
                 Recursos.bloque(ANCHO, ALTO, new Color(180, 80, 50),
                                              new Color(90, 40, 25))));
    }

    protected void efecto(Ralph ralph)
    {
        ralph.recibirLadrillo(DANIO);
    }
}
