# Ralph el Demoledor — proyecto Greenfoot

Juego de plataformas basado en *Ralph el Demoledor*, desarrollado sobre la guia
**Semana 4: Sprites, estados y salto parabolico**.

**El jugador es RALPH.** Sube por el edificio destruyendolo mientras Felix, la
computadora, repara lo que rompe y lo persigue con su martillo.

**Estado actual: logica completa y probada, con sprites provisionales dibujados
por codigo.** Al agregar los `.png` reales el juego los usa automaticamente.

---

## 1. Como abrirlo

1. Abrir Greenfoot 3.9.
2. `Scenario > Open...` y elegir la carpeta `ralph`.
3. Boton **Run**, y hacer clic sobre el mundo antes de usar el teclado.

## 2. Controles (Ralph)

| Tecla | Accion |
|---|---|
| Flecha izquierda / derecha | Caminar |
| Espacio o flecha arriba | Saltar al piso de arriba (trayectoria parabolica) |
| Flecha abajo | Bajar un piso |
| **F** | Golpear: ventana, viga o el letrero de la azotea |
| **M** | Silenciar o volver a activar el sonido |

## 3. Como se gana

| Ruta | Condicion |
|---|---|
| **Colapso** | Llevar la barra de **DANO** al 100% |
| **Cima** | Con el edificio al **60%** de dano, subir a la azotea y romper el letrero (el pastel de la victoria) |

La barra de dano se llena asi:

- **Ventana rota: +4%**, pero es dano *reversible*: si Felix la repara, el dano baja.
- **Viga (punto estructural): +15%**, y es **permanente**. Aguanta 3 golpes y Felix
  no puede repararla. Hay una viga por piso: las cuatro suman 60%, justo el umbral
  que abre la cima.

Por eso no alcanza con romper ventanas: hay que derribar vigas para asegurar el
avance, y rematar con ventanas para llegar al 100%.

## 4. Como se pierde

| Derrota | Condicion |
|---|---|
| **Felix blinda el edificio** | Su barra de **REPARA** llega al 100%: eso ocurre solo si pasan unos diez segundos sin que Ralph destroce nada y con las veinte ventanas sanas. Cualquier destrozo la pone a cero |
| **Sin energia** | La barra de **ENERGIA** llega a 0 y Ralph cae del edificio |

La energia baja por dos motivos, y los dos se ven en pantalla:

- **Ladrillo de los vecinos: −12.**
- **Martillazo de Felix: −10**, y ademas lo deja *congelado* unos segundos (si
  Ralph esta en su mismo piso y a menos de 170 px, Felix deja de reparar y lo
  persigue).

Cada golpe muestra el numero flotando sobre Ralph, la barra de energia esta
dividida en diez bloques para que se vea cuantos golpes quedan, y por debajo del
30% aparece el aviso "ENERGIA BAJA". Despues de un impacto Ralph es invulnerable
un momento, asi que no encadenan golpes.

Los vecinos tambien lanzan **pasteles**: no quitan energia, pero dejan a Ralph a
media velocidad y sin poder golpear unos segundos. Todo lo que tiran **asoma
primero por la ventana medio segundo, parpadeando**, para que dé tiempo a
apartarse; lanzan cada vez mas seguido segun sube el dano, y esa es la presion
del reloj.

> Nota sobre "Felix te acorrala en una habitacion sin salida": el mapa es una
> fachada abierta con repisas continuas, no tiene habitaciones ni puertas, asi que
> esa variante no esta implementada. Si esta la otra mitad de esa condicion: el
> martillazo directo, que congela y debilita a Ralph.

## 5. Clases

| Clase | Responsabilidad |
|---|---|
| `Mundo` | Geometria del edificio, las tres barras, vecinos, victoria y derrota |
| `Personaje` | **Clase base abstracta**: fisica vertical y aterrizajes compartidos |
| `Ralph` | Jugador: estados, animacion, salto, golpes y dano recibido |
| `Felix` | IA: busca ventanas rotas, repara, persigue y da martillazos |
| `Ventana` | Estado intacta/rota (dano reversible) |
| `Viga` | Punto estructural: 3 golpes y dano permanente |
| `Letrero` | Objetivo de la cima; solo cede con el edificio ya danado |
| `Proyectil` | Base de lo que lanzan los vecinos (caida cuadratica + impacto) |
| `Ladrillo` / `Pastel` | Quita energia / ralentiza |
| `Plataforma` | Repisa de cada piso y de la azotea |
| `Hud` | Barras, avisos y mensaje final |
| `Aviso` | Numero flotante que aparece sobre Ralph al perder energia |
| `Recursos` | Carga de imagenes con respaldo generado por codigo |
| `Sonidos` | Reproduce los efectos; si no hay audio, el juego sigue en silencio |

Ralph y Felix hacen cosas distintas pero se mueven igual, por eso la ecuacion
cuadratica vive una sola vez, en `Personaje`. Cada uno conserva **su propio enum
de estados** (Ralph golpea y se aturde; Felix repara y persigue) y recibe avisos
de la fisica por los metodos `alSubir()`, `alCaer()` y `alAterrizar()`.

## 6. Relacion con la guia (actividad de cierre, seccion 16)

| Driver o concern | Decision tomada | Elemento de codigo |
|---|---|---|
| Respuesta visual | Cada estado tiene su propio sprite | `Ralph.actualizarAnimacion()`, `Felix.actualizarAnimacion()` |
| Mantenibilidad | Estados explicitos con `enum`, no numeros | `Ralph.Estado`, `Felix.Estado` |
| Movimiento natural | `y(t) = y0 - v0*t + 0.5*g*t^2` para saltar, caer y ser derrotado | `Personaje.actualizarVertical()`, `Proyectil.caer()` |
| Fluidez | Cambio de cuadro cada 6 ciclos, no en cada `act()` | `CICLOS_POR_FRAME` |
| Extensibilidad | Fisica compartida en una clase base; aterrizaje por colision real | `Personaje`, `Personaje.buscarAterrizaje()` |
| Consistencia | El estado logico decide siempre la imagen | `Ralph.mostrar()`, `Viga.actualizarImagen()` |
| Simplicidad | Sin motor fisico: una sola ecuacion para todo lo que cae | constantes `VELOCIDAD_INICIAL` y `GRAVEDAD` |

Extras de la guia ya resueltos: **Desafio 1** (sprite propio de salto), **Desafio 2**
(`SALTANDO` y `CAYENDO` separados) y **Desafio 3** (clase `Plataforma` con
aterrizaje real por colision).

### Parametros para los experimentos (seccion 14)

Estan agrupados como constantes al inicio de `Ralph.java` y `Felix.java`:

```java
private static final int    VELOCIDAD_HORIZONTAL = 5;      // experimento 3
private static final double VELOCIDAD_INICIAL    = 14.5;   // experimento 1
private static final double GRAVEDAD             = 1.0;    // experimento 2
private static final int    CICLOS_POR_FRAME     = 6;      // experimento 4
```

Cuidado con el experimento 1: la altura maxima del salto es `v0^2 / (2g)`.

- Entre pisos hay **88 px**: Felix salta con `v0 = 13.5` (91 px), lo justo.
- Del ultimo piso a la azotea hay **100 px**: Ralph salta con `v0 = 14.5` (105 px).
  Si se baja su `v0` o se sube la gravedad, **Ralph deja de poder llegar a la cima**
  y la ruta de victoria por escalada se vuelve imposible.

## 7. Sprites

**Ya no queda nada dibujado por codigo**: todo el arte sale de las tres hojas que
estan en la raiz del proyecto. Es material del arcade original y de un remake de
fans: sirve para el prototipo de clase, pero si el escenario llega a publicarse
habria que sustituirlo por dibujos propios.

| Origen | Que aporta |
|---|---|
| `hoja_sprites_ralph.jpg` | los 11 cuadros de Ralph |
| `hoja_sprites_felix.png` | los 9 cuadros de Felix (arcade, 25x34 sin escalar) |
| `todo.png` | ventanas, ladrillo, pastel, letrero y la textura de la viga |

### Medidas

Los personajes comparten un alto fijo con los pies en el borde inferior, que es lo
que el codigo necesita (`pies = centro + ALTO/2`), y el ancho cambia segun la pose;
el cuerpo no salta entre cuadros porque estan alineados por la cadera.

| Archivos | Tamano | Nota |
|---|---|---|
| `ralph_*` (10) | alto 62 | ancho 34..58 segun la pose |
| `ralph_lodo` | 77x26 | chapuzon final, lienzo propio |
| `felix_*` (9) | alto 37 | recortados a escala 1:1, sin ampliar |
| `ventana_intacta` / `ventana_rota` | 48x50 | una hoja de la fachada, al doble |
| `viga` / `viga_rota` | 16x74 | pilar de ladrillo, apilando la textura del muro |
| `letrero` / `letrero_activo` | 87x48 | el rotulo del juego, apagado y encendido |
| `ladrillo` / `pastel` | 16x16 | proyectiles de los vecinos |

La ventana rota y el letrero apagado no existen en las hojas: se fabrican a partir
de la ventana entera y del rotulo encendido, respetando marco y paleta.

La unica imagen que sigue generada por codigo es la repisa (`Plataforma`), una
banda lisa del color de los alfeizares. Si aparece `plataforma.png` se usa esa.

### Volver a recortar (carpeta `herramientas/`)

Requiere Python con Pillow, numpy y scipy.

```bash
python herramientas/1_detectar_cuadros.py hoja.png herramientas/contacto.png herramientas/cajas.json 3 60
python herramientas/2_mosaico.py hoja.png herramientas/cajas.json herramientas/mosaico.png
python herramientas/3_exportar_sprites.py herramientas/felix.json
python herramientas/4_extraer_objetos.py
```

1. El primero separa los cuadros y los numera (los dos ultimos numeros son el
   "cierre" y la tolerancia: 3 y 60 para hojas con los sprites muy juntos, 9 y 70
   para hojas espaciadas).
2. El segundo arma un mosaico con esos numeros para ver que pose es cada uno.
3. El tercero exporta segun un fichero de configuracion (`herramientas/ralph.json`
   o `felix.json`), donde se indica archivo -> numero de cuadro y si hay que
   voltearlo. Admite `"fondo": "borde"` para hojas con fondo negro, que respeta los
   negros del propio dibujo.
4. El cuarto recorta los objetos de `todo.png`, que son rectangulos fijos.

## 8. Sonido

Los 14 efectos de `sounds/` **no son grabaciones del arcade**: se sintetizan con
`herramientas/5_generar_sonidos.py`, usando ondas cuadradas y ruido, que es
justo como generaban el audio aquellas maquinas. Son originales, ocupan unos
pocos kilobytes y salen identicos cada vez que se ejecuta el script.

| Efecto | Cuando suena |
|---|---|
| `salto.wav` | Ralph salta (tono ascendente) |
| `paso.wav` | cada dos cuadros de la caminata, muy bajito |
| `golpe.wav` | el puno golpea una viga o el letrero |
| `romper.wav` | una ventana revienta (impacto y esquirlas) |
| `viga_cae.wav` | la viga se derrumba (retumbo grave) |
| `reparar.wav` | Felix termina una ventana (arpegio do-mi-sol) |
| `martillazo.wav` | Felix alcanza a Ralph |
| `ladrillo.wav` / `pastel.wav` | impacto de cada proyectil |
| `cima.wav` | el dano llega al 60% y se abre la azotea |
| `letrero.wav` | Ralph derriba el rotulo |
| `chapuzon.wav` | Ralph cae al lodo |
| `victoria.wav` / `derrota.wav` | final de la partida |

Dos detalles del sintetizador que se notan al oido:

- **Se quita la componente continua.** Una onda cuadrada con ciclo distinto de
  0.5 no esta centrada en cero, y eso se oye como un chasquido al empezar y al
  acabar cada efecto.
- **Se cuantiza a 6 bits y 22050 Hz.** No es por ahorrar espacio, es para que
  suene sucio como el hardware antiguo.

La clase `Sonidos` centraliza la reproduccion: ignora un efecto que se repita
antes de 6 ciclos (si no, chirria), y si no hay motor de audio (por ejemplo al
correr las pruebas fuera del IDE) desactiva el sonido en vez de fallar.

Para regenerarlos:

```bash
python herramientas/5_generar_sonidos.py
```

## 9. Tensiones entre concerns (seccion 4 de la guia)

No se puede maximizar todo a la vez. Estas son las cuatro tensiones de la guia y
como se resolvieron aqui.

**Realismo contra simplicidad.** Un motor fisico con velocidad, aceleracion,
friccion y fuerzas habria dado saltos mas creibles, pero seria imposible de
explicar en clase. Se usa una sola ecuacion, `y(t) = y0 - v0*t + 0.5*g*t^2`, y con
ella se resuelven cuatro cosas distintas: el salto, la caida entre pisos, los
proyectiles de los vecinos y la caida final de Ralph al lodo. Se pierde realismo y
se gana que todo el movimiento vertical del juego se entienda leyendo tres lineas
(`Personaje.actualizarVertical()`).

**Fluidez contra numero de actualizaciones.** Cambiar de sprite en cada `act()`
daria 60 cambios por segundo: la caminata se ve como un temblor. Por eso hay un
contador (`CICLOS_POR_FRAME = 6`) y la animacion solo avanza uno de cada seis
ciclos. El precio es que la animacion ya no esta sincronizada con la posicion: si
se sube mucho la velocidad horizontal, los pies "patinan".

**Simplicidad contra extensibilidad.** Con `if` sueltos bastaba para quieto y
caminando. Al aparecer golpear, aturdirse, caer al lodo y, en Felix, reparar y
perseguir, esos `if` se vuelven imposibles de mantener. Cada personaje tiene su
propio `enum Estado`, y anadir un estado nuevo es anadir un valor y un caso en
`actualizarAnimacion()`. Cuesta mas codigo al principio y lo devuelve despues.

**Control contra consistencia visual.** El personaje podria moverse bien y
mostrar siempre la misma imagen: funcionaria, pero el jugador no sabria si esta
saltando o cayendo. Por eso el movimiento espacial y la animacion son dos
responsabilidades separadas que se coordinan a traves del estado, nunca desde el
teclado directamente.

**Una tension propia de este juego: fidelidad al arcade contra jugabilidad.** En
el original Ralph solo se mueve por la azotea, asi que los pisos pueden estar muy
juntos. Aqui Ralph es el jugador y recorre el edificio, asi que los pisos tienen
que estar separados al menos su altura: 88 px. Eso obliga a que las ventanas se
vean mas grandes en proporcion que en el arcade.

## 10. Experimentos de laboratorio (seccion 14 de la guia)

Todo sale de la misma ecuacion. Con `y(t) = y0 - v0*t + 0.5*g*t^2`:

- altura maxima del salto = `v0^2 / (2g)`
- ciclos en el aire = `2*v0 / g`

### Experimento 1: cambiar `velocidadInicial` de 12 a 16

| v0 | Altura maxima | Ciclos en el aire |
|---|---|---|
| 12 | 72 px | 24 |
| 16 | 128 px | 32 |

1. **Aumenta** la altura maxima, y no de forma proporcional: al pasar de 12 a 16
   (un tercio mas) la altura crece un 78%, porque `v0` esta elevado al cuadrado.
2. **Si**, permanece mas tiempo en el aire: de 24 a 32 ciclos.
3. Se modifico el termino lineal, `-v0*t`, es decir el coeficiente `b` de
   `y = at^2 + bt + c`.

En el juego, Ralph usa `v0 = 14.5` (105 px de altura, 29 ciclos) porque de la
ultima repisa a la azotea hay 100 px; Felix usa `13.5` (91 px), lo justo para los
88 px que separan dos pisos.

### Experimento 2: gravedad 1.0 frente a 2.0

Con `v0 = 14.5`, doblar la gravedad reduce la altura a la mitad (105 px pasan a
52 px) y el tiempo en el aire tambien a la mitad (29 ciclos pasan a 14). El salto
se vuelve seco y pesado.

Consecuencia concreta: con `g = 2` Ralph deja de alcanzar los 88 px del piso de
arriba, **no puede subir y el juego se vuelve imposible de terminar**. Es el mejor
ejemplo de que un parametro visual tambien es un parametro de diseno.

### Experimento 3: velocidad horizontal 4 frente a 8

La distancia que se cubre en un salto es `velocidad * ciclos en el aire`. Con los
29 ciclos de Ralph: a 4 px/ciclo recorre 116 px; a 8, recorre 232 px. Como las
columnas de ventanas estan a 108 px, con 4 apenas se pasa una columna por salto y
con 8 se pasan dos. Ademas, cuanto mas rapido va, mas se nota el patinaje de la
animacion del experimento 4.

### Experimento 4: contador de animacion en 3, 6, 10 y 15

| Valor | Ciclos por vuelta completa (4 cuadros) | Efecto |
|---|---|---|
| 3 | 12 | Muy rapida, parece que corre nervioso |
| 6 | 24 | Intermedia, es la que usa el juego |
| 10 | 40 | Lenta, pesada; le pega al tamano de Ralph |
| 15 | 60 | Demasiado lenta: se desliza sin mover las piernas |

Con velocidad 5 px/ciclo, en el valor 6 Ralph avanza 30 px por cada cuadro de
animacion; en el valor 15 avanza 75 px, mas de su propio ancho, y por eso se ve
como si patinara.

## 11. Pruebas (carpeta `pruebas/`)

No forman parte del escenario: Greenfoot solo compila los `.java` de la raiz.

```bash
javac -d ../.build_ralph -cp "C:/Program Files/Greenfoot/lib/greenfoot.jar" *.java
javac -d ../.build_ralph -cp "C:/Program Files/Greenfoot/lib/greenfoot.jar;../.build_ralph" pruebas/*.java
java -cp "C:/Program Files/Greenfoot/lib/greenfoot.jar;../.build_ralph" PruebaLogica
```

`PruebaLogica` verifica 52 comportamientos sin abrir el IDE: geometria, salto
entre pisos, salto a la azotea, que Felix no pueda subir a ella, roturas, vigas,
las dos rutas de victoria, las dos derrotas, la IA de Felix y los proyectiles.
`ComprobarSonidos` verifica que los 14 WAV se decodifican.
`Simular [ciclos] [pasivo|solo-ventanas]` juega una partida entera sin teclado,
con un Ralph que destruye a ritmo fijo, e informa de que condicion se cumplio
primero: sirve para ajustar el equilibrio sin tener que jugar cada prueba.
`VistaPrevia salida.png [ciclos]` genera una imagen del escenario. Greenfoot
imprime un aviso de "installation is broken" al correr fuera del IDE: es normal,
solo indica que no encontro su imagen por defecto.
