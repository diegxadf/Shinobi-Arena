import greenfoot.*;

/**
 * Reproduccion de efectos de sonido.
 *
 * Es el equivalente de Recursos, pero para el audio: si un archivo no existe o
 * el escenario se ejecuta fuera de Greenfoot (por ejemplo en las pruebas), el
 * juego sigue funcionando en silencio en vez de romperse.
 *
 * Los WAV estan en sounds/ y se generan con herramientas/5_generar_sonidos.py.
 */
public class Sonidos
{
    /** Se puede apagar todo el audio desde aqui. */
    private static boolean activo = true;

    /** Ciclos que deben pasar antes de repetir un mismo efecto. */
    private static final int ESPERA_REPETICION = 6;

    private static String ultimoEfecto = "";
    private static long ultimoInstante = -1000;
    private static long ciclo = 0;
    private static boolean teclaPulsada = false;

    private Sonidos() { }

    /** Lo llama el mundo una vez por ciclo, para medir las repeticiones. */
    public static void avanzarCiclo()
    {
        ciclo++;
    }

    public static void reproducir(String archivo)
    {
        if (!activo)
        {
            return;
        }

        // Evita que el mismo efecto se dispare dos veces seguidas y "chirrie".
        if (archivo.equals(ultimoEfecto) && ciclo - ultimoInstante < ESPERA_REPETICION)
        {
            return;
        }
        ultimoEfecto = archivo;
        ultimoInstante = ciclo;

        try
        {
            Greenfoot.playSound(archivo);
        }
        catch (Throwable e)
        {
            // Sin motor de sonido (fuera del IDE): se juega en silencio.
            activo = false;
        }
    }

    /**
     * Enciende y apaga el audio con la tecla M.
     *
     * La lectura del teclado va protegida porque fuera de Greenfoot (en las
     * pruebas) no existe el gestor de teclado y lanzaria una excepcion.
     */
    public static void atenderTeclaSilencio()
    {
        boolean pulsada;
        try
        {
            pulsada = Greenfoot.isKeyDown("m");
        }
        catch (Throwable e)
        {
            return;
        }

        if (pulsada && !teclaPulsada)
        {
            activo = !activo;
        }
        teclaPulsada = pulsada;
    }

    public static void setActivo(boolean valor)
    {
        activo = valor;
    }

    public static boolean estaActivo()
    {
        return activo;
    }
}
