# Prompts para generar los sprites con Gemini

Guia para producir los archivos de `images/` en pixel art, todos con la misma
estetica. El juego funciona aunque falten: cada archivo que no exista sigue usando
el dibujo provisional, asi que se pueden ir agregando de a poco y probando.

> **El juego ya no necesita ninguno de estos prompts**: todos los sprites se
> recortaron de las hojas del arcade (ver la seccion 7 del README). Esta guia queda
> por si se quiere sustituir ese arte, que tiene derechos, por dibujos originales:
> los tamanos de la tabla de la seccion 2 estan desactualizados, los buenos son los
> del README.

---

## 1. Si Gemini rechaza el prompt

Hay tres motivos habituales, y los prompts de este documento ya los evitan.

**1. Nombrar personajes de una pelicula.** Pedir "Ralph" o "Felix" activa el filtro
de propiedad intelectual, porque son personajes registrados. **Dentro del prompt
nunca se los nombra**: se describen como *el demoledor* y *el reparador*, personajes
originales. Los archivos siguen llamandose `ralph_*.png` y `felix_*.png` porque asi
los busca el codigo, pero ese nombre no va en el prompt.

**2. Nombrar armas, aunque sea para prohibirlas.** El prompt anterior decia "no
dibujes ninguna bala, proyectil ni disparo": el filtro lee esas palabras y bloquea,
sin importar que estuvieran en negativo. La version nueva lo dice en positivo: *las
manos estan vacias, no aparece ningun objeto suelto en la imagen*.

**3. Vocabulario de violencia.** "Furia", "gritando", "destrozar" suman puntos en el
filtro. Se reemplazan por "gesto de esfuerzo", "ceno fruncido", "agrietado".

### Prompt de diagnostico

Si algo se sigue bloqueando, manda primero esto solo. Si pasa, el problema esta en
la descripcion del personaje; si tambien lo rechaza, el problema es la cuenta o la
region, no el texto:

```
Pixel art de 16 bits de un cubo de piedra gris sobre fondo magenta plano #FF00FF.
Pixeles cuadrados nitidos, sin antialiasing.
```

## 2. Reglas que impone el codigo (no negociables)

Estas cuatro cosas no son gusto artistico: si no se cumplen, el sprite se ve mal
dentro del juego.

1. **Mirando a la DERECHA.** El codigo genera la version hacia la izquierda solo,
   con `mirrorHorizontally()`. Un sprite que mire a la izquierda saldra al reves.
2. **Los pies tocan el borde inferior del lienzo.** El actor se posiciona por su
   centro y los pies se calculan como `centro + alto/2`. Si queda espacio vacio
   abajo, el personaje flotara sobre la repisa; si se sale, quedara enterrado.
3. **Personaje centrado horizontalmente** y del mismo tamano en todos sus cuadros.
   Entre cuadros de caminata la cabeza puede subir o bajar 1 pixel como mucho: mas
   que eso se ve como un temblor.
4. **PNG con transparencia real** (canal alfa), no fondo blanco.

Tamanos exactos y relacion de aspecto que conviene pedirle a Gemini:

| Archivos | Tamano final | Pedir en Gemini |
|---|---|---|
| `ralph_*` (10 archivos) | 46x52 | cuadrado 1:1 |
| `felix_*` (9 archivos) | 26x38 | vertical 3:4 |
| `ventana_intacta` / `ventana_rota` | 62x52 | cuadrado 1:1 |
| `viga` / `viga_rota` | 20x74 | vertical 3:4 |
| `letrero` / `letrero_activo` | 96x40 | horizontal 16:9 |
| `ladrillo` | 22x14 | horizontal 16:9 |
| `pastel` | 24x20 | cuadrado 1:1 |
| `plataforma` | 540x12 | horizontal 16:9 |

## 3. Flujo de trabajo

1. **Generar grande.** Nunca pedir 46x52 directo: Gemini devuelve un borron. Se
   pide una cuadricula logica de 46x52 **ampliada** a 1024x1024.
2. **Fondo magenta.** Gemini casi nunca entrega transparencia; el magenta puro
   (`#FF00FF`) no aparece en ningun sprite, asi que se recorta despues sin dudas.
3. **Recortar y reducir** en [photopea.com](https://www.photopea.com) (gratis, sin
   instalar):
   - `Select > Color Range`, clic en el magenta, `Delete`.
   - `Image > Image Size`, poner el tamano exacto de la tabla y elegir
     **Nearest Neighbor** (nunca Bicubic: suaviza y arruina el pixel art).
   - `File > Export as > PNG`, con el nombre exacto del archivo.
4. **Guardar en** `ralph/images/` y volver a correr el escenario.

## 4. Bloque de estilo (va en TODOS los prompts)

```
Pixel art de videojuego arcade de 16 bits, estilo maquina recreativa de los anos 80,
con aspecto caricaturesco y amable.
Pixeles cuadrados grandes y nitidos, SIN antialiasing, SIN degradados, SIN desenfoque:
cada pixel logico es un cuadrado solido de un unico color.
Paleta limitada, sombreado plano de dos tonos por color, contorno oscuro de 1 pixel.
Luz desde arriba a la izquierda. Vista lateral 2D de juego de plataformas.
Fondo de un unico color plano magenta puro #FF00FF: sin sombra, sin suelo, sin texto,
sin marco, sin bordes, sin decoracion, sin cuadricula visible.
La imagen debe verse como una cuadricula de pixeles ampliada (nearest neighbor),
no como una ilustracion suave.
```

## 5. Los dos personajes

Personajes **originales**: en el prompt no se menciona ninguna pelicula ni ningun
nombre registrado. Pegar la descripcion completa en el primer prompt de cada uno;
despues basta con adjuntar la imagen de referencia.

### El demoledor (archivos `ralph_*.png`)

```
Personaje original de videojuego: un obrero gigante y torpe, de aspecto bonachon.
Hombros muy anchos, torso masivo, cabeza pequena en comparacion, piernas cortas y
gruesas, descalzo con pies grandes. Sus MANOS son enormes, del tamano de su cabeza.
Ropa: camisa naranja oxido de manga corta y overol marron oscuro gastado y remendado.
Pelo castano oscuro alborotado, nariz grande y ancha, cejas gruesas, ceno fruncido
pero con expresion simpatica de dibujo animado.
Paleta exacta:
  piel #E8B48A, sombra de piel #C4855E
  camisa #D2612F, sombra #9A3F1B
  overol #6B4A2F, sombra #4A3320
  pelo #3A2418
  contorno #241309
  blanco de los ojos #F2EFE6
```

### El reparador (archivos `felix_*.png`)

```
Personaje original de videojuego: un tecnico bajito y amable, de proporciones
caricaturescas. Cabeza grande y redonda, cuerpo pequeno, manos chicas. Gorra azul
con visera, camisa celeste de manga corta, pantalon azul marino, cinturon de
herramientas marron. Lleva SIEMPRE un martillo de carpintero dorado con mango de
madera en la mano derecha. Sonrisa amable, ojos grandes y redondos.
Paleta exacta:
  piel #F2C9A0, sombra de piel #D19A6E
  camisa #4FA3E3, sombra #2E6EA8
  pantalon y gorra #26406B
  cinturon #7A4A26
  martillo: mango #8A5A2B, cabeza dorada #E8C55A con sombra #B8912F
  contorno #16223A
```

---

## 6. Prompts del demoledor (`ralph_*.png`)

### 6.1. `ralph_idle.png` — hacerlo PRIMERO

Esta imagen es la referencia de todo lo demas: hay que aprobarla antes de seguir.

```
[BLOQUE DE ESTILO]

[DESCRIPCION DEL DEMOLEDOR]

Dibuja UN unico sprite: el personaje de pie, quieto, mirando hacia la DERECHA,
brazos colgando a los costados con las manos cerradas, peso en las dos piernas.
Cuadricula logica de 46x52 pixeles, ampliada a 1024x1024.
Los pies deben tocar exactamente el borde inferior del dibujo y el cuerpo debe
quedar centrado horizontalmente. Un solo personaje, nada mas en la imagen.
```

> A partir de aqui, **adjunta `ralph_idle` en cada prompt** y empieza con
> "Usando exactamente este personaje, esta paleta y este estilo...". Es la unica
> forma de que los cuadros no cambien de aspecto entre generaciones.

### 6.2. `ralph_walk1..4.png` — hoja de caminata

```
[adjuntar aqui la imagen de referencia del demoledor]

Usando exactamente este mismo personaje, la misma paleta, el mismo tamano y el
mismo estilo pixel art, dibuja una HOJA DE SPRITES horizontal con 4 cuadros de una
animacion de caminata ciclica, los 4 mirando a la DERECHA:
1) pierna derecha adelantada y brazo izquierdo adelante (brazos en oposicion)
2) paso intermedio, piernas casi juntas, cuerpo 1 pixel mas alto
3) pierna izquierda adelantada y brazo derecho adelante
4) paso intermedio igual al 2 pero con los brazos al reves

Los 4 cuadros deben medir exactamente lo mismo (46x52 pixeles logicos cada uno),
con los pies apoyados siempre en el borde inferior y el cuerpo centrado.
Solo cambian piernas y brazos: la cabeza no se mueve mas de 1 pixel.
Separa los cuadros con una franja vertical de fondo magenta #FF00FF del mismo ancho.
Sin numeros, sin etiquetas, sin texto.
```

### 6.3. `ralph_jump.png`, `ralph_fall.png`, `ralph_aturdido.png` — hoja de poses

```
[adjuntar aqui la imagen de referencia del demoledor]

Usando exactamente este mismo personaje, paleta y estilo, dibuja una HOJA de 3
cuadros en fila (46x52 pixeles logicos cada uno), separados por franjas de fondo
magenta #FF00FF, los tres mirando a la DERECHA:
1) SALTANDO: cuerpo estirado hacia arriba, los dos brazos levantados, rodillas
   recogidas, gesto de esfuerzo.
2) CAYENDO: brazos abiertos hacia los lados, piernas separadas, boca abierta y
   cejas levantadas, expresion de sorpresa.
3) MAREADO: encogido y tambaleante, ojos en espiral, tres estrellitas amarillas
   pequenas girando sobre la cabeza, brazos caidos.
En los tres cuadros los pies (o el punto mas bajo del cuerpo) tocan el borde
inferior y el personaje queda centrado. Sin texto.
```

### 6.4. `ralph_smash1.png`, `ralph_smash2.png` — el empujon con los punos

En el juego el personaje solo actua con sus manos, cuerpo a cuerpo. La consigna va
**en positivo**: manos vacias y nada suelto en la imagen.

```
[adjuntar aqui la imagen de referencia del demoledor]

Usando exactamente este mismo personaje, paleta y estilo, dibuja una HOJA de 2
cuadros en fila (46x52 pixeles logicos cada uno), separados por una franja de fondo
magenta #FF00FF, los dos mirando a la DERECHA. Es la animacion de un personaje de
dibujo animado que empuja una pared con sus propias manos:
1) PREPARACION: torso girado hacia atras, las DOS manos cerradas y recogidas a la
   altura del pecho, rodillas flexionadas, ceno fruncido.
2) EMPUJE: los DOS brazos extendidos al maximo hacia la derecha, rectos y paralelos,
   las manos cerradas con los nudillos hacia adelante, cuerpo inclinado hacia
   adelante, boca abierta con gesto de esfuerzo.

Las manos del personaje estan VACIAS: solo se ven sus nudillos. En la imagen no hay
ningun objeto suelto, ni nada volando por el aire, ni efectos de luz o energia.
En el cuadro 2 puedes anadir 3 o 4 chispitas blancas muy pequenas justo delante de
los nudillos, siempre DENTRO del cuadro de 46x52.
Los pies tocan el borde inferior en los dos cuadros y el cuerpo queda centrado.
```

---

## 7. Prompts del reparador (`felix_*.png`)

### 7.1. `felix_idle.png` — hacerlo primero

```
[BLOQUE DE ESTILO]

[DESCRIPCION DEL REPARADOR]

Dibuja UN unico sprite: el personaje de pie, quieto, mirando hacia la DERECHA,
sonriendo, con el martillo apoyado sobre el hombro derecho.
Cuadricula logica de 26x38 pixeles, ampliada a 1024x1024 (imagen vertical).
Los pies deben tocar exactamente el borde inferior y el cuerpo quedar centrado.
Al ser un sprite pequeno, usa formas simples y grandes: los detalles finos
desaparecen. Un solo personaje, nada mas en la imagen.
```

### 7.2. `felix_walk1..4.png`

```
[adjuntar aqui la imagen de referencia del reparador]

Usando exactamente este mismo personaje, paleta y estilo, dibuja una HOJA DE
SPRITES horizontal con 4 cuadros de caminata ciclica mirando a la DERECHA, con el
martillo siempre en la mano:
1) pierna derecha adelantada, 2) paso intermedio, 3) pierna izquierda adelantada,
4) paso intermedio con los brazos invertidos.
Cada cuadro mide 26x38 pixeles logicos, todos del mismo tamano, con los pies en el
borde inferior y el cuerpo centrado. Separa los cuadros con franjas de fondo
magenta #FF00FF. Sin texto ni numeros.
```

### 7.3. `felix_jump.png`, `felix_fall.png`, `felix_fix1.png`, `felix_fix2.png`

```
[adjuntar aqui la imagen de referencia del reparador]

Usando exactamente este mismo personaje, paleta y estilo, dibuja una HOJA de 4
cuadros en fila (26x38 pixeles logicos cada uno), separados por franjas de fondo
magenta #FF00FF, los cuatro mirando a la DERECHA:
1) SALTANDO: piernas recogidas, martillo levantado sobre la cabeza.
2) CAYENDO: piernas estiradas hacia abajo, brazos hacia arriba, gorra levantada.
3) REPARANDO, martillo arriba: de pie, martillo alzado por encima de la cabeza,
   listo para dar un clavo hacia la derecha.
4) REPARANDO, martillo abajo: el mismo personaje con el martillo ya bajado hacia
   adelante a la altura del pecho, brazos extendidos hacia la derecha.
Los cuadros 3 y 4 son dos fotogramas del mismo movimiento: el cuerpo, los pies y la
cabeza deben quedar EXACTAMENTE en el mismo sitio, solo se mueven los brazos y el
martillo. Pies en el borde inferior, cuerpo centrado. Sin texto.
```

---

## 8. Prompts de los objetos

### 8.1. `ventana_intacta.png` (62x52)

```
[BLOQUE DE ESTILO]

Dibuja UNA ventana de edificio vista de frente, en pixel art de 16 bits.
Marco blanco hueso en forma de cruz que divide el cristal en cuatro paneles.
Cristal celeste claro (#8CD1EB) con un reflejo diagonal blanco en el panel superior
izquierdo. Alfeizar gris claro en la base. Sin cortinas, sin personas.
Cuadricula logica de 62x52 pixeles, ampliada a 1024x1024.
La ventana ocupa todo el lienzo, apoyada en el borde inferior; el resto es fondo
magenta plano #FF00FF.
```

### 8.2. `ventana_rota.png` (62x52)

```
[adjuntar aqui la imagen de la ventana en buen estado]

Usando exactamente esta misma ventana, con el marco en la MISMA posicion y del
MISMO tamano, dibujala vieja y agrietada: los cuatro cristales quebrados, el
interior azul muy oscuro (#231E2D), astillas de vidrio celeste apuntando hacia
adentro desde los bordes del marco, y el marco desconchado en dos o tres puntos.
No muevas ni cambies el tamano del marco ni del alfeizar: es la misma ventana, solo
que en mal estado. Mismo tamano de lienzo y mismo fondo magenta #FF00FF.
```

### 8.3. `viga.png` (20x74)

```
[BLOQUE DE ESTILO]

Dibuja UNA viga de acero vertical, muy estrecha y alta, vista de frente, en pixel
art de 16 bits. Color acero grisaceo con oxido anaranjado en los bordes, una fila
central de remaches redondos oscuros de arriba a abajo, y refuerzos horizontales
arriba y abajo. Debe verse solida, como una columna de sosten.
Cuadricula logica de 20x74 pixeles (muy vertical), ampliada a una imagen alta.
La viga ocupa toda la altura del lienzo y toca el borde inferior; a los lados,
fondo magenta plano #FF00FF.
```

### 8.4. `viga_rota.png` (20x74)

```
[adjuntar aqui la imagen de la viga entera]

Usando la misma viga, misma paleta y mismo lienzo, dibuja solo lo que queda de ella:
un monton bajo de trozos de metal doblado y cascotes oscuros apilados en la parte
de abajo, ocupando aproximadamente el quinto inferior del lienzo.
Todo el resto del lienzo, de arriba hacia abajo, debe ser fondo magenta plano
#FF00FF completamente vacio.
```

### 8.5. `letrero.png` (96x40) — apagado

```
[BLOQUE DE ESTILO]

Dibuja UN letrero luminoso de azotea apagado, visto de frente, en pixel art de 16
bits: un cartel rectangular horizontal de marco metalico gris, con una fila de
bombillas redondas apagadas (gris oscuro) alrededor del borde, y en el centro la
silueta apagada y sin brillo de un pastel de cumpleanos.
Todo el cartel en tonos grises y azulados apagados, como sin corriente.
NO escribas ninguna palabra ni letra en el cartel.
Cuadricula logica de 96x40 pixeles (imagen horizontal), ampliada a 1024 px de ancho.
El cartel ocupa todo el lienzo; el resto, fondo magenta plano #FF00FF.
```

### 8.6. `letrero_activo.png` (96x40) — encendido

```
[adjuntar aqui la imagen del cartel apagado]

Usando exactamente el mismo cartel, del mismo tamano y en la misma posicion,
dibujalo ENCENDIDO: marco dorado brillante, todas las bombillas del borde amarillas
y encendidas con un halo claro, y en el centro un pastel de cumpleanos a todo color
(base marron, crema blanca, cereza roja arriba) bien iluminado.
El cartel no cambia de forma ni de tamano: solo se enciende.
Mismo lienzo y mismo fondo magenta #FF00FF. Sin texto ni letras.
```

### 8.7. `ladrillo.png` (22x14)

```
[BLOQUE DE ESTILO]

Dibuja UN ladrillo rojo de construccion visto de lado, en pixel art de 16 bits.
Rojo terracota (#B4503A) con la cara superior mas clara, mortero gris claro en dos
bordes y un par de mellas oscuras en las esquinas.
Cuadricula logica de 22x14 pixeles (horizontal, muy pequeno): usa formas simples,
sin detalles finos. Ampliar a 1024 px de ancho.
El ladrillo ocupa casi todo el lienzo, centrado; el resto, fondo magenta #FF00FF.
```

### 8.8. `pastel.png` (24x20)

```
[BLOQUE DE ESTILO]

Dibuja UNA porcion de pastel de crema vista de lado, en pixel art de 16 bits, del
tipo que aparece en las comedias antiguas: base de bizcocho marron claro, capa
gruesa de crema blanca ondulada encima y una cereza roja en la punta.
Cuadricula logica de 24x20 pixeles: formas simples y legibles a tamano diminuto.
El pastel ocupa casi todo el lienzo, centrado; el resto, fondo magenta #FF00FF.
```

### 8.9. `plataforma.png` (540x12)

```
[BLOQUE DE ESTILO]

Dibuja UNA cornisa horizontal de edificio, muy larga y muy fina, vista de frente,
en pixel art de 16 bits: una franja de piedra gris clara con una linea de luz mas
clara en el borde superior y una linea de sombra oscura en el borde inferior.
El patron debe ser UNIFORME y repetitivo a lo largo de toda la franja, sin adornos
unicos, sin extremos distintos, sin esquinas decorativas: en el juego esta franja
se estira horizontalmente.
Cuadricula logica de 540x12 pixeles (una banda horizontal muy alargada).
La banda ocupa todo el ancho del lienzo; arriba y abajo, fondo magenta #FF00FF.
```

---

## 9. Si algo sale mal

| Problema | Que hacer |
|---|---|
| **"Va en contra de las directrices"** | Revisar que no aparezca ningun nombre de pelicula o personaje registrado, ninguna palabra de armas (ni siquiera negada) y ningun termino violento. Ver la seccion 1 |
| Bordes suaves, parece ilustracion | Agregar "cada pixel logico debe ser un cuadrado solido de color uniforme, sin ningun borde suave ni antialiasing" |
| El fondo tiene degradado o textura | "fondo 100% plano de un unico color magenta #FF00FF, sin ninguna variacion de tono" |
| Cambia de estilo entre cuadros | Siempre adjuntar la imagen de referencia y repetir "usando exactamente este mismo personaje y paleta" |
| El personaje flota o se hunde | "los pies deben tocar exactamente el borde inferior del dibujo" |
| Mira hacia la izquierda | Repetir "mirando hacia la DERECHA" o voltear en Photopea (`Image > Flip Horizontal`) |
| Sale con sombra en el suelo | "sin sombra proyectada, sin suelo, sin superficie de apoyo" |
| Mete texto o marcas de agua | "sin texto, sin letras, sin numeros, sin firma, sin marca de agua" |
| Demasiado detalle para el tamano | "usa formas simples y grandes; el sprite final mide solo 46x52 pixeles" |

## 10. Orden recomendado

1. `ralph_idle` (referencia de todo el personaje) → aprobar antes de seguir.
2. Hoja de caminata → probar en el juego: es lo que mas se ve.
3. `ralph_smash1/2` y las poses de salto.
4. `felix_idle` y sus hojas.
5. Ventanas, viga y letrero, que son los objetivos del juego.
6. Ladrillo, pastel y plataforma.
