import greenfoot.*;

/**
 * Letrero principal en lo alto del edificio, con el pastel de la victoria.
 *
 * Solo se puede derribar cuando el edificio ya esta suficientemente danado
 * (Mundo.UMBRAL_CIMA). Golpearlo entonces gana la partida por la ruta de escalada.
 */
public class Letrero extends Actor
{
    // El rotulo del juego, recortado de la hoja a la mitad de tamano.
    public static final int ANCHO = 87;
    public static final int ALTO  = 48;

    private boolean derribado = false;

    public Letrero()
    {
        actualizarImagen();
    }

    public void act()
    {
        actualizarImagen();
    }

    /** Ralph lo golpea: solo cede si ya hay bastante dano acumulado. */
    public boolean recibirGolpe()
    {
        Mundo mundo = (Mundo) getWorld();

        if (derribado || !mundo.cimaDesbloqueada())
        {
            return false;
        }

        derribado = true;
        Sonidos.reproducir("letrero.wav");
        actualizarImagen();
        mundo.victoria("Ralph derribo el letrero y se llevo el pastel");
        return true;
    }

    private void actualizarImagen()
    {
        Mundo mundo = (Mundo) getWorld();
        boolean activo = mundo != null && mundo.cimaDesbloqueada();

        setImage(Recursos.cargar(activo ? "letrero_activo.png" : "letrero.png",
                                 dibujar(activo)));
    }

    private GreenfootImage dibujar(boolean activo)
    {
        Color fondo = activo ? new Color(230, 180, 60) : new Color(90, 88, 100);
        Color borde = activo ? new Color(255, 240, 180) : new Color(60, 58, 70);

        GreenfootImage img = Recursos.bloque(ANCHO, ALTO, fondo, borde);
        img.setFont(new Font("Monospaced", true, false, 14));
        img.setColor(activo ? new Color(60, 40, 10) : new Color(150, 148, 160));
        img.drawString(activo ? "PASTEL!" : "CERRADO", 16, 26);

        return img;
    }

    public boolean estaDerribado()
    {
        return derribado;
    }
}
