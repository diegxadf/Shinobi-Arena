import greenfoot.*;
import java.util.List;

/**
 * Comportamiento fisico comun a Ralph (jugador) y Felix (IA).
 *
 * Concentra aqui el movimiento vertical porque los dos personajes usan la misma
 * ecuacion cuadratica y el mismo sistema de aterrizaje:
 *
 *     y(t) = y0 - v0*t + 0.5*g*t^2
 *
 * Cada subclase mantiene su propio enum de estados (son distintos: Ralph golpea,
 * Felix repara) y solo recibe avisos mediante los metodos alSubir(), alCaer() y
 * alAterrizar(). Asi se comparte la fisica sin mezclar las dos maquinas de estado.
 */
public abstract class Personaje extends Actor
{
    protected final int anchoCuerpo;
    protected final int altoCuerpo;
    protected final double velocidadInicial;   // v0 del salto
    protected final double gravedad;           // g

    private boolean enAire = false;
    private int tiempoSalto = 0;
    private int yInicial = 0;
    private double v0Actual = 0.0;

    protected Plataforma plataformaActual;
    protected int pisoActual = 0;

    protected Personaje(int ancho, int alto, double velocidadInicial, double gravedad)
    {
        this.anchoCuerpo = ancho;
        this.altoCuerpo = alto;
        this.velocidadInicial = velocidadInicial;
        this.gravedad = gravedad;
    }

    // ------------------------------------------------------------------
    // Movimiento horizontal
    // ------------------------------------------------------------------

    /** Mueve en x sin salir de la fachada; si la repisa se acaba, cae. */
    protected void moverHorizontal(int desplazamiento)
    {
        int limiteIzq = Mundo.EDIFICIO_X1 + anchoCuerpo / 2;
        int limiteDer = Mundo.EDIFICIO_X2 - anchoCuerpo / 2;

        int x = getX() + desplazamiento;
        x = Math.max(limiteIzq, Math.min(limiteDer, x));
        setLocation(x, getY());

        if (!enAire && plataformaActual != null && !plataformaActual.cubre(getX()))
        {
            iniciarCaida();
        }
    }

    // ------------------------------------------------------------------
    // Movimiento vertical
    // ------------------------------------------------------------------

    protected void iniciarSalto()
    {
        if (enAire)
        {
            return;
        }
        enAire = true;
        tiempoSalto = 0;
        yInicial = getY();
        v0Actual = velocidadInicial;
        plataformaActual = null;
        alSubir();
    }

    /** Caida sin impulso: la misma ecuacion con v0 = 0. */
    protected void iniciarCaida()
    {
        if (enAire)
        {
            return;
        }
        enAire = true;
        tiempoSalto = 0;
        setLocation(getX(), getY() + 8);   // se despega de la repisa
        yInicial = getY();
        v0Actual = 0.0;
        plataformaActual = null;
        alCaer();
    }

    protected void actualizarVertical()
    {
        if (!enAire)
        {
            return;
        }

        tiempoSalto++;

        double y = yInicial
                   - v0Actual * tiempoSalto
                   + 0.5 * gravedad * tiempoSalto * tiempoSalto;

        int yAnterior = getY();
        int yNuevo = (int) y;

        if (yNuevo >= yAnterior)          // esta bajando: puede aterrizar
        {
            Plataforma destino = buscarAterrizaje(yAnterior, yNuevo);
            if (destino != null)
            {
                aterrizar(destino);
                return;
            }
            alCaer();
        }
        else
        {
            alSubir();
        }

        setLocation(getX(), yNuevo);
    }

    /**
     * Plataforma cuya superficie cruzaron los pies durante este ciclo.
     * Si hay varias gana la mas alta: es la primera que se toca al bajar.
     */
    private Plataforma buscarAterrizaje(int yAnterior, int yNuevo)
    {
        int piesAntes   = yAnterior + altoCuerpo / 2;
        int piesDespues = yNuevo + altoCuerpo / 2;

        Plataforma elegida = null;
        List<Plataforma> plataformas = getWorld().getObjects(Plataforma.class);

        for (Plataforma p : plataformas)
        {
            if (!puedeApoyarseEn(p))
            {
                continue;
            }

            int superficie = p.getSuperficie();

            if (p.cubre(getX()) && piesAntes <= superficie && piesDespues >= superficie)
            {
                if (elegida == null || superficie < elegida.getSuperficie())
                {
                    elegida = p;
                }
            }
        }
        return elegida;
    }

    /** Felix lo redefine: la IA no sube a la azotea. */
    protected boolean puedeApoyarseEn(Plataforma p)
    {
        return true;
    }

    protected void aterrizar(Plataforma p)
    {
        plataformaActual = p;
        pisoActual = p.getPiso();
        setLocation(getX(), p.getSuperficie() - altoCuerpo / 2);

        enAire = false;
        tiempoSalto = 0;
        alAterrizar();
    }

    /** Coloca al personaje sobre un piso concreto (lo usa el mundo al preparar). */
    public void colocarEnPiso(int piso)
    {
        for (Plataforma p : getWorld().getObjects(Plataforma.class))
        {
            if (p.getPiso() == piso && p.cubre(getX()))
            {
                aterrizar(p);
                return;
            }
        }
    }

    // ------------------------------------------------------------------
    // Avisos para la maquina de estados de cada subclase
    // ------------------------------------------------------------------

    protected abstract void alSubir();
    protected abstract void alCaer();
    protected abstract void alAterrizar();

    // ------------------------------------------------------------------
    // Consultas
    // ------------------------------------------------------------------

    public boolean estaEnAire()
    {
        return enAire;
    }

    public int getPiso()
    {
        return pisoActual;
    }

    public int getAltoCuerpo()
    {
        return altoCuerpo;
    }

    protected Mundo getMundo()
    {
        return (Mundo) getWorld();
    }
}
