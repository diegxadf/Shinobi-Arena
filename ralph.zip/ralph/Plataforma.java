import greenfoot.*;

/**
 * Repisa de un piso del edificio.
 *
 * Felix no usa coordenadas fijas para aterrizar: consulta las plataformas que
 * existen en el mundo. Asi se pueden agregar o mover pisos sin tocar su codigo
 * (driver: extensibilidad).
 */
public class Plataforma extends Actor
{
    public static final int ALTO = 12;

    private int piso;

    public Plataforma(int ancho, int piso)
    {
        this.piso = piso;

        GreenfootImage img = Recursos.cargar("plataforma.png",
                             Recursos.bloque(ancho, ALTO, new Color(198, 122, 78),
                                                          new Color(140, 80, 48)));

        // El sprite se estira al ancho pedido: la azotea es mas ancha que los pisos.
        if (img.getWidth() != ancho)
        {
            img.scale(ancho, ALTO);
        }
        setImage(img);
    }

    /** Coordenada y de la cara superior: es el nivel donde se apoyan los pies. */
    public int getSuperficie()
    {
        return getY() - getImage().getHeight() / 2;
    }

    /** Indica si la coordenada x cae dentro de esta plataforma. */
    public boolean cubre(int x)
    {
        int mitad = getImage().getWidth() / 2;
        return x >= getX() - mitad && x <= getX() + mitad;
    }

    public int getPiso()
    {
        return piso;
    }
}
