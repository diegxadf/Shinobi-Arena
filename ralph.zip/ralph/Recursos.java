import greenfoot.*;

/**
 * Carga de imagenes con respaldo generado por codigo.
 *
 * Driver atendido: EXTENSIBILIDAD / SIMPLICIDAD.
 * Permite programar y probar toda la logica del juego antes de tener sprites:
 * si el archivo .png existe en la carpeta images se usa, y si no existe se
 * dibuja un rectangulo de color equivalente (placeholder).
 * Cuando se agreguen los sprites reales NO hay que tocar el resto del codigo.
 */
public class Recursos
{
    /** Intenta cargar un archivo de images/. Si no existe devuelve el respaldo. */
    public static GreenfootImage cargar(String archivo, GreenfootImage respaldo)
    {
        try
        {
            return new GreenfootImage(archivo);
        }
        catch (Exception e)
        {
            return respaldo;
        }
    }

    /** Rectangulo simple con borde, usado como sprite provisional. */
    public static GreenfootImage bloque(int ancho, int alto, Color relleno, Color borde)
    {
        GreenfootImage img = new GreenfootImage(ancho, alto);
        img.setColor(relleno);
        img.fillRect(0, 0, ancho, alto);
        img.setColor(borde);
        img.drawRect(0, 0, ancho - 1, alto - 1);
        return img;
    }

    /**
     * Muneco provisional: cuerpo, cabeza y una marca que indica el frame.
     * El parametro fase permite distinguir visualmente los cuadros de caminata.
     */
    public static GreenfootImage personaje(int ancho, int alto, Color cuerpo,
                                           Color cabeza, int fase)
    {
        GreenfootImage img = new GreenfootImage(ancho, alto);
        int altoCabeza = alto / 3;

        img.setColor(cabeza);
        img.fillOval(ancho / 4, 0, ancho / 2, altoCabeza);

        img.setColor(cuerpo);
        img.fillRect(ancho / 6, altoCabeza, ancho - ancho / 3, alto - altoCabeza - alto / 5);

        // Piernas: su separacion cambia con la fase para que se note la animacion.
        int abertura = (fase % 2 == 0) ? 1 : ancho / 5;
        img.fillRect(ancho / 6 + abertura, alto - alto / 5, ancho / 6, alto / 5);
        img.fillRect(ancho - ancho / 3 - abertura, alto - alto / 5, ancho / 6, alto / 5);

        img.setColor(Color.BLACK);
        img.drawRect(0, 0, ancho - 1, alto - 1);
        return img;
    }
}
