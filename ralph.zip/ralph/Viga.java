import greenfoot.*;

/**
 * Punto estructural clave del edificio.
 *
 * Aguanta varios golpes de Ralph y, al romperse, suma un dano PERMANENTE:
 * Felix no puede repararla. Son las vigas las que hacen posible llegar al 100%
 * de la barra de dano.
 */
public class Viga extends Actor
{
    public static final int ANCHO = 16;
    public static final int ALTO  = 74;

    public static final int GOLPES_NECESARIOS = 3;

    private final int piso;
    private int golpesRecibidos = 0;

    public Viga(int piso)
    {
        this.piso = piso;
        actualizarImagen();
    }

    /** Devuelve true si este golpe la destruyo. */
    public boolean recibirGolpe()
    {
        if (estaDestruida())
        {
            return false;
        }

        golpesRecibidos++;
        actualizarImagen();

        if (estaDestruida())
        {
            Sonidos.reproducir("viga_cae.wav");
            ((Mundo) getWorld()).registrarVigaDestruida();
            return true;
        }

        ((Mundo) getWorld()).registrarDestrozo();
        return false;
    }

    private void actualizarImagen()
    {
        if (estaDestruida())
        {
            setImage(Recursos.cargar("viga_rota.png", dibujar(true)));
        }
        else
        {
            setImage(Recursos.cargar("viga.png", dibujar(false)));
        }
    }

    private GreenfootImage dibujar(boolean destruida)
    {
        if (destruida)
        {
            GreenfootImage img = new GreenfootImage(ANCHO, ALTO);
            img.setColor(new Color(70, 60, 55));
            img.fillRect(0, ALTO - 16, ANCHO, 16);      // solo queda el escombro
            img.setColor(new Color(40, 34, 30));
            img.drawRect(0, ALTO - 16, ANCHO - 1, 15);
            return img;
        }

        GreenfootImage img = Recursos.bloque(ANCHO, ALTO, new Color(150, 120, 70),
                                                          new Color(80, 60, 35));
        img.setColor(new Color(80, 60, 35));

        // Remaches y, segun los golpes recibidos, grietas.
        for (int y = 8; y < ALTO; y += 18)
        {
            img.fillOval(ANCHO / 2 - 2, y, 4, 4);
        }
        for (int i = 0; i < golpesRecibidos; i++)
        {
            int y = 14 + i * 22;
            img.drawLine(2, y, ANCHO - 3, y + 12);
            img.drawLine(ANCHO - 3, y, 2, y + 12);
        }
        return img;
    }

    public boolean estaDestruida()
    {
        return golpesRecibidos >= GOLPES_NECESARIOS;
    }

    public int getGolpesRestantes()
    {
        return Math.max(0, GOLPES_NECESARIOS - golpesRecibidos);
    }

    public int getPiso()
    {
        return piso;
    }
}
