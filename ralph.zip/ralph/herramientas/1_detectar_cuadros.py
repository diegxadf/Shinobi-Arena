"""Detecta los cuadros sueltos de una hoja de sprites con fondo liso.

Uso: python 1_detectar_cuadros.py <hoja.jpg> <contacto.png> <cajas.json> [cierre] [tolerancia]

  cierre     cuanto se "engordan" los cuadros para unir partes sueltas del mismo
             sprite (9 para hojas espaciadas, 3 si los sprites estan muy juntos)
  tolerancia distancia al color de fondo a partir de la cual se considera sprite
"""
import json
import sys

import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage

RUTA = sys.argv[1]
SALIDA_CONTACTO = sys.argv[2]
SALIDA_JSON = sys.argv[3]

CIERRE = int(sys.argv[4]) if len(sys.argv) > 4 else 9
TOLERANCIA = int(sys.argv[5]) if len(sys.argv) > 5 else 70
AREA_MINIMA = 120    # descarta motas

img = Image.open(RUTA).convert("RGB")
a = np.asarray(img).astype(np.int16)
h, w, _ = a.shape

fondo = np.median(a[:6, :6].reshape(-1, 3), axis=0)
dist = np.sqrt(((a - fondo) ** 2).sum(axis=2))
mask = dist > TOLERANCIA

# Cierre morfologico: une partes separadas del mismo sprite.
estructura = np.ones((CIERRE, CIERRE), bool)
cerrada = ndimage.binary_closing(mask, structure=estructura)
if CIERRE >= 7:
    cerrada = ndimage.binary_dilation(cerrada, structure=np.ones((5, 5), bool))

etiquetas, n = ndimage.label(cerrada)
cajas = []
for i, corte in enumerate(ndimage.find_objects(etiquetas), start=1):
    ys, xs = corte
    sub = mask[ys, xs]
    if sub.sum() < AREA_MINIMA:
        continue
    # Recorta la caja al contenido real (sin la dilatacion).
    filas = np.where(sub.any(axis=1))[0]
    cols = np.where(sub.any(axis=0))[0]
    y0 = ys.start + filas[0]
    y1 = ys.start + filas[-1] + 1
    x0 = xs.start + cols[0]
    x1 = xs.start + cols[-1] + 1
    if (x1 - x0) < 12 or (y1 - y0) < 12:
        continue
    cajas.append([int(x0), int(y0), int(x1 - x0), int(y1 - y0)])

# Ordena por filas visuales y luego por x.
cajas.sort(key=lambda c: (c[1], c[0]))
filas = []
for c in cajas:
    for fila in filas:
        if abs(fila[0][1] - c[1]) < 60:
            fila.append(c)
            break
    else:
        filas.append([c])
ordenadas = []
for fila in filas:
    fila.sort(key=lambda c: c[0])
    ordenadas.extend(fila)

contacto = img.copy()
d = ImageDraw.Draw(contacto)
for i, (x, y, cw, ch) in enumerate(ordenadas):
    d.rectangle([x - 2, y - 2, x + cw + 1, y + ch + 1], outline=(0, 255, 0), width=3)
    d.text((x, max(0, y - 22)), str(i), fill=(255, 255, 0))
contacto.save(SALIDA_CONTACTO)

json.dump({"fondo": [int(v) for v in fondo], "cajas": ordenadas},
          open(SALIDA_JSON, "w"), indent=1)

print(f"imagen {w}x{h}  fondo={fondo.tolist()}  sprites detectados={len(ordenadas)}")
for i, (x, y, cw, ch) in enumerate(ordenadas):
    print(f"{i:3d}  x={x:5d} y={y:5d}  {cw:4d}x{ch:4d}")
