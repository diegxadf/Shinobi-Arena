"""Extrae de todo.png los objetos del juego (ventanas, ladrillo, pastel, letrero).

Uso: python herramientas/4_extraer_objetos.py [carpeta_destino]

A diferencia de los personajes, cada objeto es un recorte fijo de la hoja: aqui
estan sus coordenadas. La ventana rota no existe en la hoja, asi que se genera a
partir de la intacta oscureciendo el cristal y dibujando las grietas, para que
mantenga exactamente el mismo marco y la misma paleta.
"""
import os
import random
import sys

import numpy as np
from PIL import Image, ImageDraw

HOJA = "todo.png"
DESTINO = sys.argv[1] if len(sys.argv) > 1 else "images"

# Colores de fondo de la hoja que hay que volver transparentes.
GRIS_CELDA = (72, 72, 85)
GRIS_HOJA = (144, 144, 168)
PARED = (255, 220, 170)

CRISTAL = (176, 232, 240)          # celeste del vidrio
CRISTAL_ROTO = (32, 26, 48)        # hueco oscuro
GRIETA = (150, 220, 235)

hoja = Image.open(HOJA).convert("RGB")


def recortar(caja, fondos, escala=1):
    """Corta un rectangulo, vuelve transparentes los fondos y lo amplia."""
    trozo = hoja.crop(caja).convert("RGBA")
    a = np.asarray(trozo).astype(int)

    alfa = np.full(a.shape[:2], 255, np.uint8)
    for color in fondos:
        parecido = (np.abs(a[:, :, :3] - np.array(color)).sum(axis=2) < 30)
        alfa[parecido] = 0

    img = Image.fromarray(np.dstack([a[:, :, :3].astype(np.uint8), alfa]), "RGBA")
    if escala != 1:
        img = img.resize((int(img.width * escala), int(img.height * escala)),
                         Image.NEAREST if escala > 1 else Image.BOX)
    return img


def romper_ventana(intacta):
    """Misma ventana, con el cristal reventado."""
    a = np.asarray(intacta).astype(int)
    vidrio = (np.abs(a[:, :, :3] - np.array(CRISTAL)).sum(axis=2) < 90) & (a[:, :, 3] > 0)

    # Tambien cuenta el brillo blanco dibujado sobre el cristal.
    claro = (a[:, :, :3].min(axis=2) > 200) & (a[:, :, 3] > 0)
    hueco = vidrio | claro

    rgb = a[:, :, :3].copy()
    rgb[hueco] = CRISTAL_ROTO
    rota = Image.fromarray(np.dstack([rgb, a[:, :, 3]]).astype(np.uint8), "RGBA")

    filas = np.where(hueco.any(axis=1))[0]
    cols = np.where(hueco.any(axis=0))[0]
    x0, x1 = int(cols[0]), int(cols[-1])
    y0, y1 = int(filas[0]), int(filas[-1])

    d = ImageDraw.Draw(rota)
    d.line([(x0 + 1, y0 + 1), (x1 - 1, y1 - 1)], fill=GRIETA, width=1)
    d.line([(x1 - 1, y0 + 1), (x0 + 1, y1 - 1)], fill=GRIETA, width=1)
    d.line([((x0 + x1) // 2, y0), ((x0 + x1) // 3, y1)], fill=GRIETA, width=1)
    return rota


def apagar(img):
    """Version apagada del letrero: sin color y oscurecida, como sin corriente.

    El rotulo de la hoja ya viene encendido, asi que lo que se fabrica es el
    estado bloqueado, que es el contrario.
    """
    a = np.asarray(img).astype(float)
    gris = a[:, :, :3].mean(axis=2)
    rgb = np.clip(np.dstack([gris, gris, gris * 1.1]) * 0.45 + 18, 0, 255)
    return Image.fromarray(np.dstack([rgb, a[:, :, 3]]).astype(np.uint8), "RGBA")


os.makedirs(DESTINO, exist_ok=True)


def guardar(img, nombre):
    img.save(os.path.join(DESTINO, nombre + ".png"))
    print(f"  {nombre:18s} {img.width}x{img.height}")


# --- Ventanas: una hoja de la fachada, al doble de tamano ---
ventana = recortar((37, 657, 61, 682), [PARED, GRIS_HOJA], escala=2)
guardar(ventana, "ventana_intacta")
guardar(romper_ventana(ventana), "ventana_rota")

# --- Proyectiles de los vecinos ---
guardar(recortar((251, 407, 267, 423), [GRIS_CELDA, GRIS_HOJA]), "ladrillo")
guardar(recortar((287, 407, 303, 423), [GRIS_CELDA, GRIS_HOJA]), "pastel")

# --- Letrero de la azotea: el rotulo del juego, a la mitad ---
# El rotulo ocupa hasta x=176; mas a la derecha ya empieza otra cosa de la hoja.
letrero = recortar((1, 841, 176, 938), [GRIS_HOJA], escala=0.5)
guardar(apagar(letrero), "letrero")          # cima bloqueada
guardar(letrero, "letrero_activo")           # cima disponible

# --- Viga: no existe en la hoja, se construye apilando la textura de ladrillo ---
def columna_de_ladrillo(alto):
    """Pilar de ladrillo, repitiendo verticalmente un trozo del muro de la hoja."""
    tira = hoja.crop((323, 407, 339, 423)).convert("RGBA")   # 16x16 del muro rojo
    col = Image.new("RGBA", (tira.width, alto), (0, 0, 0, 0))
    for y in range(0, alto, tira.height):
        col.alpha_composite(tira, (0, y))
    return col.crop((0, 0, tira.width, alto))


VIGA_ALTO = 74
viga = columna_de_ladrillo(VIGA_ALTO)
guardar(viga, "viga")

# La viga rota deja solo un monton de cascotes apagados en la base.
escombro = Image.new("RGBA", (viga.width, VIGA_ALTO), (0, 0, 0, 0))
escombro.alpha_composite(viga.crop((0, 0, viga.width, 14)), (0, VIGA_ALTO - 14))
sombra = np.asarray(escombro).astype(float)
sombra[:, :, :3] *= 0.55
guardar(Image.fromarray(sombra.astype(np.uint8), "RGBA"), "viga_rota")

# --- Lodo: franja del ancho del charco, con la textura del monton de tierra ---
def franja_de_lodo(ancho, alto):
    """Rellena el charco copiando trozos sueltos del monton de tierra de la hoja.

    Dibujarlo como un rectangulo liso se notaba mucho. Repetir siempre el mismo
    trozo tampoco vale: se ve la cuadricula. Por eso cada trozo se toma de un
    sitio distinto del monton, con una semilla fija para que el charco salga
    igual en todas las partidas.
    """
    azar = random.Random(7)
    lado = 16
    franja = Image.new("RGBA", (ancho, alto), (0, 0, 0, 0))

    for x in range(0, ancho, lado):
        for y in range(0, alto, lado):
            sx = azar.randrange(198, 230)          # interior macizo del monton
            sy = azar.randrange(902, 920)
            trozo = hoja.crop((sx, sy, sx + lado, sy + lado)).convert("RGBA")
            franja.alpha_composite(trozo, (x, y))

    # Borde superior irregular, con tramos de distinta altura.
    perfil = []
    while len(perfil) < ancho:
        perfil += [azar.randrange(0, 6)] * azar.randrange(4, 12)

    pixeles = franja.load()
    for x in range(ancho):
        for y in range(perfil[x]):
            pixeles[x, y] = (0, 0, 0, 0)

    # Charcos oscuros repartidos por la superficie.
    d = ImageDraw.Draw(franja)
    for cx, cy, rx in [(70, 15, 20), (250, 21, 13), (430, 13, 24), (600, 19, 15)]:
        d.ellipse([cx - rx, cy - 4, cx + rx, cy + 4], fill=(92, 55, 32, 200))
    return franja


guardar(franja_de_lodo(660, 30), "lodo")

# --- Cartel del vertedero, decoracion junto al charco ---
guardar(recortar((210, 840, 236, 878), [(0, 0, 0), GRIS_HOJA]), "cartel_lodo")

print("Listo: todo el arte sale de las hojas.")
