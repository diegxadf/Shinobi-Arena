"""Mosaico numerado con cada cuadro detectado, para elegir cual es cual.

Uso: python 2_mosaico.py <hoja.jpg> <cajas.json> <salida.png> [desde] [hasta]
"""
import json
import sys

from PIL import Image, ImageDraw

RUTA, JSON_CAJAS, SALIDA = sys.argv[1], sys.argv[2], sys.argv[3]
DESDE = int(sys.argv[4]) if len(sys.argv) > 4 else 0
HASTA = int(sys.argv[5]) if len(sys.argv) > 5 else 10 ** 6

CELDA = 150
COLS = 8

img = Image.open(RUTA).convert("RGB")
datos = json.load(open(JSON_CAJAS))
cajas = [(i, c) for i, c in enumerate(datos["cajas"]) if DESDE <= i < HASTA]

filas = (len(cajas) + COLS - 1) // COLS
salida = Image.new("RGB", (COLS * CELDA, filas * (CELDA + 18)), (20, 20, 30))
d = ImageDraw.Draw(salida)

for n, (i, (x, y, w, h)) in enumerate(cajas):
    recorte = img.crop((x, y, x + w, y + h))
    escala = min((CELDA - 8) / w, (CELDA - 8) / h)
    recorte = recorte.resize((max(1, int(w * escala)), max(1, int(h * escala))),
                             Image.NEAREST)
    cx = (n % COLS) * CELDA + (CELDA - recorte.width) // 2
    cy = (n // COLS) * (CELDA + 18) + 18 + (CELDA - recorte.height) // 2
    salida.paste(recorte, (cx, cy))
    d.text(((n % COLS) * CELDA + 6, (n // COLS) * (CELDA + 18) + 4),
           f"{i}  {w}x{h}", fill=(255, 255, 0))

salida.save(SALIDA)
print(f"mosaico con {len(cajas)} sprites -> {SALIDA}")
