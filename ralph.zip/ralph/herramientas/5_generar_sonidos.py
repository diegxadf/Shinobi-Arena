"""Genera los efectos de sonido del juego, al estilo de una recreativa de 8 bits.

Uso: python herramientas/5_generar_sonidos.py [carpeta_destino]

No se usan grabaciones del arcade original (tienen derechos): cada efecto se
sintetiza aqui con ondas cuadradas y ruido, que es justo como sonaban aquellas
maquinas. Todo es determinista, asi que el resultado es identico cada vez.
"""
import os
import sys
import wave

import numpy as np

DESTINO = sys.argv[1] if len(sys.argv) > 1 else "sounds"
FRECUENCIA = 22050          # ritmo de muestreo bajo, como el hardware de la epoca
BITS_FALSOS = 6             # se cuantiza la senal para que suene "sucia"

# Notas que se usan en las melodias (en Hz).
NOTA = {"do": 523, "re": 587, "mi": 659, "fa": 698, "sol": 784,
        "la": 880, "si": 988, "do2": 1047, "mi2": 1319, "sol2": 1568}


# ---------------------------------------------------------------- generadores

def cuadrada(freq, dur, ciclo=0.5, vol=0.6):
    """Onda cuadrada: el sonido basico de las consolas de 8 bits."""
    t = np.arange(int(FRECUENCIA * dur)) / FRECUENCIA
    return np.where((t * freq) % 1.0 < ciclo, vol, -vol)


def barrido(desde, hasta, dur, ciclo=0.5, vol=0.6):
    """Onda cuadrada que cambia de tono: sirve para saltos y golpes."""
    n = int(FRECUENCIA * dur)
    frecuencias = np.linspace(desde, hasta, n)
    fase = np.cumsum(frecuencias) / FRECUENCIA
    return np.where(fase % 1.0 < ciclo, vol, -vol)


def ruido(dur, vol=0.5, semilla=1):
    """Ruido blanco: impactos, cristales y salpicaduras."""
    azar = np.random.default_rng(semilla)
    return azar.uniform(-vol, vol, int(FRECUENCIA * dur))


def sobre(onda, ataque=0.004, curva=1.6):
    """Envolvente: subida rapida y caida suave, para que no suene a chasquido."""
    n = len(onda)
    e = np.ones(n)
    a = max(1, int(FRECUENCIA * ataque))
    e[:a] = np.linspace(0, 1, a)
    e[a:] = np.linspace(1, 0, n - a) ** curva
    return onda * e


def grave(onda, ventana=10):
    """Filtro paso bajo casero: quita agudos y deja un golpe sordo."""
    return np.convolve(onda, np.ones(ventana) / ventana, mode="same")


def melodia(notas, dur=0.07, ciclo=0.5, vol=0.5):
    """Encadena notas cortas: las fanfarrias del arcade son asi de simples."""
    return np.concatenate([sobre(cuadrada(NOTA[n], dur, ciclo, vol), curva=1.1)
                           for n in notas])


def juntar(*ondas):
    """Suma varias ondas alineadas al principio."""
    largo = max(len(o) for o in ondas)
    suma = np.zeros(largo)
    for o in ondas:
        suma[:len(o)] += o
    return suma


def silencio(dur):
    return np.zeros(int(FRECUENCIA * dur))


def quitar_continua(onda):
    """Elimina la componente continua.

    Una onda cuadrada con ciclo distinto de 0.5 no esta centrada en cero: eso se
    oye como un chasquido al empezar y al acabar, y ademas se come volumen util.
    """
    onda = onda - onda.mean()

    salida = np.zeros_like(onda)
    anterior_entrada = 0.0
    anterior_salida = 0.0
    for i, v in enumerate(onda):
        anterior_salida = v - anterior_entrada + 0.995 * anterior_salida
        anterior_entrada = v
        salida[i] = anterior_salida
    return salida


def guardar(nombre, onda, nivel=0.85):
    """Centra, iguala el volumen, cuantiza y escribe el WAV que lee Greenfoot."""
    onda = quitar_continua(onda)

    pico = np.abs(onda).max()
    if pico > 0:
        onda = onda / pico * nivel

    niveles = 2 ** BITS_FALSOS
    onda = np.round(onda * niveles) / niveles

    datos = (np.clip(onda, -1, 1) * 32767).astype("<i2")
    ruta = os.path.join(DESTINO, nombre)
    with wave.open(ruta, "w") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(FRECUENCIA)
        w.writeframes(datos.tobytes())
    print(f"  {nombre:18s} {len(onda) / FRECUENCIA:.2f} s   pico {nivel:.2f}")


# ---------------------------------------------------------------- los efectos

os.makedirs(DESTINO, exist_ok=True)

# Salto: tono que sube deprisa.
guardar("salto.wav", sobre(barrido(190, 560, 0.13, ciclo=0.35), curva=1.2))

# Punetazo de Ralph contra el edificio: golpe sordo con cuerpo grave.
guardar("golpe.wav", sobre(juntar(grave(ruido(0.09, 0.7, 3), 6),
                                  barrido(150, 60, 0.10, vol=0.5)), curva=2.0))

# Ventana que revienta: el golpe mas tres esquirlas agudas.
esquirlas = np.concatenate([sobre(cuadrada(f, 0.03, 0.25, 0.35), curva=2.0)
                            for f in (1500, 1900, 1200)])
guardar("romper.wav", juntar(sobre(ruido(0.22, 0.6, 5), curva=1.8),
                             np.concatenate([silencio(0.03), esquirlas])))

# Viga que se derrumba: retumbo grave y largo.
guardar("viga_cae.wav", sobre(juntar(grave(ruido(0.55, 0.9, 7), 18),
                                     barrido(120, 35, 0.5, vol=0.45)), curva=1.4))

# Martillazo de Felix reparando: el arpegio corto de "arreglado".
guardar("reparar.wav", melodia(["do", "mi", "sol"], dur=0.055, ciclo=0.25))

# Martillazo de Felix contra Ralph: zumbido que cae.
guardar("martillazo.wav", sobre(barrido(520, 120, 0.22, ciclo=0.2, vol=0.55),
                                curva=1.5))

# Ladrillo de los vecinos: impacto seco y tono descendente.
guardar("ladrillo.wav", sobre(juntar(ruido(0.06, 0.6, 11),
                                     barrido(340, 110, 0.16, vol=0.5)), curva=1.6))

# Pastel: salpicadura blanda, sin agudos.
guardar("pastel.wav", sobre(grave(ruido(0.25, 0.8, 13), 22), curva=1.3),
        nivel=0.70)

# Chapuzon final en el lodo.
guardar("chapuzon.wav", sobre(juntar(grave(ruido(0.45, 0.9, 17), 26),
                                     barrido(90, 40, 0.4, vol=0.4)), curva=1.2))

# La cima se desbloquea: aviso ascendente de dos notas.
guardar("cima.wav", melodia(["sol", "do2"], dur=0.09, ciclo=0.4))

# Letrero derribado: estruendo con brillo.
guardar("letrero.wav", juntar(sobre(ruido(0.4, 0.8, 19), curva=1.5),
                              np.concatenate([silencio(0.05),
                                              melodia(["do2", "sol", "do2"], 0.08)])))

# Victoria: fanfarria.
guardar("victoria.wav", melodia(["do", "mi", "sol", "do2", "sol", "do2", "mi2"],
                                dur=0.11, ciclo=0.35), nivel=0.95)

# Derrota: la misma idea, pero cayendo.
guardar("derrota.wav", melodia(["sol", "mi", "do", "do"], dur=0.16, ciclo=0.45,
                               vol=0.45))

# Paso de Ralph: muy corto y grave, porque suena muchas veces.
guardar("paso.wav", sobre(grave(ruido(0.05, 0.35, 23), 12), curva=2.2),
        nivel=0.30)

print(f"\n{len(os.listdir(DESTINO))} sonidos en {DESTINO}/")
