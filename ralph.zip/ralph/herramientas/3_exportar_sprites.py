"""Recorta una hoja de sprites y exporta los PNG que espera el juego.

Uso: python 3_exportar_sprites.py <config.json>

El fichero de configuracion indica de que hoja sale cada archivo:

{
  "hoja":   "hoja_sprites_ralph.jpg",
  "cajas":  "herramientas/cajas_ralph.json",
  "destino": "images",
  "alto":    62,          alto del lienzo comun (o "x1" / "x2" para escalar sin resamplear)
  "fondo":   "color",     "color" = quita todo lo que se parezca al fondo
                          "borde" = quita solo el fondo pegado al borde (para hojas
                                    con fondo negro, que respeta los negros del dibujo)
  "tolerancia": 85,
  "mapa":   { "ralph_idle": [4, false] },     archivo -> [numero de cuadro, espejar]
  "aparte": { "ralph_lodo": [22, false] }     cuadros con lienzo propio
}

Que hace, y por que:
- quita el fondo (canal alfa real)
- escala TODOS los cuadros con el mismo factor
- alto identico en todos: el codigo apoya al personaje con pies = centro + ALTO/2
- ancho por pose, centrando siempre la cadera, para que el cuerpo no salte
"""
import json
import os
import sys

import numpy as np
from PIL import Image
from scipy import ndimage

CONFIG = json.load(open(sys.argv[1], encoding="utf-8"))

HOJA = CONFIG["hoja"]
DESTINO = CONFIG["destino"]
MODO_FONDO = CONFIG.get("fondo", "color")
TOLERANCIA = CONFIG.get("tolerancia", 85)
MAPA = {k: tuple(v) for k, v in CONFIG["mapa"].items()}
APARTE = {k: tuple(v) for k, v in CONFIG.get("aparte", {}).items()}

ALFA_CORTE = 120

hoja = Image.open(HOJA).convert("RGB")
datos = json.load(open(CONFIG["cajas"], encoding="utf-8"))
cajas = datos["cajas"]
fondo = np.array(datos["fondo"], dtype=np.float64)


def recortar(indice, espejar):
    x, y, w, h = cajas[indice]
    trozo = np.asarray(hoja.crop((x, y, x + w, y + h))).astype(np.float64)
    dist = np.sqrt(((trozo - fondo) ** 2).sum(axis=2))

    if MODO_FONDO == "borde":
        alfa = alfa_por_borde(dist)
    else:
        alfa = np.where(dist > TOLERANCIA, 255, 0).astype(np.uint8)
        alfa = quitar_motas(alfa)

    img = Image.fromarray(np.dstack([trozo.astype(np.uint8), alfa]), "RGBA")
    if espejar:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
    return ajustar(img)


def alfa_por_borde(dist):
    """Solo es fondo lo que tiene el color del fondo Y toca el borde del recorte.

    Asi un negro encerrado dentro del dibujo (ojos, sombras) no se vuelve un agujero.
    """
    parecido = dist <= TOLERANCIA
    etiquetas, n = ndimage.label(parecido)
    if n == 0:
        return np.full(dist.shape, 255, np.uint8)

    borde = set(etiquetas[0, :]) | set(etiquetas[-1, :]) \
            | set(etiquetas[:, 0]) | set(etiquetas[:, -1])
    borde.discard(0)

    fuera = np.isin(etiquetas, list(borde))
    return np.where(fuera, 0, 255).astype(np.uint8)


def quitar_motas(alfa, minimo=60):
    """El JPEG deja puntos sueltos alrededor del sprite: se descartan."""
    etiquetas, n = ndimage.label(alfa > 0)
    if n <= 1:
        return alfa
    tam = ndimage.sum(alfa > 0, etiquetas, range(1, n + 1))
    grandes = np.isin(etiquetas, [i + 1 for i, t in enumerate(tam) if t >= minimo])
    return np.where(grandes, alfa, 0).astype(np.uint8)


def ajustar(img):
    alfa = np.asarray(img)[:, :, 3]
    filas = np.where(alfa.any(axis=1))[0]
    cols = np.where(alfa.any(axis=0))[0]
    return img.crop((cols[0], filas[0], cols[-1] + 1, filas[-1] + 1))


def reducir(img, escala):
    """Reduce promediando; con escala 1 no toca nada (no se pierde nitidez)."""
    if abs(escala - 1.0) < 1e-6:
        return img

    ancho = max(1, round(img.width * escala))
    alto = max(1, round(img.height * escala))

    if escala > 1:                       # ampliar sin difuminar
        return img.resize((ancho, alto), Image.NEAREST)

    a = np.asarray(img).astype(np.float64)
    pre = np.dstack([a[:, :, :3] * (a[:, :, 3:] / 255.0), a[:, :, 3:]])
    chico = np.asarray(Image.fromarray(pre.astype(np.uint8), "RGBA")
                       .resize((ancho, alto), Image.BOX)).astype(np.float64)

    alfa = chico[:, :, 3]
    visible = alfa > 1
    color = np.zeros_like(chico[:, :, :3])
    color[visible] = chico[:, :, :3][visible] / (alfa[visible][:, None] / 255.0)

    duro = np.where(alfa >= ALFA_CORTE, 255, 0)
    return Image.fromarray(np.dstack([np.clip(color, 0, 255), duro]).astype(np.uint8),
                           "RGBA")


def centro_de_cadera(img):
    """Centro horizontal de la franja de la cadera: es lo que menos se mueve."""
    alfa = np.asarray(img)[:, :, 3]
    alto = alfa.shape[0]
    banda = alfa[int(alto * 0.50):int(alto * 0.80), :]
    cols = np.where(banda.any(axis=0))[0]
    if len(cols) == 0:
        cols = np.where(alfa.any(axis=0))[0]
    return (cols[0] + cols[-1] + 1) / 2.0


def guardar(img, ancla, nombre, alto_lienzo):
    mitad = int(np.ceil(max(ancla, img.width - ancla)))
    lienzo = Image.new("RGBA", (mitad * 2, alto_lienzo), (0, 0, 0, 0))
    lienzo.alpha_composite(img, (int(round(mitad - ancla)), alto_lienzo - img.height))
    lienzo.save(os.path.join(DESTINO, nombre + ".png"))
    return lienzo


os.makedirs(DESTINO, exist_ok=True)
crudos = {n: recortar(*v) for n, v in MAPA.items()}
alto_maximo = max(img.height for img in crudos.values())

alto = CONFIG["alto"]
if isinstance(alto, str) and alto.startswith("x"):
    escala = float(alto[1:])
    alto_lienzo = int(round(alto_maximo * escala))
else:
    alto_lienzo = int(alto)
    escala = alto_lienzo / alto_maximo

print(f"{HOJA}:  escala={escala:.4f}  lienzo de alto {alto_lienzo}")
anchos = {}
for nombre in sorted(crudos):
    chico = reducir(crudos[nombre], escala)
    ancla = centro_de_cadera(chico)
    salida = guardar(chico, ancla, nombre, alto_lienzo)
    anchos[nombre] = salida.width
    print(f"  {nombre:16s} {chico.width:3d}x{chico.height:3d}"
          f"  cadera x={ancla:5.1f}  ->  {salida.width}x{salida.height}")

for nombre, (indice, espejar) in APARTE.items():
    chico = reducir(recortar(indice, espejar), escala)
    chico.save(os.path.join(DESTINO, nombre + ".png"))
    print(f"  {nombre:16s} {chico.width:3d}x{chico.height:3d}  (lienzo propio)")

principal = sorted(anchos)[0]
print(f"\nALTO para el codigo = {alto_lienzo}   ANCHO (cuadro base) = "
      f"{anchos.get('ralph_idle', anchos.get('felix_idle', anchos[principal]))}")
