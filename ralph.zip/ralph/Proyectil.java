import greenfoot.*;

/**
 * Objeto que los vecinos lanzan desde las ventanas contra Ralph.
 *
 * Cae con la misma ecuacion cuadratica que usan los personajes:
 *     y(t) = y0 - v0*t + 0.5*g*t^2
 *
 * Cada subclase solo decide su imagen y el efecto que provoca al impactar.
 */
public abstract class Proyectil extends Actor
{
    private final double velocidadInicial;
    private final double gravedad;
    private final int giro;

    /** Ciclos que el objeto asoma por la ventana antes de caer. */
    private static final int AVISO = 30;

    private int tiempo = 0;
    private int yInicial = 0;
    private boolean iniciado = false;
    private int aviso = AVISO;

    protected Proyectil(double velocidadInicial, double gravedad, int giro)
    {
        this.velocidadInicial = velocidadInicial;
        this.gravedad = gravedad;
        this.giro = giro;
    }

    protected void addedToWorld(World mundo)
    {
        yInicial = getY();
        iniciado = true;
    }

    public void act()
    {
        // Tras impactar, el proyectil ya se quito del mundo.
        if (!iniciado || getWorld() == null)
        {
            return;
        }

        if (aviso > 0)
        {
            asomarse();
            return;
        }

        caer();
        comprobarImpacto();
        comprobarSalida();
    }

    /**
     * El objeto se queda un momento parpadeando en la ventana.
     *
     * Sin este aviso caia en un cuarto de segundo y era imposible de esquivar,
     * asi que el jugador perdia energia sin entender de donde venia.
     */
    private void asomarse()
    {
        aviso--;
        getImage().setTransparency((aviso / 4) % 2 == 0 ? 255 : 110);

        if (aviso == 0)
        {
            getImage().setTransparency(255);
        }
    }

    private void caer()
    {
        tiempo++;

        double y = yInicial
                   - velocidadInicial * tiempo
                   + 0.5 * gravedad * tiempo * tiempo;

        setLocation(getX(), (int) y);
        setRotation(getRotation() + giro);
    }

    private void comprobarImpacto()
    {
        Mundo mundo = (Mundo) getWorld();
        Ralph ralph = (Ralph) getOneIntersectingObject(Ralph.class);

        if (ralph != null && mundo.estaActivo())
        {
            efecto(ralph);
            mundo.removeObject(this);
        }
    }

    private void comprobarSalida()
    {
        if (getWorld() != null && getY() > Mundo.ALTO - 10)
        {
            getWorld().removeObject(this);
        }
    }

    /** Que le hace este proyectil a Ralph. */
    protected abstract void efecto(Ralph ralph);
}
