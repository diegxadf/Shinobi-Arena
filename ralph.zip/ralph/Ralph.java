import greenfoot.*;

/**
 * Ralph: el personaje que controla el jugador.
 *
 * Sube por el edificio destruyendo ventanas y vigas para llenar la barra de
 * DANO, mientras Felix repara y los vecinos le lanzan ladrillos y pasteles.
 *
 * Controles:
 *   flechas izquierda/derecha .. caminar
 *   espacio o flecha arriba ... saltar (trayectoria parabolica)
 *   flecha abajo ............. bajar un piso
 *   F ........................ golpear (ventana, viga o letrero de la azotea)
 */
public class Ralph extends Personaje
{
    // Tamano del lienzo de los sprites recortados de la hoja (ver images/).
    public static final int ANCHO = 42;
    public static final int ALTO  = 62;

    // Ajustes del personaje (utiles para los experimentos de la guia).
    private static final int    VELOCIDAD_HORIZONTAL = 5;
    private static final double VELOCIDAD_INICIAL    = 14.5;  // v0: llega a la azotea
    private static final double GRAVEDAD             = 1.0;   // g
    private static final int    CICLOS_POR_FRAME     = 6;

    private static final int ALCANCE_GOLPE     = 50;
    private static final int DURACION_GOLPE    = 16;
    private static final int DURACION_ATURDIDO = 55;
    private static final int DURACION_PASTEL   = 150;
    private static final int INVULNERABLE      = 70;
    private static final int DURACION_CHAPUZON   = 60;    // ciclos hundido en el lodo

    public static final int SALUD_MAXIMA = 100;

    private enum Estado
    {
        QUIETO,
        CAMINANDO_DERECHA,
        CAMINANDO_IZQUIERDA,
        SALTANDO,
        CAYENDO,
        GOLPEANDO,
        ATURDIDO,
        DERROTADO
    }

    private Estado estado = Estado.QUIETO;
    private boolean mirandoIzquierda = false;

    // ---------- Imagenes ----------
    private GreenfootImage quietoDer, quietoIzq;
    private GreenfootImage[] caminarDer, caminarIzq;
    private GreenfootImage saltoDer, saltoIzq;
    private GreenfootImage caidaDer, caidaIzq;
    private GreenfootImage[] golpeDer, golpeIzq;
    private GreenfootImage aturdido;
    private GreenfootImage lodo;

    private int frameActual = 0;
    private int contadorAnimacion = 0;

    // ---------- Estado de combate ----------
    private int salud = SALUD_MAXIMA;
    private int contadorGolpe = 0;
    private boolean golpeAplicado = false;
    private int contadorAturdido = 0;
    private int contadorPastel = 0;
    private int invulnerable = 0;

    // ---------- Caida final al lodo ----------
    private boolean cayendoAlLodo = false;
    private boolean enLodo = false;
    private int contadorLodo = 0;
    private int tiempoCaidaLodo = 0;
    private int yInicialLodo = 0;

    public Ralph()
    {
        super(ANCHO, ALTO, VELOCIDAD_INICIAL, GRAVEDAD);
        cargarImagenes();
    }

    // ------------------------------------------------------------------
    // Imagenes
    // ------------------------------------------------------------------

    private void cargarImagenes()
    {
        quietoDer = Recursos.cargar("ralph_idle.png", cuerpo(0));

        caminarDer = new GreenfootImage[4];
        caminarDer[0] = Recursos.cargar("ralph_walk1.png", cuerpo(0));
        caminarDer[1] = Recursos.cargar("ralph_walk2.png", cuerpo(1));
        caminarDer[2] = Recursos.cargar("ralph_walk3.png", cuerpo(0));
        caminarDer[3] = Recursos.cargar("ralph_walk4.png", cuerpo(1));

        saltoDer = Recursos.cargar("ralph_jump.png", cuerpo(1));
        caidaDer = Recursos.cargar("ralph_fall.png", cuerpo(0));

        golpeDer = new GreenfootImage[2];
        golpeDer[0] = Recursos.cargar("ralph_smash1.png", conPuno(0));
        golpeDer[1] = Recursos.cargar("ralph_smash2.png", conPuno(1));

        aturdido = Recursos.cargar("ralph_aturdido.png",
                   Recursos.personaje(ANCHO, ALTO, new Color(120, 70, 40),
                                                   new Color(220, 180, 150), 1));

        // Si no hay sprite del chapuzon, se reutiliza el de aturdido.
        lodo = Recursos.cargar("ralph_lodo.png", aturdido);

        quietoIzq  = espejo(quietoDer);
        saltoIzq   = espejo(saltoDer);
        caidaIzq   = espejo(caidaDer);
        caminarIzq = espejo(caminarDer);
        golpeIzq   = espejo(golpeDer);

        setImage(quietoDer);
    }

    private GreenfootImage cuerpo(int fase)
    {
        return Recursos.personaje(ANCHO, ALTO, new Color(160, 90, 50),
                                               new Color(240, 200, 170), fase);
    }

    /**
     * Sprite provisional de golpe: Ralph destroza con los PUNOS, cuerpo a cuerpo.
     * No lanza nada: los unicos proyectiles del juego son los de los vecinos.
     */
    private GreenfootImage conPuno(int fase)
    {
        GreenfootImage img = cuerpo(1);
        Color piel = new Color(240, 200, 170);
        Color borde = new Color(90, 50, 25);

        // Fase 0: punos recogidos. Fase 1: impacto, extendidos al maximo.
        int lado = 14;
        int retraccion = (fase == 0) ? 12 : 0;

        for (int i = 0; i < 2; i++)
        {
            int x = ANCHO - lado - retraccion - i * 5;
            int y = ALTO / 3 + i * 12;

            img.setColor(piel);
            img.fillRect(x, y, lado, lado);
            img.setColor(borde);
            img.drawRect(x, y, lado - 1, lado - 1);
        }
        return img;
    }

    private GreenfootImage espejo(GreenfootImage original)
    {
        GreenfootImage copia = new GreenfootImage(original);
        copia.mirrorHorizontally();
        return copia;
    }

    private GreenfootImage[] espejo(GreenfootImage[] originales)
    {
        GreenfootImage[] copias = new GreenfootImage[originales.length];
        for (int i = 0; i < originales.length; i++)
        {
            copias[i] = espejo(originales[i]);
        }
        return copias;
    }

    // ------------------------------------------------------------------
    // Ciclo principal
    // ------------------------------------------------------------------

    public void act()
    {
        if (enLodo)
        {
            reposarEnLodo();
            return;
        }

        if (cayendoAlLodo)
        {
            caerAlLodo();
            actualizarAnimacion();
            return;
        }

        Mundo mundo = getMundo();
        if (mundo == null || mundo.estaTerminado())
        {
            return;
        }

        actualizarTemporizadores();

        if (aceptaEntrada())
        {
            controlarMovimientoHorizontal();
            controlarSalto();
            controlarDescenso();
            controlarGolpe();
        }

        actualizarVertical();
        actualizarAnimacion();
    }

    private boolean aceptaEntrada()
    {
        return estado != Estado.GOLPEANDO && estado != Estado.ATURDIDO;
    }

    private void actualizarTemporizadores()
    {
        if (invulnerable > 0)   { invulnerable--; }
        if (contadorPastel > 0) { contadorPastel--; }

        if (estado == Estado.GOLPEANDO)
        {
            contadorGolpe--;

            if (!golpeAplicado && contadorGolpe <= DURACION_GOLPE / 2)
            {
                golpeAplicado = true;
                aplicarGolpe();
            }
            if (contadorGolpe <= 0)
            {
                estado = estaEnAire() ? Estado.CAYENDO : Estado.QUIETO;
            }
        }
        else if (estado == Estado.ATURDIDO)
        {
            contadorAturdido--;
            if (contadorAturdido <= 0)
            {
                estado = estaEnAire() ? Estado.CAYENDO : Estado.QUIETO;
            }
        }
    }

    // ------------------------------------------------------------------
    // Entrada del jugador
    // ------------------------------------------------------------------

    private void controlarMovimientoHorizontal()
    {
        int velocidad = estaEmpastelado() ? VELOCIDAD_HORIZONTAL / 2
                                          : VELOCIDAD_HORIZONTAL;

        if (Greenfoot.isKeyDown("right"))
        {
            moverHorizontal(velocidad);
            mirandoIzquierda = false;
            if (!estaEnAire())
            {
                estado = Estado.CAMINANDO_DERECHA;
            }
        }
        else if (Greenfoot.isKeyDown("left"))
        {
            moverHorizontal(-velocidad);
            mirandoIzquierda = true;
            if (!estaEnAire())
            {
                estado = Estado.CAMINANDO_IZQUIERDA;
            }
        }
        else if (!estaEnAire())
        {
            estado = Estado.QUIETO;
        }
    }

    private void controlarSalto()
    {
        boolean tecla = Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("up");

        if (tecla && !estaEnAire())
        {
            Sonidos.reproducir("salto.wav");
            iniciarSalto();
        }
    }

    private void controlarDescenso()
    {
        if (Greenfoot.isKeyDown("down") && !estaEnAire() && pisoActual > 0)
        {
            iniciarCaida();
        }
    }

    /** Solo golpea con los pies en la repisa y sin un pastel encima. */
    private boolean puedeGolpearAhora()
    {
        return !estaEnAire() && !estaEmpastelado() && estado != Estado.ATURDIDO;
    }

    private void controlarGolpe()
    {
        if (!puedeGolpearAhora() || !Greenfoot.isKeyDown("f"))
        {
            return;
        }

        if (hayObjetivo())
        {
            estado = Estado.GOLPEANDO;
            contadorGolpe = DURACION_GOLPE;
            golpeAplicado = false;
            frameActual = 0;
            contadorAnimacion = 0;
        }
    }

    // ------------------------------------------------------------------
    // Destruccion
    // ------------------------------------------------------------------

    private boolean hayObjetivo()
    {
        return letreroAlAlcance() != null || vigaAlAlcance() != null
               || ventanaAlAlcance() != null;
    }

    /** Prioridad: letrero de la azotea, luego viga, luego ventana. */
    private void aplicarGolpe()
    {
        Letrero letrero = letreroAlAlcance();
        if (letrero != null)
        {
            Sonidos.reproducir("golpe.wav");
            letrero.recibirGolpe();
            return;
        }

        Viga viga = vigaAlAlcance();
        if (viga != null)
        {
            Sonidos.reproducir("golpe.wav");
            viga.recibirGolpe();
            return;
        }

        Ventana ventana = ventanaAlAlcance();
        if (ventana != null)
        {
            Sonidos.reproducir("romper.wav");
            ventana.romper();
            getMundo().registrarDestrozo();
        }
    }

    private Ventana ventanaAlAlcance()
    {
        Mundo mundo = getMundo();

        for (int col = 0; col < Mundo.COLUMNAS; col++)
        {
            Ventana v = mundo.ventanaEn(pisoActual, col);
            if (v != null && !v.estaRota()
                && Math.abs(v.getX() - getX()) <= ALCANCE_GOLPE)
            {
                return v;
            }
        }
        return null;
    }

    private Viga vigaAlAlcance()
    {
        for (Viga viga : getWorld().getObjects(Viga.class))
        {
            if (!viga.estaDestruida() && viga.getPiso() == pisoActual
                && Math.abs(viga.getX() - getX()) <= ALCANCE_GOLPE)
            {
                return viga;
            }
        }
        return null;
    }

    private Letrero letreroAlAlcance()
    {
        for (Letrero letrero : getWorld().getObjects(Letrero.class))
        {
            if (pisoActual == Mundo.PISO_AZOTEA
                && Math.abs(letrero.getX() - getX()) <= ALCANCE_GOLPE)
            {
                return letrero;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------
    // Dano recibido
    // ------------------------------------------------------------------

    /** Ladrillo de los vecinos: quita energia y sacude a Ralph. */
    public void recibirLadrillo(int danio)
    {
        if (invulnerable > 0 || estado == Estado.DERROTADO)
        {
            return;
        }

        Sonidos.reproducir("ladrillo.wav");
        avisarDelGolpe(danio);
        salud -= danio;
        invulnerable = INVULNERABLE;
        aturdir(DURACION_ATURDIDO / 2);
        comprobarEnergia();
    }

    /** Martillazo de Felix: congela a Ralph y lo debilita. */
    public void recibirMartillazo(int danio)
    {
        if (invulnerable > 0 || estado == Estado.DERROTADO)
        {
            return;
        }

        Sonidos.reproducir("martillazo.wav");
        avisarDelGolpe(danio);
        salud -= danio;
        invulnerable = INVULNERABLE;
        aturdir(DURACION_ATURDIDO);
        comprobarEnergia();
    }

    /** Pastel de los vecinos: no quita energia, pero ralentiza y estorba. */
    public void recibirPastel()
    {
        if (estado == Estado.DERROTADO)
        {
            return;
        }
        Sonidos.reproducir("pastel.wav");
        contadorPastel = DURACION_PASTEL;
    }

    /** Muestra sobre Ralph cuanta energia acaba de perder. */
    private void avisarDelGolpe(int danio)
    {
        if (getWorld() != null)
        {
            getWorld().addObject(new Aviso("-" + danio, new Color(255, 110, 110)),
                                 getX(), getY() - ALTO / 2);
        }
    }

    private void aturdir(int ciclos)
    {
        estado = Estado.ATURDIDO;
        contadorAturdido = ciclos;
        contadorGolpe = 0;
    }

    private void comprobarEnergia()
    {
        if (salud <= 0)
        {
            salud = 0;
            getMundo().derrota("Ralph se quedo sin energia y cayo del edificio");
        }
    }

    public boolean estaEmpastelado()
    {
        return contadorPastel > 0;
    }

    public int getSalud()
    {
        return salud;
    }

    // ------------------------------------------------------------------
    // Caida final al lodo
    // ------------------------------------------------------------------

    /** Lo llama el mundo cuando Ralph pierde: cae al charco de lodo. */
    public void arrojarAlLodo()
    {
        if (cayendoAlLodo)
        {
            return;
        }

        estado = Estado.DERROTADO;
        cayendoAlLodo = true;
        tiempoCaidaLodo = 0;
        yInicialLodo = getY();
    }

    private void caerAlLodo()
    {
        tiempoCaidaLodo++;

        double y = yInicialLodo
                   - 6.0 * tiempoCaidaLodo
                   + 0.5 * GRAVEDAD * tiempoCaidaLodo * tiempoCaidaLodo;

        int destino = Mundo.NIVEL_LODO - ALTO / 4;

        if (y >= destino)
        {
            // Queda hundido en el charco; el chapuzon se ve un momento antes
            // de que la partida se detenga.
            setLocation(getX(), Mundo.NIVEL_LODO + lodo.getHeight() / 2 - 4);
            setImage(lodo);
            Sonidos.reproducir("chapuzon.wav");
            cayendoAlLodo = false;
            enLodo = true;
            contadorLodo = DURACION_CHAPUZON;
            return;
        }

        setLocation(getX() + (mirandoIzquierda ? -1 : 1), (int) y);
    }

    /** Momento final: Ralph hundido en el lodo antes de cerrar la partida. */
    private void reposarEnLodo()
    {
        setImage(lodo);
        contadorLodo--;

        if (contadorLodo <= 0)
        {
            enLodo = false;
            getMundo().confirmarFinal();
        }
    }

    // ------------------------------------------------------------------
    // Avisos de la fisica (clase Personaje)
    // ------------------------------------------------------------------

    protected void alSubir()
    {
        if (estado != Estado.ATURDIDO && estado != Estado.DERROTADO)
        {
            estado = Estado.SALTANDO;
        }
    }

    protected void alCaer()
    {
        if (estado != Estado.ATURDIDO && estado != Estado.DERROTADO)
        {
            estado = Estado.CAYENDO;
        }
    }

    protected void alAterrizar()
    {
        if (estado == Estado.SALTANDO || estado == Estado.CAYENDO)
        {
            estado = Estado.QUIETO;
        }
    }

    // ------------------------------------------------------------------
    // Representacion visual: Estado -> Sprite
    // ------------------------------------------------------------------

    private void actualizarAnimacion()
    {
        switch (estado)
        {
            case QUIETO:
                mostrar(mirandoIzquierda ? quietoIzq : quietoDer);
                break;
            case CAMINANDO_DERECHA:
                animarCaminata(false);
                break;
            case CAMINANDO_IZQUIERDA:
                animarCaminata(true);
                break;
            case SALTANDO:
                mostrar(mirandoIzquierda ? saltoIzq : saltoDer);
                break;
            case CAYENDO:
                mostrar(mirandoIzquierda ? caidaIzq : caidaDer);
                break;
            case GOLPEANDO:
                animarGolpe();
                break;
            case ATURDIDO:
            case DERROTADO:
                mostrar(aturdido);
                break;
        }
    }

    private void animarCaminata(boolean izquierda)
    {
        contadorAnimacion++;

        if (contadorAnimacion >= CICLOS_POR_FRAME)
        {
            frameActual++;
            if (frameActual >= caminarDer.length)
            {
                frameActual = 0;
            }
            contadorAnimacion = 0;

            // Ralph pesa: se le oye el paso, pero solo en los cuadros de apoyo.
            if (!estaEnAire() && frameActual % 2 == 0)
            {
                Sonidos.reproducir("paso.wav");
            }
        }

        mostrar(izquierda ? caminarIzq[frameActual] : caminarDer[frameActual]);
    }

    private void animarGolpe()
    {
        int cuadro = (contadorGolpe > DURACION_GOLPE / 2) ? 0 : 1;
        mostrar(mirandoIzquierda ? golpeIzq[cuadro] : golpeDer[cuadro]);
    }

    /**
     * Muestra la imagen del estado actual. Parpadea tras recibir un golpe y se
     * tine de crema mientras el pastel lo tiene ralentizado.
     */
    private void mostrar(GreenfootImage base)
    {
        if (estaEmpastelado())
        {
            GreenfootImage copia = new GreenfootImage(base);
            copia.setColor(new Color(250, 245, 220, 130));
            copia.fillRect(0, 0, copia.getWidth(), copia.getHeight());
            setImage(copia);
            return;
        }

        if (invulnerable > 0 && (invulnerable / 4) % 2 == 0)
        {
            GreenfootImage copia = new GreenfootImage(base);
            copia.setTransparency(90);
            setImage(copia);
            return;
        }

        setImage(base);
    }
}
