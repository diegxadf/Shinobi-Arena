import greenfoot.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Banco de pruebas de la logica del juego, fuera del IDE de Greenfoot.
 *
 * No simula el teclado (Greenfoot.isKeyDown solo funciona dentro del IDE):
 * invoca directamente los metodos internos de los actores para comprobar la
 * fisica, la IA de Felix, los proyectiles de los vecinos y las condiciones de
 * victoria y derrota.
 *
 * Cada prueba que termina la partida usa su propio mundo.
 * Esta carpeta NO forma parte del escenario: Greenfoot solo compila los .java
 * de la raiz del proyecto.
 */
public class PruebaLogica
{
    private static int fallas = 0;

    public static void main(String[] args) throws Exception
    {
        prepararEntornoDePrueba();

        probarEscenario();
        probarPosicionInicial();
        probarRalphSubeDePiso();
        probarRalphLlegaALaAzotea();
        probarFelixNoSubeALaAzotea();
        probarRalphRompeVentana();
        probarRalphDerribaViga();
        probarVictoriaPorColapso();
        probarLetreroBloqueado();
        probarVictoriaPorLaCima();
        probarFelixReparaSolo();
        probarFelixPersigueYMartilla();
        probarLadrilloYPastel();
        probarDerrotaPorReparacion();
        probarDerrotaPorEnergia();

        System.out.println();
        System.out.println(fallas == 0 ? "TODAS LAS PRUEBAS PASARON"
                                       : fallas + " PRUEBA(S) FALLARON");
        System.exit(fallas == 0 ? 0 : 1);
    }

    /**
     * Fuera del IDE, Actor no encuentra su imagen por defecto (la carga el
     * entorno de Greenfoot) y su constructor falla. Se le asigna una imagen
     * minima para poder instanciar actores en esta prueba.
     */
    private static void prepararEntornoDePrueba() throws Exception
    {
        Field f = Actor.class.getDeclaredField("greenfootImage");
        f.setAccessible(true);
        f.set(null, new GreenfootImage(1, 1));
    }

    // ------------------------------------------------------------------
    // Escenario y fisica
    // ------------------------------------------------------------------

    private static void probarEscenario()
    {
        Mundo mundo = new Mundo();

        verificar("El mundo crea 20 ventanas",
                  mundo.getObjects(Ventana.class).size() == 20);
        verificar("Hay 4 pisos mas la azotea (5 plataformas)",
                  mundo.getObjects(Plataforma.class).size() == 5);
        verificar("Hay una viga por piso",
                  mundo.getObjects(Viga.class).size() == Mundo.PISOS);
        verificar("Hay un letrero en la cima",
                  mundo.getObjects(Letrero.class).size() == 1);
        verificar("El jugador es Ralph y empieza en el piso 0",
                  mundo.getRalph().getPiso() == 0);
        verificar("Felix arranca en otro piso", mundo.getFelix().getPiso() == 1);
        verificar("Ralph empieza con toda la energia",
                  mundo.getRalph().getSalud() == Ralph.SALUD_MAXIMA);
        verificar("Las barras arrancan bajas",
                  mundo.getDanio() == Mundo.DANIO_VENTANA * 2
                  && mundo.getReparacion() == 0);
        verificar("La cima empieza bloqueada", !mundo.cimaDesbloqueada());
    }

    private static void probarPosicionInicial()
    {
        Mundo mundo = new Mundo();
        Ralph ralph = mundo.getRalph();

        int pies = ralph.getY() + Ralph.ALTO / 2;
        verificar("Ralph queda apoyado en la repisa del piso 0 (" + pies + ")",
                  pies == Mundo.SUPERFICIE_PISO[0]);
    }

    private static void probarRalphSubeDePiso() throws Exception
    {
        Mundo mundo = new Mundo();
        Ralph ralph = mundo.getRalph();

        int ciclos = saltar(ralph);

        verificar("El salto de Ralph termina (" + ciclos + " ciclos)", ciclos < 60);
        verificar("Ralph sube un piso de un salto", ralph.getPiso() == 1);
        verificar("Aterriza exacto sobre la repisa",
                  ralph.getY() + Ralph.ALTO / 2 == Mundo.SUPERFICIE_PISO[1]);
    }

    private static void probarRalphLlegaALaAzotea() throws Exception
    {
        Mundo mundo = new Mundo();
        Ralph ralph = mundo.getRalph();

        ralph.setLocation(ralph.getX(), Mundo.SUPERFICIE_PISO[3] - Ralph.ALTO / 2);
        ralph.colocarEnPiso(3);
        saltar(ralph);

        verificar("Desde el ultimo piso Ralph alcanza la azotea",
                  ralph.getPiso() == Mundo.PISO_AZOTEA);
        verificar("Queda de pie sobre la losa",
                  ralph.getY() + Ralph.ALTO / 2 == Mundo.SUPERFICIE_TECHO);
    }

    private static void probarFelixNoSubeALaAzotea() throws Exception
    {
        Mundo mundo = new Mundo();
        Felix felix = mundo.getFelix();

        felix.setLocation(felix.getX(), Mundo.SUPERFICIE_PISO[3] - Felix.ALTO / 2);
        felix.colocarEnPiso(3);
        saltar(felix);

        verificar("Felix no puede apoyarse en la azotea", felix.getPiso() == 3);
    }

    // ------------------------------------------------------------------
    // Destruccion
    // ------------------------------------------------------------------

    private static void probarRalphRompeVentana() throws Exception
    {
        Mundo mundo = new Mundo();
        Ralph ralph = mundo.getRalph();

        Ventana v = mundo.ventanaEn(0, 1);
        v.reparar();                              // aseguramos que este sana
        ralph.setLocation(v.getX(), ralph.getY());

        int danioAntes = mundo.getDanio();
        invocar(ralph, "aplicarGolpe");

        verificar("El golpe de Ralph rompe la ventana de enfrente", v.estaRota());
        verificar("La barra de dano sube " + Mundo.DANIO_VENTANA + "%",
                  mundo.getDanio() == danioAntes + Mundo.DANIO_VENTANA);
    }

    private static void probarRalphDerribaViga() throws Exception
    {
        Mundo mundo = new Mundo();
        Ralph ralph = mundo.getRalph();
        Viga viga = vigaDelPiso(mundo, 0);

        ralph.setLocation(viga.getX(), ralph.getY());
        int danioAntes = mundo.getDanio();

        invocar(ralph, "aplicarGolpe");
        verificar("La viga aguanta el primer golpe", !viga.estaDestruida());
        verificar("Quedan " + (Viga.GOLPES_NECESARIOS - 1) + " golpes",
                  viga.getGolpesRestantes() == Viga.GOLPES_NECESARIOS - 1);

        for (int i = 1; i < Viga.GOLPES_NECESARIOS; i++)
        {
            invocar(ralph, "aplicarGolpe");
        }

        verificar("Al tercer golpe la viga cae", viga.estaDestruida());
        verificar("La viga suma " + Mundo.DANIO_VIGA + "% de dano permanente",
                  mundo.getDanio() == danioAntes + Mundo.DANIO_VIGA);

        // Felix no puede deshacer el dano de las vigas: solo repara ventanas.
        for (Ventana v : mundo.getObjects(Ventana.class)) { v.reparar(); }
        verificar("Reparar todas las ventanas no borra el dano de la viga",
                  mundo.getDanio() == Mundo.DANIO_VIGA);
    }

    private static void probarVictoriaPorColapso() throws Exception
    {
        Mundo mundo = new Mundo();

        for (Viga viga : mundo.getObjects(Viga.class))
        {
            for (int i = 0; i < Viga.GOLPES_NECESARIOS; i++) { viga.recibirGolpe(); }
        }
        verificar("Las 4 vigas dan " + (4 * Mundo.DANIO_VIGA) + "% permanente",
                  mundo.vigasDestruidas() == 4);

        int rotas = 0;
        for (Ventana v : mundo.getObjects(Ventana.class))
        {
            if (mundo.getDanio() >= Mundo.DANIO_META) { break; }
            if (v.romper()) { rotas++; }
        }

        ejecutarSinDetener(mundo, 1);

        verificar("Con vigas y ventanas el dano llega al 100%",
                  mundo.getDanio() == Mundo.DANIO_META);
        verificar("Ralph gana por colapso del edificio",
                  mundo.estaTerminado() && mundo.hayVictoria());
        verificar("El resultado explica la victoria",
                  mundo.getResultado().toLowerCase().contains("colapso"));
    }

    // ------------------------------------------------------------------
    // Ruta de la cima
    // ------------------------------------------------------------------

    private static void probarLetreroBloqueado()
    {
        Mundo mundo = new Mundo();
        Letrero letrero = mundo.getObjects(Letrero.class).get(0);

        verificar("Con poco dano el letrero no cede", !letrero.recibirGolpe());
        verificar("La partida sigue activa", mundo.estaActivo());
    }

    private static void probarVictoriaPorLaCima() throws Exception
    {
        Mundo mundo = new Mundo();
        Ralph ralph = mundo.getRalph();
        Letrero letrero = mundo.getObjects(Letrero.class).get(0);

        // Se rompen vigas hasta desbloquear la cima.
        for (Viga viga : mundo.getObjects(Viga.class))
        {
            for (int i = 0; i < Viga.GOLPES_NECESARIOS; i++) { viga.recibirGolpe(); }
        }
        verificar("Con las vigas caidas la cima se desbloquea",
                  mundo.cimaDesbloqueada());

        // Ralph sube a la azotea y golpea el letrero.
        ralph.setLocation(letrero.getX(), Mundo.SUPERFICIE_TECHO - Ralph.ALTO / 2);
        ralph.colocarEnPiso(Mundo.PISO_AZOTEA);
        ejecutarSinDetener(ralph, "aplicarGolpe");

        verificar("Ralph derriba el letrero", letrero.estaDerribado());
        verificar("Gana por la ruta de la cima",
                  mundo.estaTerminado() && mundo.hayVictoria());
        verificar("El resultado menciona el pastel",
                  mundo.getResultado().toLowerCase().contains("pastel"));
    }

    // ------------------------------------------------------------------
    // Felix (IA)
    // ------------------------------------------------------------------

    private static void probarFelixReparaSolo()
    {
        Mundo mundo = new Mundo();
        Felix felix = mundo.getFelix();
        Ralph ralph = mundo.getRalph();

        // Ralph lejos, para que Felix no lo persiga.
        ralph.setLocation(Mundo.EDIFICIO_X1 + 20, ralph.getY());
        for (Ventana v : mundo.getObjects(Ventana.class)) { v.reparar(); }

        Ventana objetivo = mundo.ventanaEn(1, 0);
        objetivo.romper();

        int ciclos = 0;
        while (objetivo.estaRota() && ciclos < 400)
        {
            felix.act();
            ciclos++;
        }

        verificar("Felix busca y repara solo la ventana rota (" + ciclos + " ciclos)",
                  !objetivo.estaRota());
        verificar("Felix suma la reparacion a su cuenta",
                  mundo.getReparaciones() > 0);
    }

    private static void probarFelixPersigueYMartilla()
    {
        Mundo mundo = new Mundo();
        Felix felix = mundo.getFelix();
        Ralph ralph = mundo.getRalph();

        // Ralph aparece justo al lado de Felix, en su mismo piso.
        ralph.setLocation(felix.getX() + 30, Mundo.SUPERFICIE_PISO[1] - Ralph.ALTO / 2);
        ralph.colocarEnPiso(1);

        int energiaAntes = ralph.getSalud();
        int ciclos = 0;
        while (ralph.getSalud() == energiaAntes && ciclos < 200)
        {
            felix.act();
            ciclos++;
        }

        verificar("Felix persigue a Ralph y le da un martillazo (" + ciclos + " ciclos)",
                  ralph.getSalud() < energiaAntes);
        verificar("El martillazo deja aturdido a Ralph",
                  estadoDe(ralph).equals("ATURDIDO"));
    }

    // ------------------------------------------------------------------
    // Vecinos
    // ------------------------------------------------------------------

    private static void probarLadrilloYPastel() throws Exception
    {
        Mundo mundo = new Mundo();
        Ralph ralph = mundo.getRalph();

        int energiaAntes = ralph.getSalud();
        Ladrillo ladrillo = new Ladrillo();
        mundo.addObject(ladrillo, ralph.getX(), ralph.getY() - 4);
        for (int i = 0; i < 60 && ladrillo.getWorld() != null; i++)
        {
            ladrillo.act();
        }

        verificar("El ladrillo quita energia", ralph.getSalud() < energiaAntes);
        verificar("El ladrillo desaparece al impactar",
                  mundo.getObjects(Ladrillo.class).isEmpty());

        int energia = ralph.getSalud();
        Ladrillo otro = new Ladrillo();
        mundo.addObject(otro, ralph.getX(), ralph.getY() - 4);
        for (int i = 0; i < 60 && otro.getWorld() != null; i++) { otro.act(); }
        verificar("Tras el impacto hay invulnerabilidad breve",
                  ralph.getSalud() == energia);

        Pastel pastel = new Pastel();
        mundo.addObject(pastel, ralph.getX(), ralph.getY() - 4);
        for (int i = 0; i < 60 && pastel.getWorld() != null; i++) { pastel.act(); }

        verificar("El pastel no quita energia", ralph.getSalud() == energia);
        verificar("El pastel ralentiza a Ralph", ralph.estaEmpastelado());
        verificar("Empastelado no puede golpear",
                  !((Boolean) invocar(ralph, "puedeGolpearAhora")));
    }

    // ------------------------------------------------------------------
    // Derrotas
    // ------------------------------------------------------------------

    private static void probarDerrotaPorReparacion()
    {
        Mundo mundo = new Mundo();
        Ralph ralph = mundo.getRalph();

        // Con una sola ventana rota, la barra de Felix no avanza.
        for (int i = 0; i < 200; i++) { mundo.act(); }
        verificar("Con ventanas rotas Felix no blinda nada",
                  mundo.getReparacion() == 0 && mundo.estaActivo());

        // Edificio entero: a partir de aqui Felix empieza a blindarlo.
        for (Ventana v : mundo.getObjects(Ventana.class)) { v.reparar(); }
        for (int i = 0; i < Mundo.CICLOS_BLINDAJE / 2; i++) { mundo.act(); }
        verificar("Con el edificio entero la barra de Felix sube",
                  mundo.getReparacion() > 30 && mundo.estaActivo());

        // Y un solo destrozo la pone a cero: es lo que hace justa la regla.
        mundo.registrarDestrozo();
        verificar("Cualquier destrozo de Ralph reinicia el blindaje",
                  mundo.getReparacion() == 0);
        for (int i = 0; i < Mundo.CICLOS_BLINDAJE / 2; i++) { mundo.act(); }

        // Si Ralph vuelve a romper algo, Felix pierde terreno deprisa.
        int antes = mundo.getReparacion();
        mundo.ventanaEn(0, 0).romper();
        for (int i = 0; i < 20; i++) { mundo.act(); }
        verificar("Romper una ventana hace bajar la barra de Felix",
                  mundo.getReparacion() < antes);

        // Y si Ralph no reacciona, Felix acaba blindando el edificio.
        mundo.ventanaEn(0, 0).reparar();
        for (int i = 0; i < Mundo.CICLOS_BLINDAJE + 60 && mundo.estaActivo(); i++)
        {
            mundo.act();
        }

        verificar("Manteniendo el edificio entero, Felix gana", !mundo.estaActivo());
        verificar("Ralph es arrojado al lodo (aun no termina la animacion)",
                  !mundo.estaTerminado());

        caerAlLodo(mundo, ralph);

        verificar("Ralph termina dentro del lodo",
                  ralph.getY() >= Mundo.NIVEL_LODO - 40);
        verificar("La partida termina en derrota",
                  mundo.estaTerminado() && !mundo.hayVictoria());
        verificar("El resultado menciona el blindaje de Felix",
                  mundo.getResultado().toLowerCase().contains("blindo"));
    }

    private static void probarDerrotaPorEnergia() throws Exception
    {
        Mundo mundo = new Mundo();
        Ralph ralph = mundo.getRalph();

        int golpes = 0;
        while (ralph.getSalud() > 0 && golpes < 40)
        {
            ralph.recibirLadrillo(Ralph.SALUD_MAXIMA / 4);

            // Se deja pasar la invulnerabilidad sin usar act() (leeria el teclado).
            for (int i = 0; i < 60; i++)
            {
                invocar(ralph, "actualizarTemporizadores");
            }
            golpes++;
        }

        verificar("La energia de Ralph puede llegar a cero", ralph.getSalud() == 0);
        verificar("Quedarse sin energia termina la partida", !mundo.estaActivo());

        caerAlLodo(mundo, ralph);

        verificar("Pierde por falta de energia",
                  mundo.estaTerminado() && !mundo.hayVictoria());
        verificar("El resultado menciona la energia",
                  mundo.getResultado().toLowerCase().contains("energia"));
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------

    /** Ejecuta un salto completo y devuelve cuantos ciclos duro. */
    private static int saltar(Personaje personaje) throws Exception
    {
        invocar(personaje, "iniciarSalto");

        int ciclos = 0;
        while (personaje.estaEnAire() && ciclos < 60)
        {
            invocar(personaje, "actualizarVertical");
            ciclos++;
        }
        return ciclos;
    }

    /** Deja caer a Ralph al lodo hasta que la partida se cierra. */
    private static void caerAlLodo(Mundo mundo, Ralph ralph)
    {
        int ciclos = 0;
        try
        {
            while (!mundo.estaTerminado() && ciclos < 300)
            {
                ralph.act();
                ciclos++;
            }
        }
        catch (NullPointerException e)
        {
            // Greenfoot.stop() solo existe dentro del IDE; el estado ya se fijo.
        }
    }

    /** Igual que act(), tolerando el fallo de Greenfoot.stop() fuera del IDE. */
    private static void ejecutarSinDetener(Mundo mundo, int ciclos)
    {
        try
        {
            for (int i = 0; i < ciclos; i++) { mundo.act(); }
        }
        catch (NullPointerException e)
        {
            // la partida ya quedo marcada como terminada
        }
    }

    private static void ejecutarSinDetener(Object objetivo, String metodo)
    {
        try
        {
            invocar(objetivo, metodo);
        }
        catch (Exception e)
        {
            // Greenfoot.stop() fuera del IDE
        }
    }

    private static String estadoDe(Object actor)
    {
        try
        {
            return campo(actor, "estado").toString();
        }
        catch (Exception e)
        {
            return "?";
        }
    }

    private static Viga vigaDelPiso(Mundo mundo, int piso)
    {
        for (Viga viga : mundo.getObjects(Viga.class))
        {
            if (viga.getPiso() == piso)
            {
                return viga;
            }
        }
        return null;
    }

    private static void verificar(String descripcion, boolean condicion)
    {
        System.out.println((condicion ? "  OK   " : "  FALLA") + "  " + descripcion);
        if (!condicion)
        {
            fallas++;
        }
    }

    private static Object invocar(Object objetivo, String nombre) throws Exception
    {
        Method m = metodo(objetivo.getClass(), nombre);
        return m.invoke(objetivo);
    }

    /** Busca el metodo tambien en las superclases (por ejemplo, en Personaje). */
    private static Method metodo(Class<?> clase, String nombre) throws Exception
    {
        for (Class<?> c = clase; c != null; c = c.getSuperclass())
        {
            try
            {
                Method m = c.getDeclaredMethod(nombre);
                m.setAccessible(true);
                return m;
            }
            catch (NoSuchMethodException e)
            {
                // se sigue buscando hacia arriba
            }
        }
        throw new NoSuchMethodException(nombre);
    }

    private static Object campo(Object objetivo, String nombre) throws Exception
    {
        for (Class<?> c = objetivo.getClass(); c != null; c = c.getSuperclass())
        {
            try
            {
                Field f = c.getDeclaredField(nombre);
                f.setAccessible(true);
                return f.get(objetivo);
            }
            catch (NoSuchFieldException e)
            {
                // se sigue buscando hacia arriba
            }
        }
        throw new NoSuchFieldException(nombre);
    }
}
