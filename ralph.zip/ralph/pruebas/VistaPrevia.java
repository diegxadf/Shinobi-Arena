import greenfoot.*;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.Field;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * Genera una imagen PNG del escenario sin abrir Greenfoot, para revisar la
 * geometria y el HUD mientras se usan sprites provisionales.
 *
 * Uso: java VistaPrevia salida.png [ciclos]
 * Simula a Felix y a los proyectiles; Ralph queda quieto porque depende del teclado.
 */
public class VistaPrevia
{
    public static void main(String[] args) throws Exception
    {
        System.out.println("images/ disponible: " + CargadorImagenes.instalar());

        Field f = Actor.class.getDeclaredField("greenfootImage");
        f.setAccessible(true);
        f.set(null, new GreenfootImage(1, 1));

        String salida = args.length > 0 ? args[0] : "vista_previa.png";
        int ciclos = args.length > 1 ? Integer.parseInt(args[1]) : 0;

        Mundo mundo = new Mundo();
        prepararSituacionDeEjemplo(mundo);

        for (int i = 0; i < ciclos; i++)
        {
            mundo.act();
            mundo.getFelix().act();
            for (Proyectil p : mundo.getObjects(Proyectil.class))
            {
                p.act();
            }
        }
        mundo.getObjects(Hud.class).get(0).refrescar();

        BufferedImage lienzo = new BufferedImage(Mundo.ANCHO, Mundo.ALTO,
                                                 BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = lienzo.createGraphics();
        g.drawImage(mundo.getBackground().getAwtImage(), 0, 0, null);

        dibujarCapa(g, mundo.getObjects(Plataforma.class));
        dibujarCapa(g, mundo.getObjects(Ventana.class));
        dibujarCapa(g, mundo.getObjects(Viga.class));
        dibujarCapa(g, mundo.getObjects(Letrero.class));
        dibujarCapa(g, mundo.getObjects(Felix.class));
        dibujarCapa(g, mundo.getObjects(Ralph.class));
        dibujarCapa(g, mundo.getObjects(Proyectil.class));
        dibujarCapa(g, mundo.getObjects(Hud.class));

        g.dispose();
        ImageIO.write(lienzo, "png", new File(salida));
        System.out.println("Imagen generada: " + new File(salida).getAbsolutePath());
    }

    /** Partida a medias: algunas ventanas rotas y una viga golpeada. */
    private static void prepararSituacionDeEjemplo(Mundo mundo)
    {
        for (int col = 0; col < 3; col++)
        {
            mundo.ventanaEn(0, col).romper();
            mundo.ventanaEn(1, col + 1).romper();
        }

        List<Viga> vigas = mundo.getObjects(Viga.class);
        for (int i = 0; i < Viga.GOLPES_NECESARIOS; i++)
        {
            vigas.get(0).recibirGolpe();
        }
        vigas.get(1).recibirGolpe();

        // Ralph se coloca junto a una viga de un piso alto, lejos de Felix.
        Ralph ralph = mundo.getRalph();
        Viga objetivo = vigas.get(2);
        ralph.setLocation(objetivo.getX() - 34,
                          Mundo.SUPERFICIE_PISO[2] - Ralph.ALTO / 2);
        ralph.colocarEnPiso(2);
    }

    private static void dibujarCapa(Graphics2D g, List<? extends Actor> actores)
    {
        for (Actor a : actores)
        {
            BufferedImage img = a.getImage().getAwtImage();
            g.drawImage(img, a.getX() - img.getWidth() / 2,
                             a.getY() - img.getHeight() / 2, null);
        }
    }
}
