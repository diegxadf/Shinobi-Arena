import java.io.File;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;

/** Comprueba que todos los WAV de sounds/ se pueden decodificar. */
public class ComprobarSonidos {
    public static void main(String[] a) throws Exception {
        File dir = new File("sounds");
        File[] archivos = dir.listFiles((d, n) -> n.endsWith(".wav"));
        int fallos = 0;
        for (File f : archivos) {
            try (AudioInputStream in = AudioSystem.getAudioInputStream(f)) {
                AudioFormat fmt = in.getFormat();
                double seg = in.getFrameLength() / fmt.getFrameRate();
                System.out.printf("  OK   %-18s %.0f Hz %d bits %d canal  %.2fs%n",
                    f.getName(), fmt.getSampleRate(), fmt.getSampleSizeInBits(),
                    fmt.getChannels(), seg);
            } catch (Exception e) {
                System.out.println("  FALLA " + f.getName() + ": " + e);
                fallos++;
            }
        }
        System.out.println(fallos == 0 ? "TODOS LOS SONIDOS SE LEEN" : fallos + " FALLARON");
        System.exit(fallos == 0 ? 0 : 1);
    }
}
