import greenfoot.*;
import java.lang.reflect.Field;
import java.util.List;

/** Simula una partida con un Ralph que rompe a ritmo constante, sin teclado. */
public class Simular {
    public static void main(String[] a) throws Exception {
        CargadorImagenes.instalar();
        Field f = Actor.class.getDeclaredField("greenfootImage");
        f.setAccessible(true); f.set(null, new GreenfootImage(1,1));

        int ritmo = a.length > 0 ? Integer.parseInt(a[0]) : 40;   // ciclos por rotura
        boolean vigasNo = a.length > 1 && a[1].equals("solo-ventanas");
        boolean pasivo  = a.length > 1 && a[1].equals("pasivo");
        Mundo m = new Mundo();
        Ralph r = m.getRalph();
        Felix fx = m.getFelix();

        int ciclos = 0, rotas = 0, vigas = 0;
        try {
            while (m.estaActivo() && ciclos < 6000) {
                m.act(); fx.act();
                // Ralph no puede usar act() (leeria el teclado): se le hacen
                // avanzar sus temporizadores a mano.
                java.lang.reflect.Method t = Ralph.class.getDeclaredMethod("actualizarTemporizadores");
                t.setAccessible(true); t.invoke(r);
                for (Proyectil p : m.getObjects(Proyectil.class)) p.act();

                // Ralph destruye a ritmo fijo: primero las vigas, luego ventanas.
                if (!pasivo && ciclos % ritmo == 0) {
                    boolean hecho = false;
                    if (!vigasNo) for (Viga v : m.getObjects(Viga.class))
                        if (!v.estaDestruida()) { v.recibirGolpe(); hecho = true; break; }
                    if (!hecho) {
                        Ventana v = m.ventanaIntactaAleatoria();
                        if (v != null) { v.romper(); m.registrarDestrozo(); rotas++; }
                    }
                }
                ciclos++;
                if (ciclos % 300 == 0)
                    System.out.printf("  t=%4d s=%2d  DANO %3d%%  REPARA %3d%%  ENERGIA %3d%%%n",
                        ciclos, ciclos/60, m.getDanio(), m.getReparacion(), r.getSalud());
            }
        } catch (NullPointerException e) { }

        vigas = m.vigasDestruidas();
        System.out.printf("%nFIN en %d ciclos (%d s): %s%n  %s%n",
            ciclos, ciclos/60, m.hayVictoria() ? "VICTORIA" : "DERROTA", m.getResultado());
        System.out.printf("  dano=%d%%  reparacion=%d%%  energia=%d%%  vigas=%d  reparaciones=%d%n",
            m.getDanio(), m.getReparacion(), r.getSalud(), vigas, m.getReparaciones());
    }
}
