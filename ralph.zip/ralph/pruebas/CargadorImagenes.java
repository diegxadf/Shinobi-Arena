import greenfoot.GreenfootImage;
import greenfoot.UserInfo;
import greenfoot.platforms.GreenfootUtilDelegate;
import greenfoot.util.GreenfootUtil;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Permite que GreenfootImage encuentre la carpeta images/ fuera del IDE.
 *
 * Greenfoot instala ese "delegado" al abrir un escenario; en una ejecucion
 * normal de Java no existe, y por eso todos los sprites caerian al dibujo
 * provisional. Con esto la vista previa muestra los PNG de verdad.
 */
public class CargadorImagenes implements GreenfootUtilDelegate
{
    /** Lo instala y devuelve true si la carpeta images/ existe. */
    public static boolean instalar()
    {
        GreenfootUtil.initialise(new CargadorImagenes());
        return new File("images").isDirectory();
    }

    public URL getResource(String ruta)
    {
        File archivo = new File(ruta);
        if (!archivo.exists())
        {
            archivo = new File("images", new File(ruta).getName());
        }
        if (!archivo.exists())
        {
            return null;
        }
        try
        {
            return archivo.toURI().toURL();
        }
        catch (Exception e)
        {
            return null;
        }
    }

    public Iterable<String> getSoundFiles()        { return new ArrayList<String>(); }
    public String getGreenfootLogoPath()           { return "greenfoot.png"; }
    public boolean isStorageSupported()            { return false; }
    public UserInfo getCurrentUserInfo()           { return null; }
    public boolean storeCurrentUserInfo(UserInfo u){ return false; }
    public List<UserInfo> getTopUserInfo(int n)    { return new ArrayList<UserInfo>(); }
    public GreenfootImage getUserImage(String n)   { return null; }
    public String getUserName()                    { return null; }
    public List<UserInfo> getNearbyUserInfo(int n) { return new ArrayList<UserInfo>(); }
}
