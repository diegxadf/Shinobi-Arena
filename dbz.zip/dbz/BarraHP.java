import greenfoot.*;

/**
 * Paso 11 de la guia, mejorado.
 *
 * Concern atendido: OBSERVABILIDAD y FEEDBACK.
 * Ademas de mostrar el HP restante, la barra baja de forma animada y deja una
 * estela roja del dano recien recibido: el usuario ve CUANTO le quitaron, no
 * solo cuanto le queda. El color cambia (verde -> amarillo -> rojo) para que el
 * estado se lea de un vistazo sin leer numeros.
 */
public class BarraHP extends Actor
{
    private static final int ANCHO = 300;
    private static final int ALTO  = 48;

    private final Unidad unidad;
    private final Color  acento;

    private double mostrado;   // valor que se dibuja (persigue al HP real)
    private double estela;     // valor lento, deja el rastro rojo

    public BarraHP(Unidad unidad, Color acento)
    {
        this.unidad = unidad;
        this.acento = acento;
        this.mostrado = unidad.getHP();
        this.estela = unidad.getHP();
        actualizar();
    }

    public void act()
    {
        double objetivo = unidad.getHP();
        // Si no hay nada moviendose, no se vuelve a dibujar: el gestor ya llama
        // a actualizar() cuando cambia algo que la barra deba mostrar.
        if (mostrado == objetivo && estela == mostrado) return;
        mostrado += (objetivo - mostrado) * 0.25;
        estela   += (mostrado  - estela)  * 0.06;
        if (Math.abs(objetivo - mostrado) < 0.4) mostrado = objetivo;
        if (Math.abs(mostrado - estela)   < 0.4) estela   = mostrado;
        actualizar();
    }

    /** La guia llama a este metodo desde el gestor tras cada resolucion. */
    public void actualizar()
    {
        GreenfootImage img = FabricaImagenes.panel(ANCHO, ALTO, 10,
                                 new Color(18, 20, 28, 225), acento, 3);

        // Nombre del peleador (cambia al transformarse).
        img.drawImage(FabricaImagenes.texto(unidad.getNombre().toUpperCase(), 17,
                          Config.BLANCO), 12, 2);

        // Numeros a la derecha.
        GreenfootImage num = FabricaImagenes.texto(
                unidad.getHP() + " / " + unidad.getHPMaximo(), 15, Config.BLANCO);
        img.drawImage(num, ANCHO - 12 - num.getWidth(), 4);

        // Canal de la barra.
        int x = 12, y = 28, ancho = ANCHO - 24, alto = 14;
        FabricaImagenes.redondeado(img, x, y, ancho, alto, 7, new Color(48, 50, 62));

        double pTotal  = (double) unidad.getHPMaximo();
        int anchoEst   = (int) (ancho * Math.max(0, estela)   / pTotal);
        int anchoVida  = (int) (ancho * Math.max(0, mostrado) / pTotal);

        // Estela del dano reciente.
        FabricaImagenes.redondeado(img, x, y, anchoEst, alto, 7, new Color(235, 70, 60, 200));

        // Vida actual, con color segun la proporcion.
        double prop = unidad.proporcionVida();
        Color color = prop > 0.5 ? new Color( 70, 215, 100)
                    : prop > 0.25 ? new Color(245, 200,  50)
                                  : new Color(235,  70,  60);
        FabricaImagenes.redondeado(img, x, y, anchoVida, alto, 7, color);
        FabricaImagenes.redondeado(img, x, y + 2, anchoVida, 4, 2,
                                   Config.conAlfa(Config.aclarar(color, 0.6), 170));

        // Marcas cada 25% para poder estimar sin leer.
        img.setColor(new Color(20, 22, 30, 160));
        for (int i = 1; i < 4; i++)
        {
            int mx = x + ancho * i / 4;
            img.drawLine(mx, y + 1, mx, y + alto - 2);
        }

        // Avisos de estado (guardia / aturdido / transformado).
        String aviso = null;
        Color colorAviso = Config.BLANCO;
        if (unidad.estaAturdida())         { aviso = "ATURDIDO";  colorAviso = new Color(255, 220, 90); }
        else if (unidad.estaDefendiendo()) { aviso = "GUARDIA";   colorAviso = new Color(120, 230, 255); }
        else if (unidad.estaTransformada()){ aviso = "x" + unidad.getFicha().multiplicadorTransformacion + " DANO";
                                             colorAviso = Config.DORADO; }
        if (aviso != null && Config.AYUDAS_VISUALES)
        {
            GreenfootImage t = FabricaImagenes.texto(aviso, 12, colorAviso);
            int ax = ANCHO - 20 - num.getWidth() - t.getWidth();
            FabricaImagenes.redondeado(img, ax - 5, 5, t.getWidth() + 10, 18, 8,
                                       Config.conAlfa(colorAviso, 45));
            img.drawImage(t, ax, 4);
        }

        setImage(img);
    }
}
