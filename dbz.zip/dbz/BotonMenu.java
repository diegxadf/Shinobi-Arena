import greenfoot.*;

/**
 * Tarjeta de seleccion de rival en el menu.
 *
 * Concern atendido: TOMA DE DECISION INFORMADA.
 * Antes de empezar, la tarjeta ya dice cuanta vida tiene el rival, en que se
 * transforma y cual es su tecnica mas peligrosa. Elegir rival es la primera
 * decision del juego y tambien tiene que hacerse con datos, no a ciegas.
 */
public class BotonMenu extends Actor
{
    public static final int ANCHO = 262;
    public static final int ALTO  = 344;

    private final Ficha ficha;
    private final int numeroTecla;
    private boolean resaltado = false;
    private int fase = 0;

    public BotonMenu(Ficha ficha, int numeroTecla)
    {
        this.ficha = ficha;
        this.numeroTecla = numeroTecla;
        pintar();
    }

    public void act()
    {
        fase++;
        boolean antes = resaltado;
        if (Greenfoot.mouseMoved(this))      resaltado = true;
        else if (Greenfoot.mouseMoved(null)) resaltado = false;
        if (antes != resaltado || fase % 6 == 0) pintar();

        if (Greenfoot.mouseClicked(this))
        {
            Sonidos.reproducir("boton.wav");
            Greenfoot.setWorld(new JuegoTurnos(ficha));
        }
    }

    public Ficha getFicha() { return ficha; }

    private void pintar()
    {
        Color acento = ficha.estilo.detalle;
        Color borde = resaltado || (fase % 40 < 20)
                    ? Config.aclarar(acento, 0.45) : acento;

        GreenfootImage img = FabricaImagenes.panel(ANCHO, ALTO, 16,
                                 new Color(18, 20, 30, resaltado ? 245 : 215), borde, 3);

        // Marco del retrato.
        FabricaImagenes.redondeado(img, 16, 16, ANCHO - 32, 190, 12,
                                   Config.conAlfa(acento, 55));
        GreenfootImage retrato = Recursos.cargar("retrato_" + ficha.prefijo + ".png");
        if (retrato == null) retrato = Recursos.cargar(ficha.prefijo + "_idle.png");
        if (retrato == null) retrato = FabricaImagenes.retrato(ficha.estilo, 128, 182);
        img.drawImage(retrato, (ANCHO - retrato.getWidth()) / 2,
                      20 + Math.max(0, 182 - retrato.getHeight()));

        // Numero de atajo.
        FabricaImagenes.redondeado(img, 16, 16, 26, 26, 8, Config.conAlfa(acento, 220));
        FabricaImagenes.textoCentrado(img, String.valueOf(numeroTecla), 16,
                                      Config.NEGRO, 29, 16);

        FabricaImagenes.textoCentrado(img, ficha.nombre.toUpperCase(), 26,
                                      Config.BLANCO, ANCHO / 2, 210);
        FabricaImagenes.textoCentrado(img, ficha.apodo, 12,
                                      new Color(185, 190, 208), ANCHO / 2, 242);

        FabricaImagenes.textoCentrado(img, "HP " + ficha.hpMaximo
                                      + "   -   se convierte en " + ficha.nombreTransformado,
                                      12, new Color(210, 215, 230), ANCHO / 2, 264);

        AccionCombate fuerte = masFuerte();
        if (fuerte != null)
        {
            FabricaImagenes.textoCentrado(img, "Tecnica mas peligrosa", 11,
                                          new Color(160, 166, 184), ANCHO / 2, 284);
            FabricaImagenes.textoCentrado(img, fuerte.getNombre() + "   "
                                          + fuerte.getDanio() + " dano / "
                                          + fuerte.getProbabilidadAcierto() + "%",
                                          14, fuerte.getColor(), ANCHO / 2, 298);
        }

        // Dificultad en puntos.
        for (int i = 0; i < 3; i++)
        {
            img.setColor(i < ficha.dificultad ? Config.ROJO : new Color(70, 74, 90));
            img.fillOval(ANCHO / 2 - 27 + i * 18, 322, 12, 12);
        }

        setImage(img);
    }

    /** La accion ofensiva de mayor dano nominal del rival. */
    private AccionCombate masFuerte()
    {
        AccionCombate mejor = null;
        for (AccionCombate a : ficha.acciones)
        {
            if (!a.esOfensiva()) continue;
            if (mejor == null || a.getDanio() > mejor.getDanio()) mejor = a;
        }
        return mejor;
    }
}
