import greenfoot.*;

/**
 * Paleta y tipo de cuerpo de un peleador.
 *
 * Driver atendido: MODULARIDAD.
 * La apariencia vive separada de las reglas: FabricaImagenes dibuja a partir de
 * un Estilo, y Ficha/Unidad no saben nada de colores ni de pixeles.
 */
public class Estilo
{
    public static final int SAIYAJIN = 0;   // Goku, Vegeta: pelo en picos y gi
    public static final int ALIEN    = 1;   // Freezer: cabeza lisa, cuernos y cola
    public static final int BIO      = 2;   // Cell: caparazon verde con manchas

    public final int   tipo;
    public final Color piel;
    public final Color traje;
    public final Color detalle;
    public final Color pelo;
    public final Color peloTransformado;
    public final Color aura;
    public final Color auraTransformada;

    public Estilo(int tipo, Color piel, Color traje, Color detalle,
                  Color pelo, Color peloTransformado,
                  Color aura, Color auraTransformada)
    {
        this.tipo = tipo;
        this.piel = piel;
        this.traje = traje;
        this.detalle = detalle;
        this.pelo = pelo;
        this.peloTransformado = peloTransformado;
        this.aura = aura;
        this.auraTransformada = auraTransformada;
    }

    /** Gi naranja, cinturon azul, pelo negro que se vuelve dorado. */
    public static Estilo goku()
    {
        return new Estilo(SAIYAJIN,
            new Color(255, 214, 170),
            new Color(242, 124,  24),
            new Color( 40,  80, 190),
            new Color( 28,  26,  36),
            new Color(255, 219,  62),
            new Color(255, 255, 255),
            new Color(255, 205,  40));
    }

    /** Traje azul, armadura blanca, pelo negro en llama. */
    public static Estilo vegeta()
    {
        return new Estilo(SAIYAJIN,
            new Color(255, 214, 170),
            new Color( 50,  70, 170),
            new Color(238, 240, 245),
            new Color( 28,  26,  36),
            new Color(255, 219,  62),
            new Color(140, 200, 255),
            new Color(255, 205,  40));
    }

    /** Cuerpo blanco con placas moradas. */
    public static Estilo freezer()
    {
        return new Estilo(ALIEN,
            new Color(238, 240, 248),
            new Color(238, 240, 248),
            new Color(150,  80, 200),
            new Color(150,  80, 200),
            new Color(210, 150, 255),
            new Color(190, 110, 255),
            new Color(235, 170, 255));
    }

    /** Caparazon verde con manchas negras y placas naranjas. */
    public static Estilo cell()
    {
        return new Estilo(BIO,
            new Color(120, 200, 110),
            new Color( 70, 165,  85),
            new Color(245, 170,  60),
            new Color( 30,  60,  40),
            new Color(190, 255, 140),
            new Color(120, 255, 140),
            new Color(210, 255, 120));
    }
}
