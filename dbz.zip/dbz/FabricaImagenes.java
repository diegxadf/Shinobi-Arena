import greenfoot.*;

/**
 * Paso 2 de la guia, llevado al estilo Dragon Ball: TODOS los graficos del
 * juego se dibujan por codigo, sin archivos externos.
 *
 * Driver atendido: PORTABILIDAD y CLARIDAD VISUAL.
 * El escenario abre y corre en cualquier maquina con Greenfoot, sin depender de
 * imagenes con licencia. Cada figura se construye con primitivas
 * (fillRect, fillOval, fillPolygon) y con la paleta que define Estilo.
 */
public class FabricaImagenes
{
    // ==================================================================
    // Utilidades generales
    // ==================================================================

    /** Texto suelto con fondo transparente (se usa para medir y centrar). */
    public static GreenfootImage texto(String s, int tam, Color color)
    {
        return new GreenfootImage(s, tam, color, new Color(0, 0, 0, 0));
    }

    /** Dibuja un texto centrado horizontalmente en cx. */
    public static void textoCentrado(GreenfootImage destino, String s, int tam,
                                     Color color, int cx, int y)
    {
        GreenfootImage t = texto(s, tam, color);
        destino.drawImage(t, cx - t.getWidth() / 2, y);
    }

    /**
     * Rectangulo de esquinas redondeadas relleno de un color.
     *
     * Si el color es translucido se dibuja primero en una imagen aparte y luego
     * se pega con transparencia: de lo contrario las esquinas, donde se pisan el
     * rectangulo y el ovalo, quedarian mas oscuras que el resto.
     */
    public static void redondeado(GreenfootImage img, int x, int y, int ancho,
                                  int alto, int radio, Color color)
    {
        if (ancho <= 0 || alto <= 0) return;

        if (color.getAlpha() < 255)
        {
            GreenfootImage capa = new GreenfootImage(ancho, alto);
            redondeado(capa, 0, 0, ancho, alto, radio,
                       new Color(color.getRed(), color.getGreen(), color.getBlue()));
            capa.setTransparency(color.getAlpha());
            img.drawImage(capa, x, y);
            return;
        }

        int r = Math.max(0, Math.min(radio, Math.min(ancho, alto) / 2));
        img.setColor(color);
        if (r == 0) { img.fillRect(x, y, ancho, alto); return; }
        img.fillRect(x + r, y, ancho - 2 * r, alto);
        img.fillRect(x, y + r, ancho, alto - 2 * r);
        img.fillOval(x, y, 2 * r, 2 * r);
        img.fillOval(x + ancho - 2 * r, y, 2 * r, 2 * r);
        img.fillOval(x, y + alto - 2 * r, 2 * r, 2 * r);
        img.fillOval(x + ancho - 2 * r, y + alto - 2 * r, 2 * r, 2 * r);
    }

    /** Panel redondeado con borde, base de casi toda la interfaz. */
    public static GreenfootImage panel(int ancho, int alto, int radio,
                                       Color relleno, Color borde, int grosor)
    {
        GreenfootImage img = new GreenfootImage(ancho, alto);
        redondeado(img, 0, 0, ancho, alto, radio, borde);
        redondeado(img, grosor, grosor, ancho - 2 * grosor, alto - 2 * grosor,
                   Math.max(0, radio - grosor), relleno);
        return img;
    }

    // ==================================================================
    // Fondo de la arena
    // ==================================================================
    public static GreenfootImage fondoArena()
    {
        int ancho = Config.ANCHO, alto = Config.ALTO, suelo = Config.SUELO;
        GreenfootImage img = new GreenfootImage(ancho, alto);

        // Cielo: degradado de azul profundo a naranja cerca del horizonte.
        for (int y = 0; y < suelo; y++)
        {
            double t = (double) y / suelo;
            int r = (int) ( 46 + 200 * t * t);
            int g = (int) (120 + 100 * t);
            int b = (int) (210 - 120 * t);
            img.setColor(new Color(Math.min(r, 255), Math.min(g, 255), Math.max(b, 0)));
            img.drawLine(0, y, ancho, y);
        }

        // Sol con halo.
        img.setColor(new Color(255, 240, 180, 60));
        img.fillOval(700, 30, 190, 190);
        img.setColor(new Color(255, 245, 200, 110));
        img.fillOval(730, 60, 130, 130);
        img.setColor(new Color(255, 252, 235));
        img.fillOval(755, 85, 80, 80);

        // Nubes.
        nube(img, 120,  90, 150);
        nube(img, 420,  60, 110);
        nube(img, 610, 130,  90);

        // Montanas lejanas.
        montana(img, 60,  suelo, 260, 190, new Color(110, 130, 175));
        montana(img, 300, suelo, 330, 240, new Color( 92, 112, 158));
        montana(img, 620, suelo, 300, 205, new Color(110, 130, 175));

        // Suelo del desierto.
        for (int y = suelo; y < alto; y++)
        {
            double t = (double) (y - suelo) / (alto - suelo);
            int r = (int) (226 - 60 * t);
            int g = (int) (190 - 62 * t);
            int b = (int) (126 - 50 * t);
            img.setColor(new Color(r, g, b));
            img.drawLine(0, y, ancho, y);
        }

        // Grietas y piedras del suelo.
        img.setColor(new Color(160, 128,  80, 150));
        for (int i = 0; i < 26; i++)
        {
            int x = (i * 137) % ancho;
            int y = suelo + 12 + (i * 53) % (alto - suelo - 30);
            img.drawLine(x, y, x + 24 + (i % 5) * 7, y + (i % 3) - 1);
        }
        piedra(img,  90, suelo + 24, 60, new Color(150, 122,  84));
        piedra(img, 830, suelo + 16, 74, new Color(150, 122,  84));
        piedra(img, 470, suelo +  6, 46, new Color(164, 134,  92));

        // Cinta de sombra bajo el horizonte, para separar cielo y suelo.
        img.setColor(new Color(120,  90,  60, 90));
        img.fillRect(0, suelo - 3, ancho, 6);

        // Se baja a un tercio y se vuelve a subir: el fondo queda con el mismo
        // tamano de pixel que los sprites, y toda la pantalla se ve de la misma
        // epoca en vez de mezclar dibujo suave con pixel art.
        img.scale(ancho / 3, alto / 3);
        img.scale(ancho, alto);
        return img;
    }

    private static void nube(GreenfootImage img, int x, int y, int ancho)
    {
        img.setColor(new Color(255, 255, 255, 170));
        img.fillOval(x, y, ancho, ancho / 3);
        img.fillOval(x + ancho / 5, y - ancho / 8, ancho / 2, ancho / 3);
        img.fillOval(x + ancho / 2, y - ancho / 14, ancho / 3, ancho / 4);
    }

    private static void montana(GreenfootImage img, int x, int base, int ancho,
                                int alto, Color color)
    {
        img.setColor(color);
        int[] xs = { x, x + ancho / 2, x + ancho };
        int[] ys = { base, base - alto, base };
        img.fillPolygon(xs, ys, 3);
        // Nieve en la cima.
        img.setColor(new Color(240, 244, 255, 200));
        int[] xs2 = { x + ancho / 2 - ancho / 10, x + ancho / 2, x + ancho / 2 + ancho / 10 };
        int[] ys2 = { base - alto + alto / 5, base - alto, base - alto + alto / 5 };
        img.fillPolygon(xs2, ys2, 3);
    }

    private static void piedra(GreenfootImage img, int x, int y, int tam, Color color)
    {
        img.setColor(Config.oscurecer(color, 0.25));
        img.fillOval(x, y + tam / 6, tam, tam / 2);
        img.setColor(color);
        img.fillOval(x + tam / 10, y, tam * 4 / 5, tam / 2);
    }

    // ==================================================================
    // Peleadores
    // ==================================================================

    // ---- piezas con contorno, para que el dibujo no se vea plano ----
    private static void ovalo(GreenfootImage img, int x, int y, int w, int h, Color c)
    {
        img.setColor(c);
        img.fillOval(x, y, w, h);
        img.setColor(Config.oscurecer(c, 0.42));
        img.drawOval(x, y, w - 1, h - 1);
    }

    private static void caja(GreenfootImage img, int x, int y, int w, int h, Color c)
    {
        img.setColor(c);
        img.fillRect(x, y, w, h);
        img.setColor(Config.oscurecer(c, 0.42));
        img.drawRect(x, y, w - 1, h - 1);
    }

    private static void poli(GreenfootImage img, int[] xs, int[] ys, Color c)
    {
        img.setColor(c);
        img.fillPolygon(xs, ys, xs.length);
        img.setColor(Config.oscurecer(c, 0.42));
        img.drawPolygon(xs, ys, xs.length);
    }

    /**
     * Dibuja un peleador completo.
     *
     * Cada pieza lleva contorno oscuro: es el truco que hace que un muneco
     * hecho con rectangulos y ovalos se lea como un personaje de anime y no
     * como un grafico de barras.
     *
     * @param e            paleta y tipo de cuerpo
     * @param transformado cambia pelo, ojos y tamano
     * @param fase         0..3, da la respiracion del personaje
     * @param miraDerecha  false = mirando a la izquierda (el rival)
     */
    public static GreenfootImage guerrero(Estilo e, boolean transformado,
                                          int fase, boolean miraDerecha)
    {
        int ancho = 150, alto = 215;
        GreenfootImage img = new GreenfootImage(ancho, alto);
        int d = (fase == 1 || fase == 3) ? 1 : (fase == 2 ? 2 : 0);

        Color piel    = e.piel;
        Color traje   = e.traje;
        Color detalle = e.detalle;
        Color pelo    = transformado ? e.peloTransformado : e.pelo;
        Color brazos  = (e.tipo == Estilo.SAIYAJIN) ? traje : piel;

        // Sombra en el suelo: no acompana la respiracion, por eso ancla la figura.
        img.setColor(new Color(0, 0, 0, 70));
        img.fillOval(34, 196, 82, 14);

        if (e.tipo == Estilo.ALIEN) cola(img, d, traje, detalle);

        // ---- piernas y botas ----
        caja(img, 56, 142 + d, 18, 44, traje);
        caja(img, 78, 142 + d, 18, 44, traje);
        caja(img, 52, 178 + d, 26, 20, detalle);
        caja(img, 74, 178 + d, 26, 20, detalle);

        // ---- brazos (van detras del torso) ----
        caja(img, 34,  98 + d, 17, 44, brazos);
        caja(img, 101, 98 + d, 17, 44, brazos);
        if (e.tipo == Estilo.SAIYAJIN)
        {
            caja(img, 32,  132 + d, 21, 12, detalle);
            caja(img, 99,  132 + d, 21, 12, detalle);
        }
        ovalo(img, 31, 138 + d, 22, 22, piel);
        ovalo(img, 99, 138 + d, 22, 22, piel);

        // ---- torso en trapecio: hombros anchos, cintura estrecha ----
        poli(img, new int[] { 44, 106, 96, 54 },
                  new int[] { 88 + d, 88 + d, 150 + d, 150 + d }, traje);
        ovalo(img, 36, 80 + d, 30, 28, traje);
        ovalo(img, 84, 80 + d, 30, 28, traje);

        if (e.tipo == Estilo.SAIYAJIN)
        {
            // Camiseta azul en V y cinturon.
            poli(img, new int[] { 64, 86, 80, 70 },
                      new int[] { 88 + d, 88 + d, 132 + d, 132 + d }, detalle);
            caja(img, 52, 140 + d, 46, 14, detalle);
        }
        else if (e.tipo == Estilo.ALIEN)
        {
            ovalo(img, 58, 94 + d, 34, 42, detalle);
            ovalo(img, 38, 78 + d, 26, 24, detalle);
            ovalo(img, 86, 78 + d, 26, 24, detalle);
            ovalo(img, 64, 102 + d, 22, 26, Config.aclarar(detalle, 0.35));
        }
        else
        {
            ovalo(img, 60, 96 + d, 30, 34, detalle);
            img.setColor(new Color(25, 45, 30));
            img.fillOval(48,  98 + d, 11, 13);
            img.fillOval(90, 108 + d, 11, 13);
            img.fillOval(58, 132 + d, 10, 11);
            img.fillOval(82, 156 + d, 10, 11);
        }

        // ---- cuello y cabeza ----
        caja(img, 66, 66 + d, 18, 24, piel);
        ovalo(img, 52, 32 + d, 46, 46, piel);

        if (e.tipo == Estilo.SAIYAJIN)
        {
            picos(img, 75, 54 + d, transformado ? 30 : 20, pelo);
            img.setColor(pelo);
            img.fillOval(52, 32 + d, 46, 22);          // flequillo
            img.setColor(Config.oscurecer(pelo, 0.35));
            img.drawOval(52, 32 + d, 45, 45);
        }
        else if (e.tipo == Estilo.ALIEN)
        {
            ovalo(img, 50, 24 + d, 50, 32, detalle);   // casco natural
            ovalo(img, 38, 44 + d, 18, 14, detalle);   // cuernos
            ovalo(img, 94, 44 + d, 18, 14, detalle);
            ovalo(img, 55, 48 + d, 40, 30, piel);      // rostro
        }
        else
        {
            ovalo(img, 54, 30 + d, 42, 18, detalle);
            poli(img, new int[] { 58, 70, 62 },
                      new int[] { 36 + d, 36 + d, 6 + d }, detalle);
            poli(img, new int[] { 80, 92, 88 },
                      new int[] { 36 + d, 36 + d, 6 + d }, detalle);
        }

        // ---- cara ----
        Color iris = transformado
                   ? (e.tipo == Estilo.SAIYAJIN ? new Color(60, 195, 185) : new Color(230, 60, 60))
                   : new Color(36, 38, 52);
        img.setColor(new Color(252, 252, 255));
        img.fillOval(60, 50 + d, 15, 12);
        img.fillOval(76, 50 + d, 15, 12);
        img.setColor(iris);
        img.fillOval(64, 52 + d, 8, 8);
        img.fillOval(80, 52 + d, 8, 8);
        img.setColor(Config.oscurecer(e.pelo, 0.1));
        img.fillRect(59, 45 + d, 16, 4);
        img.fillRect(76, 45 + d, 16, 4);
        img.setColor(new Color(120, 70, 60));
        img.fillRect(69, 68 + d, 13, 3);

        if (transformado)
        {
            img.setColor(new Color(255, 255, 210, 70));
            img.fillOval(46, 26 + d, 58, 58);
        }

        if (!miraDerecha) img.mirrorHorizontally();

        double escala = transformado ? 1.28 : 1.2;
        img.scale((int) (ancho * escala), (int) (alto * escala));
        return img;
    }

    /** Pelo saiyajin: picos triangulares alrededor de la parte alta del craneo. */
    private static void picos(GreenfootImage img, int cx, int cy, int largo, Color color)
    {
        int rx = 24, ry = 25, n = 9;
        Color sombra = Config.oscurecer(color, 0.35);
        for (int i = 0; i < n; i++)
        {
            double ang = Math.toRadians(-168 + i * (156.0 / (n - 1)));
            double mitad = Math.toRadians(10);
            int extra = (i % 2 == 0) ? largo : largo - 6;
            int x1 = cx + (int) (Math.cos(ang - mitad) * rx);
            int y1 = cy + (int) (Math.sin(ang - mitad) * ry);
            int x2 = cx + (int) (Math.cos(ang + mitad) * rx);
            int y2 = cy + (int) (Math.sin(ang + mitad) * ry);
            int xt = cx + (int) (Math.cos(ang) * (rx + extra));
            int yt = cy + (int) (Math.sin(ang) * (ry + extra));
            int[] xs = { x1, x2, xt };
            int[] ys = { y1, y2, yt };
            img.setColor(color);
            img.fillPolygon(xs, ys, 3);
            img.setColor(sombra);
            img.drawPolygon(xs, ys, 3);
        }
    }

    /** Cola de Freezer, detras del cuerpo. */
    private static void cola(GreenfootImage img, int d, Color cuerpo, Color detalle)
    {
        for (int i = 0; i < 8; i++)
        {
            int x = 100 + i * 6;
            int y = 146 + d + (int) (22 * Math.sin(i * 0.5));
            int tam = 20 - i;
            ovalo(img, x, y, tam, tam, i < 6 ? cuerpo : detalle);
        }
    }

    /** Retrato para el menu: el mismo peleador, recortado y escalado. */
    public static GreenfootImage retrato(Estilo e, int ancho, int alto)
    {
        GreenfootImage cuerpo = guerrero(e, false, 0, true);
        GreenfootImage img = new GreenfootImage(ancho, alto);
        cuerpo.scale(ancho, alto);
        img.drawImage(cuerpo, 0, 0);
        return img;
    }

    // ==================================================================
    // Efectos
    // ==================================================================

    /** Aura de ki: resplandor + llamas que suben, animadas con la fase. */
    public static GreenfootImage aura(Color color, int fase, int ancho, int alto)
    {
        GreenfootImage img = new GreenfootImage(ancho, alto);
        int cx = ancho / 2, cy = alto / 2;
        int rx = ancho / 5, ry = alto / 4;

        for (int k = 4; k >= 0; k--)
        {
            int ex = rx + k * 9;
            int ey = ry + k * 12;
            img.setColor(Config.conAlfa(color, 58 - k * 10));
            img.fillOval(cx - ex, cy - ey, ex * 2, ey * 2);
        }

        int n = 18;
        for (int i = 0; i < n; i++)
        {
            double ang = Math.toRadians(i * (360.0 / n));
            double arriba = Math.max(0, -Math.sin(ang));
            int largo = (int) (14 + 62 * arriba * arriba
                              + 7 * Math.sin(fase * 0.7 + i * 1.3));
            int x1 = cx + (int) (Math.cos(ang - 0.18) * rx);
            int y1 = cy + (int) (Math.sin(ang - 0.18) * ry);
            int x2 = cx + (int) (Math.cos(ang + 0.18) * rx);
            int y2 = cy + (int) (Math.sin(ang + 0.18) * ry);
            int xt = cx + (int) (Math.cos(ang) * (rx + largo));
            int yt = cy + (int) (Math.sin(ang) * (ry + largo));
            img.setColor(Config.conAlfa(color, 120));
            img.fillPolygon(new int[] { x1, x2, xt }, new int[] { y1, y2, yt }, 3);
        }

        img.setColor(Config.conAlfa(Config.aclarar(color, 0.6), 90));
        img.fillOval(cx - rx + 6, cy - ry + 8, (rx - 6) * 2, (ry - 8) * 2);
        return img;
    }

    /** Esfera de ki que viaja hacia el rival. */
    public static GreenfootImage esferaKi(Color color, int tam, int fase)
    {
        int pulso = (int) (3 * Math.sin(fase * 0.8));
        int t = tam + pulso;
        GreenfootImage img = new GreenfootImage(tam + 26, tam + 26);
        int cx = img.getWidth() / 2, cy = img.getHeight() / 2;

        img.setColor(Config.conAlfa(color, 60));
        img.fillOval(cx - t / 2 - 10, cy - t / 2 - 10, t + 20, t + 20);
        img.setColor(Config.conAlfa(color, 150));
        img.fillOval(cx - t / 2 - 4, cy - t / 2 - 4, t + 8, t + 8);
        img.setColor(Config.aclarar(color, 0.35));
        img.fillOval(cx - t / 2, cy - t / 2, t, t);
        img.setColor(new Color(255, 255, 255, 235));
        img.fillOval(cx - t / 4, cy - t / 4, t / 2, t / 2);
        return img;
    }

    /** Rayo horizontal tipo Kamehameha. */
    public static GreenfootImage rayoKi(Color color, int largo, int grosor, int fase)
    {
        int g = Math.max(6, grosor + (int) (4 * Math.sin(fase * 0.9)));
        GreenfootImage img = new GreenfootImage(Math.max(1, largo), g + 30);
        int cy = img.getHeight() / 2;

        img.setColor(Config.conAlfa(color, 70));
        redondeado(img, 0, cy - (g + 22) / 2, largo, g + 22, (g + 22) / 2, Config.conAlfa(color, 70));
        redondeado(img, 0, cy - (g + 10) / 2, largo, g + 10, (g + 10) / 2, Config.conAlfa(color, 160));
        redondeado(img, 0, cy - g / 2, largo, g, g / 2, Config.aclarar(color, 0.3));
        redondeado(img, 6, cy - g / 6, largo - 12, Math.max(2, g / 3), g / 6,
                   new Color(255, 255, 255, 240));
        return img;
    }

    /** Halo de objetivo: anillo pulsante detras del rival. */
    public static GreenfootImage halo(int tam, int fase)
    {
        int extra = (int) (5 * Math.sin(fase * 0.35));
        int t = tam + extra;
        GreenfootImage img = new GreenfootImage(tam + 24, tam + 24);
        int cx = img.getWidth() / 2, cy = img.getHeight() / 2;

        img.setColor(new Color(255, 220, 60, 55));
        img.fillOval(cx - t / 2, cy - t / 2, t, t);
        img.setColor(new Color(255, 230, 90, 210));
        for (int k = 0; k < 4; k++)
        {
            img.drawOval(cx - t / 2 - k, cy - t / 2 - k, t + 2 * k, t + 2 * k);
        }
        return img;
    }

    /** Chispa de impacto. */
    public static GreenfootImage chispa(Color color, int tam)
    {
        GreenfootImage img = new GreenfootImage(tam + 6, tam + 6);
        img.setColor(Config.conAlfa(color, 120));
        img.fillOval(0, 0, tam + 6, tam + 6);
        img.setColor(Config.aclarar(color, 0.5));
        img.fillOval(3, 3, tam, tam);
        return img;
    }
}
