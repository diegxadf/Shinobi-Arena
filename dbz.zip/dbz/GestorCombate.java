import greenfoot.*;

/**
 * Pasos 6, 10, 13 a 18 de la guia: el cerebro del combate.
 *
 * Driver atendido: CLARIDAD DEL TURNO, PREVENCION DE ERRORES y CONSISTENCIA.
 *
 * La maquina de estados es exactamente la de la guia:
 *
 *   TURNO_JUGADOR -> ANIMANDO_JUGADOR -> TURNO_ENEMIGO -> ANIMANDO_ENEMIGO -> ...
 *                                                                  -> FIN
 *
 * Los estados ANIMANDO son la barrera de consistencia: mientras el juego esta
 * resolviendo algo, seleccionarAccion() rechaza cualquier clic y los botones se
 * apagan. Asi es imposible ejecutar dos acciones en el mismo turno.
 *
 * Todo el resto (ki, criticos, guardia, aturdimiento, transformacion) se apoya
 * en esa misma maquina, sin agregarle estados nuevos: la accion elegida decide
 * COMO se anima y COMO se resuelve, no el gestor.
 */
public class GestorCombate
{
    public enum Estado { TURNO_JUGADOR, ANIMANDO_JUGADOR, TURNO_ENEMIGO, ANIMANDO_ENEMIGO, FIN }

    private final JuegoTurnos mundo;
    private final Ficha fichaJugador;
    private final Ficha fichaEnemigo;

    private GuerreroJugador jugador;
    private GuerreroEnemigo enemigo;

    private Aura auraJugador, auraEnemigo;
    private BarraHP barraJugador, barraEnemigo;
    private BarraKi kiJugador, kiEnemigo;
    private IndicadorTurno indicador;
    private IndicadorObjetivo halo;
    private RegistroCombate registro;
    private BotonAccion[] botones;

    private Estado estado;
    private AccionCombate accionActual;
    private AccionCombate accionEnemigo;

    private int contadorAnimacion = 0;
    private int xJugadorOriginal, xEnemigoOriginal;
    private boolean proyectilLanzado = false;
    private boolean transformacionAplicada = false;

    public GestorCombate(JuegoTurnos mundo, Ficha fichaJugador, Ficha fichaEnemigo)
    {
        this.mundo = mundo;
        this.fichaJugador = fichaJugador;
        this.fichaEnemigo = fichaEnemigo;
    }

    // ==================================================================
    // Armado del combate
    // ==================================================================
    public void iniciar()
    {
        jugador = new GuerreroJugador(fichaJugador);
        enemigo = new GuerreroEnemigo(fichaEnemigo);
        mundo.addObject(jugador, Config.X_JUGADOR, Config.Y_PELEA);
        mundo.addObject(enemigo, Config.X_ENEMIGO, Config.Y_PELEA);
        xJugadorOriginal = jugador.getX();
        xEnemigoOriginal = enemigo.getX();

        auraJugador = new Aura(jugador);
        auraEnemigo = new Aura(enemigo);
        mundo.addObject(auraJugador, Config.X_JUGADOR, Config.Y_PELEA);
        mundo.addObject(auraEnemigo, Config.X_ENEMIGO, Config.Y_PELEA);

        halo = new IndicadorObjetivo(enemigo);
        mundo.addObject(halo, Config.X_ENEMIGO, Config.Y_PELEA);

        crearBarras();
        crearBotones();

        indicador = new IndicadorTurno();
        mundo.addObject(indicador, Config.ANCHO / 2, 34);

        registro = new RegistroCombate();
        mundo.addObject(registro, Config.ANCHO / 2, 452);
        registro.mostrar(jugador.getNombre() + " contra " + enemigo.getNombre()
                         + ": elige tu tecnica (teclas 1 a 6 o clic).", Config.BLANCO);

        estado = Estado.TURNO_JUGADOR;
        actualizarInterfaz();
    }

    private void crearBarras()
    {
        barraJugador = new BarraHP(jugador, Config.NARANJA);
        barraEnemigo = new BarraHP(enemigo, Config.ROJO);
        kiJugador = new BarraKi(jugador);
        kiEnemigo = new BarraKi(enemigo);
        mundo.addObject(barraJugador, 185,  96);
        mundo.addObject(kiJugador,    185, 131);
        mundo.addObject(barraEnemigo, 775,  96);
        mundo.addObject(kiEnemigo,    775, 131);
    }

    private void crearBotones()
    {
        AccionCombate[] acciones = jugador.getAcciones();
        botones = new BotonAccion[acciones.length];
        int[] columnas = { 165, 480, 795 };
        int[] filas    = { 506, 584 };
        for (int i = 0; i < acciones.length; i++)
        {
            botones[i] = new BotonAccion(acciones[i], this, i + 1);
            mundo.addObject(botones[i], columnas[i % 3], filas[i / 3]);
        }
    }

    // ==================================================================
    // Bucle principal (lo llama JuegoTurnos.act)
    // ==================================================================
    public void actualizar()
    {
        leerTeclado();

        if (estado == Estado.TURNO_JUGADOR)
        {
            // Si el jugador quedo aturdido, pierde el turno.
            if (jugador.estaAturdida())
            {
                jugador.descontarAturdimiento();
                texto("TURNO PERDIDO", new Color(255, 220, 90), 22,
                      jugador.getX(), jugador.getY() - 118);
                registro.mostrar(jugador.getNombre()
                                 + " esta aturdido y pierde el turno.",
                                 new Color(255, 220, 90));
                estado = Estado.TURNO_ENEMIGO;
                actualizarInterfaz();
            }
        }
        else if (estado == Estado.ANIMANDO_JUGADOR) animar(true);
        else if (estado == Estado.TURNO_ENEMIGO)    iniciarTurnoEnemigo();
        else if (estado == Estado.ANIMANDO_ENEMIGO) animar(false);
    }

    /** Atajos de teclado: 1..6 para las tecnicas, R para reiniciar. */
    private void leerTeclado()
    {
        String tecla = Greenfoot.getKey();
        if (tecla == null) return;

        if (tecla.equals("r"))
        {
            Greenfoot.setWorld(new MenuWorld());
            return;
        }
        if (tecla.equals("m")) { Sonidos.alternarSilencio(); return; }
        if (botones == null) return;

        try
        {
            int n = Integer.parseInt(tecla);
            if (n >= 1 && n <= botones.length)
            {
                BotonAccion boton = botones[n - 1];
                if (boton.estaHabilitado() || !Config.VALIDAR_ESTADO)
                {
                    seleccionarAccion(boton.getAccion());
                }
            }
        }
        catch (NumberFormatException e)
        {
            // cualquier otra tecla se ignora
        }
    }

    // ==================================================================
    // Paso 10: seleccionar una accion sin romper el turno
    // ==================================================================
    public void seleccionarAccion(AccionCombate accion)
    {
        // ESTA es la barrera de consistencia de la guia (Experimento D).
        if (Config.VALIDAR_ESTADO && estado != Estado.TURNO_JUGADOR) return;
        if (!jugador.puedePagar(accion)) return;
        if (accion.getTipo() == AccionCombate.Tipo.TRANSFORMACION
            && !jugador.puedeTransformarse()) return;

        accionActual = accion;
        estado = Estado.ANIMANDO_JUGADOR;
        contadorAnimacion = 0;
        proyectilLanzado = false;
        transformacionAplicada = false;
        jugador.gastarKi(accion.getCostoKi());

        registro.mostrar(jugador.getNombre() + " prepara " + accion.getNombre() + "...",
                         accion.getColor());
        Sonidos.reproducir("boton.wav");
        sonidoDeInicio(accion);
        actualizarInterfaz();
    }

    // ==================================================================
    // Pasos 14 y 17: animaciones
    // ==================================================================
    private void animar(boolean esJugador)
    {
        Unidad atacante       = esJugador ? jugador : enemigo;
        Unidad objetivo       = esJugador ? enemigo : jugador;
        Aura   aura           = esJugador ? auraJugador : auraEnemigo;
        AccionCombate accion  = esJugador ? accionActual : accionEnemigo;
        int    direccion      = esJugador ? 1 : -1;
        int    xOriginal      = esJugador ? xJugadorOriginal : xEnemigoOriginal;

        contadorAnimacion++;
        int total = accion.ciclosAnimacion();

        switch (accion.getTipo())
        {
            case FISICO:
            {
                int mitad = total / 2;
                if (contadorAnimacion == 1) atacante.setPose(Recursos.ATAQUE);
                if (contadorAnimacion <= mitad)
                {
                    atacante.setLocation(atacante.getX() + direccion * 14, atacante.getY());
                }
                else if (contadorAnimacion < total)
                {
                    atacante.setLocation(atacante.getX() - direccion * 14, atacante.getY());
                }
                else
                {
                    atacante.setLocation(xOriginal, Config.Y_PELEA);
                    resolver(esJugador);
                }
                break;
            }

            case KI:
            case ESPECIAL:
            {
                int carga = total / 2;
                if (contadorAnimacion <= carga)
                {
                    atacante.setPose(Recursos.CARGA);
                    aura.encender(6);
                    if (contadorAnimacion % 2 == 0)
                    {
                        Particula.carga(mundo, atacante.getX(), atacante.getY() - 60,
                                        accion.getColor());
                    }
                    int temblor = (contadorAnimacion % 4 < 2) ? 3 : -3;
                    atacante.setLocation(xOriginal + temblor, Config.Y_PELEA);
                }
                else if (!proyectilLanzado)
                {
                    atacante.setLocation(xOriginal, Config.Y_PELEA);
                    atacante.setPose(Recursos.ATAQUE);
                    lanzarProyectil(atacante, objetivo, accion, direccion, total - carga);
                    proyectilLanzado = true;
                }
                else if (contadorAnimacion >= total)
                {
                    resolver(esJugador);
                }
                break;
            }

            case GUARDIA:
            {
                if (contadorAnimacion <= 4)
                {
                    atacante.setLocation(atacante.getX() - direccion * 5, atacante.getY());
                }
                else if (contadorAnimacion == 5)
                {
                    aura.encender(10);
                }
                else if (contadorAnimacion >= total)
                {
                    atacante.setLocation(xOriginal, Config.Y_PELEA);
                    resolver(esJugador);
                }
                break;
            }

            case CURA:
            {
                aura.encender(5);
                if (contadorAnimacion % 2 == 0)
                {
                    Particula.carga(mundo, atacante.getX(), atacante.getY() - 60, Config.VERDE);
                }
                if (contadorAnimacion >= total) resolver(esJugador);
                break;
            }

            case TRANSFORMACION:
            {
                aura.encender(8);
                int amplitud = 2 + contadorAnimacion / 8;
                int temblor = (contadorAnimacion % 4 < 2) ? amplitud : -amplitud;
                atacante.setLocation(xOriginal + temblor, Config.Y_PELEA);
                if (contadorAnimacion % 2 == 0)
                {
                    Particula.carga(mundo, atacante.getX(), atacante.getY() - 60, Config.DORADO);
                }
                if (!transformacionAplicada && contadorAnimacion >= total - 14)
                {
                    transformacionAplicada = true;
                    atacante.transformar();
                    mundo.addObject(new Destello(new Color(255, 245, 200), 14),
                                    Config.ANCHO / 2, Config.ALTO / 2);
                    Particula.impacto(mundo, atacante.getX(), atacante.getY(),
                                      Config.DORADO, 30);
                    Efecto.lanzar(mundo, "destello.png", atacante.getX(),
                                  atacante.getY() - 20, 16, 1.6);
                    texto(atacante.getNombre().toUpperCase() + "!", Config.DORADO, 32,
                          atacante.getX(), atacante.getY() - 130);
                    Sonidos.reproducir("transformacion.wav");
                    actualizarBarras();
                }
                if (contadorAnimacion >= total)
                {
                    atacante.setLocation(xOriginal, Config.Y_PELEA);
                    resolver(esJugador);
                }
                break;
            }
        }
    }

    /**
     * Sonido que abre cada accion. Cada tipo suena distinto para que el turno
     * del enemigo se entienda sin leer el cartel.
     */
    private void sonidoDeInicio(AccionCombate accion)
    {
        switch (accion.getTipo())
        {
            case FISICO:         Sonidos.reproducir("golpe.wav");    break;
            case KI:
            case ESPECIAL:       Sonidos.reproducir("carga.wav");    break;
            case GUARDIA:        Sonidos.reproducir("guardia.wav");  break;
            case CURA:           Sonidos.reproducir("cura.wav");     break;
            case TRANSFORMACION: Sonidos.reproducir("carga.wav");    break;
        }
    }

    private void lanzarProyectil(Unidad atacante, Unidad objetivo, AccionCombate accion,
                                 int direccion, int ciclos)
    {
        int distancia = Math.abs(objetivo.getX() - atacante.getX()) - 60;
        int x = atacante.getX() + direccion * 70;
        int y = atacante.getY() - 20;     // a la altura de las manos

        if (accion.getTipo() == AccionCombate.Tipo.ESPECIAL)
        {
            mundo.addObject(OndaKi.rayo(accion.getColor(), direccion, distancia, ciclos), x, y);
            (atacante == jugador ? auraJugador : auraEnemigo).encender(ciclos);
        }
        else
        {
            int velocidad = Math.max(8, distancia / Math.max(1, ciclos - 3));
            mundo.addObject(new OndaKi(accion.getColor(), direccion, 34, velocidad, ciclos), x, y);
        }
        Sonidos.reproducir(accion.getTipo() == AccionCombate.Tipo.ESPECIAL
                           ? "kamehameha.wav" : "rafaga.wav");
    }

    // ==================================================================
    // Pasos 15 y 17: resolver la accion (aqui viven las reglas)
    // ==================================================================
    private void resolver(boolean esJugador)
    {
        Unidad atacante = esJugador ? jugador : enemigo;
        Unidad objetivo = esJugador ? enemigo : jugador;
        AccionCombate accion = esJugador ? accionActual : accionEnemigo;

        // La guardia propia dura hasta que este peleador vuelve a actuar.
        atacante.setDefendiendo(false);
        atacante.setPose(Recursos.IDLE);

        int xTexto = objetivo.getX();
        int yTexto = objetivo.getY() - 118;

        switch (accion.getTipo())
        {
            case GUARDIA:
            {
                atacante.setDefendiendo(true);
                atacante.ganarKi(accion.getGananciaKi());
                texto("GUARDIA  +" + accion.getGananciaKi() + " KI", Config.VERDE, 22,
                      atacante.getX(), atacante.getY() - 118);
                registro.mostrar(atacante.getNombre() + " se cubre: el proximo golpe"
                                 + " le hara la mitad de dano.", Config.VERDE);
                break;
            }

            case CURA:
            {
                int curado = atacante.curar(accion.getCuracion());
                texto("+" + curado + " HP", Config.VERDE, 26,
                      atacante.getX(), atacante.getY() - 118);
                registro.mostrar(atacante.getNombre() + " se regenera y recupera "
                                 + curado + " HP.", Config.VERDE);
                break;
            }

            case TRANSFORMACION:
            {
                registro.mostrar(atacante.getNombre() + " se transforma: a partir de ahora"
                                 + " su dano se multiplica por "
                                 + atacante.getFicha().multiplicadorTransformacion + ".",
                                 Config.DORADO);
                break;
            }

            default:
            {
                if (!accion.acierta())
                {
                    texto("FALLO", Config.BLANCO, 26, xTexto, yTexto);
                    Sonidos.reproducir("fallo.wav");
                    registro.mostrar(atacante.getNombre() + " falla "
                                     + accion.getNombre() + ".", new Color(205, 208, 220));
                }
                else
                {
                    boolean critico = accion.esCritico();
                    boolean cubierto = objetivo.estaDefendiendo();

                    double bruto = accion.getDanio() * atacante.multiplicadorDanio();
                    if (critico) bruto *= Config.MULT_CRITICO;
                    int aplicado = objetivo.recibirDanio((int) Math.round(bruto));

                    Particula.impacto(mundo, objetivo.getX(), objetivo.getY() - 20,
                                      accion.getColor(), critico ? 26 : 14);
                    Efecto.lanzar(mundo, "impacto.png", objetivo.getX(),
                                  objetivo.getY() - 20, critico ? 14 : 10,
                                  critico ? 0.9 : 0.4);

                    if (critico)
                    {
                        mundo.addObject(new Destello(new Color(255, 225, 150), 8),
                                        Config.ANCHO / 2, Config.ALTO / 2);
                        texto("CRITICO  -" + aplicado + " HP", new Color(255, 190, 60), 30,
                              xTexto, yTexto);
                    }
                    else
                    {
                        texto("-" + aplicado + " HP",
                              esJugador ? Config.DORADO : Config.ROJO, 26, xTexto, yTexto);
                    }

                    if (cubierto)
                    {
                        texto("BLOQUEO -50%", new Color(120, 230, 255), 18,
                              objetivo.getX(), objetivo.getY() - 70);
                    }

                    String mensaje = atacante.getNombre() + " conecta " + accion.getNombre()
                                   + ": " + aplicado + " de dano";
                    if (critico)  mensaje += " (CRITICO x2)";
                    if (cubierto) mensaje += " (bloqueado a la mitad)";
                    registro.mostrar(mensaje + ".", accion.getColor());
                    Sonidos.reproducir(critico ? "critico.wav" : "impacto.wav");

                    if (accion.aturde() && objetivo.estaViva())
                    {
                        objetivo.aturdir(1);
                        texto("ATURDIDO", new Color(255, 220, 90), 20,
                              objetivo.getX(), objetivo.getY() - 70);
                    }
                }
                atacante.ganarKi(accion.getGananciaKi());
                break;
            }
        }

        actualizarBarras();

        if (!objetivo.estaViva())
        {
            terminarCombate(esJugador);
            return;
        }

        estado = esJugador ? Estado.TURNO_ENEMIGO : Estado.TURNO_JUGADOR;
        actualizarInterfaz();
    }

    // ==================================================================
    // Paso 16: turno del enemigo
    // ==================================================================
    private void iniciarTurnoEnemigo()
    {
        if (enemigo.estaAturdida())
        {
            enemigo.descontarAturdimiento();
            texto("TURNO PERDIDO", new Color(255, 220, 90), 22,
                  enemigo.getX(), enemigo.getY() - 118);
            registro.mostrar(enemigo.getNombre() + " esta aturdido y pierde el turno.",
                             new Color(255, 220, 90));
            estado = Estado.TURNO_JUGADOR;
            actualizarInterfaz();
            return;
        }

        accionEnemigo = enemigo.elegirAccion(jugador);
        enemigo.gastarKi(accionEnemigo.getCostoKi());
        estado = Estado.ANIMANDO_ENEMIGO;
        contadorAnimacion = 0;
        proyectilLanzado = false;
        transformacionAplicada = false;
        registro.mostrar(enemigo.getNombre() + " prepara " + accionEnemigo.getNombre() + "...",
                         accionEnemigo.getColor());
        sonidoDeInicio(accionEnemigo);
        actualizarInterfaz();
    }

    // ==================================================================
    // Paso 18: final del combate
    // ==================================================================
    private void terminarCombate(boolean victoria)
    {
        estado = Estado.FIN;
        halo.setVisible(false);
        actualizarBotones();

        String titulo = victoria ? "VICTORIA" : "DERROTA";
        Color  color  = victoria ? Config.DORADO : Config.ROJO;

        indicador.mostrar(victoria ? "Has ganado el combate" : "Has sido derrotado",
                          color, false);
        registro.mostrar(victoria
                         ? enemigo.getNombre() + " cae derrotado. Pulsa R para volver al menu."
                         : jugador.getNombre() + " no puede continuar. Pulsa R para reintentar.",
                         color);

        mundo.addObject(new Destello(victoria ? new Color(255, 245, 210) : new Color(120, 0, 0), 16),
                        Config.ANCHO / 2, Config.ALTO / 2);
        Particula.impacto(mundo, victoria ? enemigo.getX() : jugador.getX(),
                          Config.Y_PELEA, color, 34);
        mundo.addObject(new Cartel(titulo, "R = volver al menu", color),
                        Config.ANCHO / 2, 250);
        Sonidos.detenerMusica();
        Sonidos.reproducir(victoria ? "victoria.wav" : "derrota.wav");
    }

    // ==================================================================
    // Interfaz
    // ==================================================================
    private void actualizarInterfaz()
    {
        actualizarBotones();
        halo.setVisible(estado == Estado.TURNO_JUGADOR);

        if (estado == Estado.TURNO_JUGADOR)
        {
            indicador.mostrar("TU TURNO - elige una tecnica", Config.VERDE, true);
        }
        else if (estado == Estado.ANIMANDO_JUGADOR)
        {
            indicador.mostrar("Ejecutando " + accionActual.getNombre() + "...",
                              Config.DORADO, false);
        }
        else if (estado == Estado.TURNO_ENEMIGO || estado == Estado.ANIMANDO_ENEMIGO)
        {
            indicador.mostrar("Turno de " + enemigo.getNombre(), Config.ROJO, false);
        }
    }

    private void actualizarBotones()
    {
        boolean turno = estado == Estado.TURNO_JUGADOR;
        for (BotonAccion boton : botones)
        {
            AccionCombate accion = boton.getAccion();
            boolean disponible = accion.getTipo() != AccionCombate.Tipo.TRANSFORMACION
                              || jugador.puedeTransformarse();
            boton.setEstado(turno, jugador.puedePagar(accion), disponible);
        }
    }

    private void actualizarBarras()
    {
        barraJugador.actualizar();
        barraEnemigo.actualizar();
        kiJugador.actualizar();
        kiEnemigo.actualizar();
    }

    private void texto(String mensaje, Color color, int tam, int x, int y)
    {
        if (!Config.AYUDAS_VISUALES) return;
        mundo.addObject(new TextoFlotante(mensaje, color, tam), x, y);
    }

    public Estado getEstado()          { return estado; }
    public GuerreroJugador getJugador() { return jugador; }
    public GuerreroEnemigo getEnemigo() { return enemigo; }
}
