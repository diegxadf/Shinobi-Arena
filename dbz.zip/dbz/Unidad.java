import greenfoot.*;

/**
 * Paso 3 de la guia: clase base de todo peleador.
 *
 * Driver atendido: MODULARIDAD y CONSISTENCIA.
 * Mantiene el ESTADO REAL del combatiente (HP, ki, guardia, aturdimiento,
 * transformacion). La interfaz nunca guarda numeros propios: las barras y los
 * botones leen de aqui, asi que lo que se ve siempre es lo que vale.
 *
 * Sobre la guia base se agregan tres estados que pedia la seccion 28:
 * defensa (Defender), aturdimiento (estados temporales) y transformacion.
 */
public abstract class Unidad extends Actor
{
    protected final Ficha ficha;

    private int hp;
    private int ki;
    private boolean transformado   = false;
    private boolean defendiendo    = false;
    private int     turnosAturdido = 0;

    private final boolean miraDerecha;
    private int fase = 0;
    private int contador = 0;
    /** Pose actual: Recursos.IDLE, ATAQUE o CARGA. La cambia el gestor. */
    private int pose = Recursos.IDLE;

    public Unidad(Ficha ficha, boolean miraDerecha)
    {
        this.ficha = ficha;
        this.miraDerecha = miraDerecha;
        this.hp = ficha.hpMaximo;
        this.ki = Math.min(Config.KI_INICIAL, ficha.kiMaximo);
        actualizarImagen();
    }

    /** Respiracion: cambia de fase cada 8 ciclos. Es animacion pasiva. */
    public void act()
    {
        contador++;
        if (contador % 8 == 0)
        {
            fase = (fase + 1) % 4;
            actualizarImagen();
        }
    }

    public void actualizarImagen()
    {
        GreenfootImage img = Recursos.peleador(ficha, transformado, pose, fase, miraDerecha);
        if (img == null)
        {
            // Sin archivos en images/: se dibuja el peleador por codigo y se
            // coloca en el mismo lienzo, para que los pies sigan en el suelo.
            int respiro = (fase == 1 || fase == 3) ? 1 : (fase == 2 ? 2 : 0);
            img = Recursos.sobreLienzo(
                      FabricaImagenes.guerrero(ficha.estilo, transformado, 0, miraDerecha),
                      respiro, 18);
        }
        setImage(img);
    }

    /** La pose es parte del feedback: el gestor la cambia al atacar o cargar. */
    public void setPose(int nuevaPose)
    {
        if (pose == nuevaPose) return;
        pose = nuevaPose;
        actualizarImagen();
    }

    public int getPose() { return pose; }

    /** true si este peleador ya trae su propia aura dibujada en el sprite. */
    public boolean auraEnSprite()
    {
        return transformado && Recursos.tieneTransformado(ficha);
    }

    // ------------------------------------------------------------------
    // Dano y vida
    // ------------------------------------------------------------------

    /**
     * Aplica dano teniendo en cuenta la guardia.
     * @return el dano realmente aplicado (para poder mostrarlo en pantalla).
     */
    public int recibirDanio(int cantidad)
    {
        if (defendiendo)
        {
            cantidad = (int) Math.round(cantidad * Config.REDUCCION_GUARDIA);
            defendiendo = false;          // la guardia solo aguanta un golpe
        }
        hp -= cantidad;
        if (hp < 0) hp = 0;
        return cantidad;
    }

    public int curar(int cantidad)
    {
        int antes = hp;
        hp = Math.min(ficha.hpMaximo, hp + cantidad);
        return hp - antes;
    }

    public boolean estaViva()        { return hp > 0; }
    public int     getHP()           { return hp; }
    public int     getHPMaximo()     { return ficha.hpMaximo; }
    public double  proporcionVida()  { return (double) hp / ficha.hpMaximo; }

    // ------------------------------------------------------------------
    // Ki
    // ------------------------------------------------------------------
    public int     getKi()          { return ki; }
    public int     getKiMaximo()    { return ficha.kiMaximo; }
    public double  proporcionKi()   { return (double) ki / ficha.kiMaximo; }

    public boolean puedePagar(AccionCombate accion)
    {
        return ki >= accion.getCostoKi();
    }

    public void gastarKi(int cantidad)
    {
        ki = Math.max(0, ki - cantidad);
    }

    public void ganarKi(int cantidad)
    {
        ki = Math.min(ficha.kiMaximo, ki + cantidad);
    }

    // ------------------------------------------------------------------
    // Estados temporales
    // ------------------------------------------------------------------
    public boolean estaDefendiendo()          { return defendiendo; }
    public void    setDefendiendo(boolean v)  { defendiendo = v; }

    public boolean estaAturdida()             { return turnosAturdido > 0; }
    public void    aturdir(int turnos)        { turnosAturdido = turnos; }
    public void    descontarAturdimiento()    { if (turnosAturdido > 0) turnosAturdido--; }

    public boolean estaTransformada()         { return transformado; }
    public boolean puedeTransformarse()
    {
        return !transformado && ficha.accionTransformacion() != null;
    }

    public void transformar()
    {
        transformado = true;
        actualizarImagen();
    }

    /** Multiplicador de dano que aplica este peleador al atacar. */
    public double multiplicadorDanio()
    {
        return transformado ? ficha.multiplicadorTransformacion : 1.0;
    }

    // ------------------------------------------------------------------
    // Identidad
    // ------------------------------------------------------------------
    public Ficha  getFicha()  { return ficha; }
    public String getNombre()
    {
        return transformado && ficha.nombreTransformado != null
             ? ficha.nombreTransformado
             : ficha.nombre;
    }
    public Color getColorAura()
    {
        return transformado ? ficha.estilo.auraTransformada : ficha.estilo.aura;
    }
    public AccionCombate[] getAcciones() { return ficha.acciones; }
}
