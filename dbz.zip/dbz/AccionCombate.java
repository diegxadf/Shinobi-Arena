import greenfoot.*;

/**
 * Paso 5 de la guia: cada accion del combate es un OBJETO, no un if.
 *
 * Driver atendido: MANTENIBILIDAD y BALANCE.
 * Agregar un ataque nuevo = crear una AccionCombate mas en Fichas. No hay que
 * tocar el gestor, ni los botones, ni la animacion.
 *
 * Respecto de la guia base se agregan cuatro campos que sostienen los desafios
 * de extension de la seccion 28: costo de ki, ganancia de ki, probabilidad de
 * aturdir y curacion.
 */
public class AccionCombate
{
    /** El tipo decide COMO se anima y COMO se resuelve la accion. */
    public enum Tipo { FISICO, KI, ESPECIAL, GUARDIA, CURA, TRANSFORMACION }

    private final String nombre;
    private final int    danio;
    private final int    probabilidadAcierto;
    private final int    costoKi;
    private final int    gananciaKi;
    private final int    probabilidadAturdir;
    private final int    curacion;
    private final Tipo   tipo;
    private final Color  color;

    public AccionCombate(String nombre, int danio, int probabilidadAcierto,
                         int costoKi, int gananciaKi, int probabilidadAturdir,
                         int curacion, Tipo tipo, Color color)
    {
        this.nombre = nombre;
        this.danio = danio;
        this.probabilidadAcierto = probabilidadAcierto;
        this.costoKi = costoKi;
        this.gananciaKi = gananciaKi;
        this.probabilidadAturdir = probabilidadAturdir;
        this.curacion = curacion;
        this.tipo = tipo;
        this.color = color;
    }

    /** Ataque cuerpo a cuerpo: no gasta ki, lo carga. */
    public static AccionCombate fisico(String nombre, int danio, int acierto,
                                       int gananciaKi, int aturdir, Color color)
    {
        return new AccionCombate(nombre, danio, acierto, 0, gananciaKi, aturdir, 0,
                                 Tipo.FISICO, color);
    }

    /** Rafaga de energia: gasta ki. */
    public static AccionCombate ki(String nombre, int danio, int acierto,
                                   int costoKi, Color color)
    {
        return new AccionCombate(nombre, danio, acierto, costoKi, 0, 0, 0,
                                 Tipo.KI, color);
    }

    /** Tecnica definitiva: mucho dano, poca precision, mucho ki. */
    public static AccionCombate especial(String nombre, int danio, int acierto,
                                         int costoKi, Color color)
    {
        return new AccionCombate(nombre, danio, acierto, costoKi, 0, 0, 0,
                                 Tipo.ESPECIAL, color);
    }

    /** Guardia: no hace dano, carga ki y reduce el siguiente golpe recibido. */
    public static AccionCombate guardia(String nombre, int gananciaKi, Color color)
    {
        return new AccionCombate(nombre, 0, 100, 0, gananciaKi, 0, 0,
                                 Tipo.GUARDIA, color);
    }

    /** Regeneracion: recupera HP propios. */
    public static AccionCombate cura(String nombre, int curacion, int costoKi, Color color)
    {
        return new AccionCombate(nombre, 0, 100, costoKi, 0, 0, curacion,
                                 Tipo.CURA, color);
    }

    /** Transformacion: no ataca, multiplica el dano futuro. */
    public static AccionCombate transformacion(String nombre, int costoKi, Color color)
    {
        return new AccionCombate(nombre, 0, 100, costoKi, 0, 0, 0,
                                 Tipo.TRANSFORMACION, color);
    }

    // ------------------------------------------------------------------
    // Consultas
    // ------------------------------------------------------------------
    public String getNombre()              { return nombre; }
    public int    getDanio()               { return danio; }
    public int    getProbabilidadAcierto() { return probabilidadAcierto; }
    public int    getCostoKi()             { return costoKi; }
    public int    getGananciaKi()          { return gananciaKi; }
    public int    getCuracion()            { return curacion; }
    public Tipo   getTipo()                { return tipo; }
    public Color  getColor()               { return color; }

    /** true si la accion hace dano (sirve para no animar impactos vacios). */
    public boolean esOfensiva()
    {
        return tipo == Tipo.FISICO || tipo == Tipo.KI || tipo == Tipo.ESPECIAL;
    }

    // ------------------------------------------------------------------
    // Tiradas de azar (toda la aleatoriedad del combate vive aqui)
    // ------------------------------------------------------------------
    public boolean acierta()
    {
        return Greenfoot.getRandomNumber(100) < probabilidadAcierto;
    }

    public boolean esCritico()
    {
        return Greenfoot.getRandomNumber(100) < Config.PROB_CRITICO;
    }

    public boolean aturde()
    {
        return probabilidadAturdir > 0
            && Greenfoot.getRandomNumber(100) < probabilidadAturdir;
    }

    /**
     * Valor esperado del dano: E[D] = P(acierto) * D.
     * Es la formula de la seccion 4.1 de la guia y la usa la IA enemiga para
     * decidir, de modo que "el ataque mas fuerte" no sea automaticamente el mejor.
     */
    public double esperanzaDanio()
    {
        return danio * (probabilidadAcierto / 100.0);
    }

    /** Ciclos de animacion que necesita esta accion. */
    public int ciclosAnimacion()
    {
        switch (tipo)
        {
            case FISICO:         return Config.CICLOS_FISICO;
            case KI:             return Config.CICLOS_KI;
            case ESPECIAL:       return Config.CICLOS_KI;
            case TRANSFORMACION: return Config.CICLOS_TRANSFOR;
            default:             return Config.CICLOS_GUARDIA;
        }
    }

    /** Texto corto que se muestra en el boton debajo del nombre. */
    public String descripcionCorta()
    {
        if (tipo == Tipo.GUARDIA)        return "Dano -50%  -  +" + gananciaKi + " KI";
        if (tipo == Tipo.CURA)           return "+" + curacion + " HP  -  KI " + costoKi;
        if (tipo == Tipo.TRANSFORMACION) return "Dano x1.5  -  KI " + costoKi;

        String texto = "DANO " + danio + "  -  " + probabilidadAcierto + "%";
        if (costoKi > 0)    texto += "  -  KI " + costoKi;
        if (gananciaKi > 0) texto += "  -  +" + gananciaKi + " KI";
        return texto;
    }
}
