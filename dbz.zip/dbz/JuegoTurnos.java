import greenfoot.*;

/**
 * Paso 1 de la guia: el mundo del combate.
 *
 * Driver atendido: MODULARIDAD.
 * El mundo casi no piensa: crea el escenario, fija el orden de dibujo y le pasa
 * el control al GestorCombate. Las reglas viven en el gestor, la apariencia en
 * FabricaImagenes y el estado en Unidad. Cada cosa se puede cambiar sin tocar
 * las otras dos.
 */
public class JuegoTurnos extends World
{
    private final GestorCombate combate;

    /** Constructor sin parametros: Greenfoot lo necesita para poder crear el mundo. */
    public JuegoTurnos()
    {
        this(Fichas.vegeta());
    }

    public JuegoTurnos(Ficha rival)
    {
        super(Config.ANCHO, Config.ALTO, 1);
        setBackground(FabricaImagenes.fondoArena());

        // Quien tapa a quien. El aura va al fondo, detras de los peleadores;
        // los carteles y textos van arriba de todo para que nada los oculte.
        setPaintOrder(Cartel.class, TextoFlotante.class, Destello.class,
                      BotonAccion.class, RegistroCombate.class, IndicadorTurno.class,
                      BarraHP.class, BarraKi.class,
                      Particula.class, OndaKi.class,
                      Unidad.class, IndicadorObjetivo.class, Aura.class);

        Sonidos.musica("combate.wav");
        combate = new GestorCombate(this, Fichas.goku(), rival);
        combate.iniciar();
    }

    public void act()
    {
        combate.actualizar();
    }

    /** Acceso al gestor (lo usan las pruebas automaticas del proyecto). */
    public GestorCombate getCombate()
    {
        return combate;
    }
}
