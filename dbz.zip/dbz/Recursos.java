import greenfoot.*;
import java.util.HashMap;

/**
 * Carga de sprites con respaldo dibujado por codigo.
 *
 * Driver atendido: PORTABILIDAD y TOLERANCIA A FALLOS.
 * Si la carpeta images/ tiene el .png se usa el sprite; si falta, el juego
 * sigue funcionando con la figura que dibuja FabricaImagenes. Por eso se puede
 * abrir el escenario aunque falten recursos, y cambiar un personaje es cambiar
 * un archivo, sin tocar codigo.
 *
 * Todos los peleadores se componen sobre un LIENZO del mismo tamano, alineados
 * por los pies. Asi cualquier sprite (alto o bajo, con aura o sin ella) pisa el
 * mismo suelo y el gestor no necesita saber cuanto mide cada personaje.
 *
 * Archivos esperados (todos miran a la DERECHA; el espejo lo hace esta clase):
 *   <prefijo>_idle.png     obligatorio para usar sprites
 *   <prefijo>_ataque.png   opcional
 *   <prefijo>_carga.png    opcional
 *   <prefijo>_t_idle.png   version transformada, opcional
 *   <prefijo>_t_ataque.png opcional
 */
public class Recursos
{
    /** Poses que puede pedir el gestor. */
    public static final int IDLE   = 0;
    public static final int ATAQUE = 1;
    public static final int CARGA  = 2;

    public static final int ANCHO_LIENZO = 240;
    public static final int ALTO_LIENZO  = 250;
    /** Separacion entre el borde inferior del lienzo y la planta de los pies. */
    public static final int MARGEN_PIE   = 4;

    /** Distancia entre el centro del actor y sus pies. La usa Config. */
    public static final int ALTURA_PIES = ALTO_LIENZO / 2 - MARGEN_PIE;

    private static final HashMap<String, GreenfootImage> cache
            = new HashMap<String, GreenfootImage>();

    // ------------------------------------------------------------------
    // Carga basica
    // ------------------------------------------------------------------

    /** Devuelve la imagen, o null si el archivo no existe. Cachea el resultado. */
    public static GreenfootImage cargar(String archivo)
    {
        if (cache.containsKey(archivo)) return cache.get(archivo);
        GreenfootImage img;
        try
        {
            img = new GreenfootImage(archivo);
        }
        catch (Throwable e)
        {
            img = null;     // el archivo no esta: se usara el dibujo por codigo
        }
        cache.put(archivo, img);
        return img;
    }

    public static boolean hay(String archivo)
    {
        return cargar(archivo) != null;
    }

    /** Version reflejada de un archivo, tambien cacheada. */
    private static GreenfootImage reflejada(String archivo)
    {
        String clave = archivo + "#espejo";
        if (cache.containsKey(clave)) return cache.get(clave);
        GreenfootImage base = cargar(archivo);
        GreenfootImage img = null;
        if (base != null)
        {
            img = new GreenfootImage(base);
            img.mirrorHorizontally();
        }
        cache.put(clave, img);
        return img;
    }

    // ------------------------------------------------------------------
    // Peleadores
    // ------------------------------------------------------------------

    /** Elige el archivo que corresponde a la pose pedida, con degradacion. */
    private static String archivoPose(Ficha ficha, boolean transformado, int pose)
    {
        String base = ficha.prefijo + (transformado ? "_t" : "");
        if (pose == ATAQUE && hay(base + "_ataque.png")) return base + "_ataque.png";
        if (pose == CARGA)
        {
            if (hay(base + "_carga.png"))  return base + "_carga.png";
            if (hay(base + "_ataque.png")) return base + "_ataque.png";
        }
        if (hay(base + "_idle.png")) return base + "_idle.png";
        return ficha.prefijo + "_idle.png";       // no tiene version transformada
    }

    /** true si este personaje tiene sprite propio para el estado transformado. */
    public static boolean tieneTransformado(Ficha ficha)
    {
        return hay(ficha.prefijo + "_t_idle.png");
    }

    /**
     * Imagen completa del peleador, ya colocada sobre el lienzo comun.
     * Devuelve null si no hay sprites: en ese caso el llamador dibuja por codigo.
     */
    public static GreenfootImage peleador(Ficha ficha, boolean transformado,
                                          int pose, int fase, boolean miraDerecha)
    {
        String archivo = archivoPose(ficha, transformado, pose);
        GreenfootImage sprite = miraDerecha ? cargar(archivo) : reflejada(archivo);
        if (sprite == null) return null;

        int respiro = (fase == 1 || fase == 3) ? 1 : (fase == 2 ? 2 : 0);
        return sobreLienzo(sprite, respiro, 0);
    }

    /** Coloca cualquier figura sobre el lienzo comun, alineada por los pies. */
    public static GreenfootImage sobreLienzo(GreenfootImage figura, int respiro, int extraAbajo)
    {
        GreenfootImage lienzo = new GreenfootImage(ANCHO_LIENZO, ALTO_LIENZO);
        lienzo.drawImage(figura,
                         (ANCHO_LIENZO - figura.getWidth()) / 2,
                         ALTO_LIENZO - MARGEN_PIE - figura.getHeight() - respiro + extraAbajo);
        return lienzo;
    }
}
