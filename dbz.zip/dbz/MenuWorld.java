import greenfoot.*;

/**
 * Pantalla de seleccion de rival.
 *
 * Concern atendido: USABILIDAD DE ENTRADA.
 * El juego empieza explicando sus tres reglas propias (turnos, ki y riesgo)
 * antes de la primera pelea, de modo que el usuario no tenga que descubrir por
 * prueba y error por que un boton esta apagado.
 */
public class MenuWorld extends World
{
    private BotonMenu[] tarjetas;

    public MenuWorld()
    {
        super(Config.ANCHO, Config.ALTO, 1);
        setBackground(fondoMenu());
        setPaintOrder(BotonMenu.class);

        Sonidos.musica("menu.wav");

        Ficha[] rivales = Fichas.rivales();
        tarjetas = new BotonMenu[rivales.length];
        int[] columnas = { 170, 480, 790 };
        for (int i = 0; i < rivales.length; i++)
        {
            tarjetas[i] = new BotonMenu(rivales[i], i + 1);
            addObject(tarjetas[i], columnas[i], 462);
        }
    }

    public void act()
    {
        String tecla = Greenfoot.getKey();
        if (tecla == null) return;
        try
        {
            int n = Integer.parseInt(tecla);
            if (n >= 1 && n <= tarjetas.length)
            {
                Greenfoot.setWorld(new JuegoTurnos(tarjetas[n - 1].getFicha()));
            }
        }
        catch (NumberFormatException e)
        {
            // otras teclas no hacen nada
        }
    }

    private GreenfootImage fondoMenu()
    {
        GreenfootImage img = FabricaImagenes.fondoArena();

        // Velo oscuro para que el texto se lea sobre el paisaje.
        img.setColor(new Color(10, 12, 22, 165));
        img.fill();

        // Goku transformado, a un costado del titulo.
        GreenfootImage goku = Recursos.cargar("goku_t_idle.png");
        if (goku != null)
        {
            img.drawImage(goku, 8, 8);
        }
        else
        {
            img.drawImage(FabricaImagenes.aura(Config.DORADO, 3, 160, 210), 0, 0);
            GreenfootImage dibujo = FabricaImagenes.guerrero(Estilo.goku(), true, 0, true);
            dibujo.scale(126, 180);
            img.drawImage(dibujo, 14, 12);
        }

        FabricaImagenes.textoCentrado(img, "SAGA Z", 72, Config.NARANJA, Config.ANCHO / 2, 16);
        FabricaImagenes.textoCentrado(img, "COMBATE POR TURNOS", 26, Config.DORADO,
                                      Config.ANCHO / 2, 92);

        FabricaImagenes.redondeado(img, 178, 132, 604, 124, 14, new Color(14, 16, 26, 210));
        FabricaImagenes.textoCentrado(img,
            "Turnos: eliges tecnica, se anima, se resuelve y responde el rival.",
            15, new Color(205, 212, 230), Config.ANCHO / 2, 142);
        FabricaImagenes.textoCentrado(img,
            "KI: el cuerpo a cuerpo y la guardia lo cargan; las tecnicas de energia lo gastan.",
            15, new Color(205, 212, 230), Config.ANCHO / 2, 166);
        FabricaImagenes.textoCentrado(img,
            "Riesgo: mas dano siempre significa menos probabilidad de acertar.",
            15, new Color(205, 212, 230), Config.ANCHO / 2, 190);
        FabricaImagenes.textoCentrado(img,
            "Teclas 1 a 6 para las tecnicas    -    R vuelve aqui    -    M silencia",
            14, new Color(255, 214, 120), Config.ANCHO / 2, 218);

        FabricaImagenes.textoCentrado(img, "ELIGE A TU RIVAL", 21, Config.BLANCO,
                                      Config.ANCHO / 2, 258);

        return img;
    }
}
