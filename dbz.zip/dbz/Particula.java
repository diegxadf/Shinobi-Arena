import greenfoot.*;

/**
 * Chispa de impacto o de carga de ki.
 *
 * Concern atendido: FEEDBACK INMEDIATO.
 * Marca el instante exacto del golpe. Es puro adorno si se la mira sola, pero
 * junto con el movimiento del atacante y el texto de dano forma la cadena
 * "accion -> impacto -> consecuencia" que pide la guia.
 */
public class Particula extends Actor
{
    private double vx, vy;
    private double x, y;
    private int vida;
    private final int vidaTotal;
    private final Color color;
    private final int tam;
    private final boolean gravedad;

    public Particula(Color color, double vx, double vy, int tam, int vida, boolean gravedad)
    {
        this.color = color;
        this.vx = vx;
        this.vy = vy;
        this.tam = tam;
        this.vida = vida;
        this.vidaTotal = vida;
        this.gravedad = gravedad;
        setImage(FabricaImagenes.chispa(color, tam));
    }

    protected void addedToWorld(World mundo)
    {
        x = getX();
        y = getY();
    }

    public void act()
    {
        x += vx;
        y += vy;
        if (gravedad) vy += 0.35;
        setLocation((int) x, (int) y);

        vida--;
        if (vida <= 0)
        {
            getWorld().removeObject(this);
            return;
        }
        double p = (double) vida / vidaTotal;
        GreenfootImage img = FabricaImagenes.chispa(color, Math.max(2, (int) (tam * p)));
        img.setTransparency((int) (255 * Math.min(1.0, p * 1.6)));
        setImage(img);
    }

    // ------------------------------------------------------------------
    // Emisores listos para usar
    // ------------------------------------------------------------------

    /** Estallido de impacto en un punto. */
    public static void impacto(World mundo, int x, int y, Color color, int cantidad)
    {
        if (!Config.AYUDAS_VISUALES) return;
        for (int i = 0; i < cantidad; i++)
        {
            double ang = Math.toRadians(Greenfoot.getRandomNumber(360));
            double vel = 2 + Greenfoot.getRandomNumber(40) / 10.0;
            mundo.addObject(new Particula(color,
                                Math.cos(ang) * vel, Math.sin(ang) * vel,
                                6 + Greenfoot.getRandomNumber(8),
                                16 + Greenfoot.getRandomNumber(12), true), x, y);
        }
    }

    /** Chispas que suben mientras el peleador carga energia. */
    public static void carga(World mundo, int x, int y, Color color)
    {
        if (!Config.AYUDAS_VISUALES) return;
        int dx = Greenfoot.getRandomNumber(120) - 60;
        mundo.addObject(new Particula(color, dx / 40.0, -2.4 - Greenfoot.getRandomNumber(20) / 10.0,
                            5 + Greenfoot.getRandomNumber(6), 20, false), x + dx, y + 60);
    }
}
