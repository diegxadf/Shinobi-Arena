import greenfoot.*;

/**
 * Barra de KI: el recurso que agregamos sobre la guia original.
 *
 * Concern atendido: VISIBILITY OF SYSTEM STATUS.
 * Sin esta barra el jugador no podria anticipar si le alcanza para el
 * Kamehameha, y los botones apagados por falta de ki pareceririan un error del
 * juego en vez de una regla. La barra explica POR QUE una accion no esta
 * disponible.
 */
public class BarraKi extends Actor
{
    private static final int ANCHO = 300;
    private static final int ALTO  = 22;
    /** Ancho util de la barra: el resto de la fila lo ocupa el numero. */
    private static final int CANAL = 232;

    private final Unidad unidad;
    private double mostrado;
    private int fase = 0;

    public BarraKi(Unidad unidad)
    {
        this.unidad = unidad;
        this.mostrado = unidad.getKi();
        actualizar();
    }

    public void act()
    {
        fase++;
        double objetivo = unidad.getKi();
        boolean lleno = unidad.getKi() >= unidad.getKiMaximo() && Config.AYUDAS_VISUALES;
        if (mostrado == objetivo && !lleno) return;
        if (mostrado == objetivo && fase % 5 != 0) return;
        mostrado += (objetivo - mostrado) * 0.2;
        if (Math.abs(objetivo - mostrado) < 0.4) mostrado = objetivo;
        actualizar();
    }

    public void actualizar()
    {
        GreenfootImage img = new GreenfootImage(ANCHO, ALTO);
        FabricaImagenes.redondeado(img, 0, 3, CANAL + 6, ALTO - 6, 8, new Color(16, 20, 34, 225));

        int x = 3, y = 6, ancho = CANAL, alto = ALTO - 12;
        int anchoKi = (int) (ancho * Math.max(0, mostrado) / unidad.getKiMaximo());

        Color base = Config.AZUL_KI;
        // Cuando el ki esta lleno el color late: avisa que hay tecnica definitiva.
        if (unidad.getKi() >= unidad.getKiMaximo() && Config.AYUDAS_VISUALES)
        {
            base = (fase % 20 < 10) ? Config.AZUL_KI : new Color(190, 240, 255);
        }
        FabricaImagenes.redondeado(img, x, y, anchoKi, alto, 4, base);
        FabricaImagenes.redondeado(img, x, y, anchoKi, Math.max(2, alto / 3), 2,
                                   new Color(255, 255, 255, 120));

        // Divisiones cada 25 de ki: sirven para "contar" cuanto falta.
        img.setColor(new Color(16, 20, 34, 200));
        for (int i = 1; i < 4; i++)
        {
            int mx = x + ancho * i / 4;
            img.drawLine(mx, y, mx, y + alto - 1);
        }

        GreenfootImage t = FabricaImagenes.texto(
                "KI " + unidad.getKi() + "/" + unidad.getKiMaximo(), 14,
                new Color(190, 235, 255));
        img.drawImage(t, ANCHO - t.getWidth(), (ALTO - t.getHeight()) / 2);
        setImage(img);
    }
}
