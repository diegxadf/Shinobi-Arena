import greenfoot.*;

/**
 * Musica y efectos del juego.
 *
 * Concern atendido: FEEDBACK MULTICANAL.
 * El sonido repite por el oido lo que la pantalla ya dice por la vista: cada
 * animacion tiene su efecto (golpe, carga, rafaga, bloqueo, critico, fallo),
 * asi que el usuario entiende el resultado aunque no este mirando los numeros.
 * Es la misma idea de la guia -la animacion comunica estado- aplicada al audio.
 *
 * Driver atendido: TOLERANCIA A FALLOS. Si un archivo no esta en sounds/, la
 * llamada se ignora en silencio y el juego sigue igual.
 *
 * Archivos usados (todos generados para este proyecto):
 *   musica : combate.wav, menu.wav
 *   efectos: boton.wav, golpe.wav, impacto.wav, critico.wav, fallo.wav,
 *            carga.wav, rafaga.wav, kamehameha.wav, guardia.wav, cura.wav,
 *            transformacion.wav, victoria.wav, derrota.wav
 *
 * Tecla M: silenciar o volver a activar todo.
 */
public class Sonidos
{
    private static final int VOLUMEN_MUSICA = 45;

    private static boolean silencio = false;
    private static GreenfootSound musica;
    private static String pistaActual = "";

    // ------------------------------------------------------------------
    // Efectos cortos
    // ------------------------------------------------------------------
    public static void reproducir(String archivo)
    {
        if (silencio) return;
        try
        {
            Greenfoot.playSound(archivo);
        }
        catch (Throwable e)
        {
            // El archivo no existe o el sistema no tiene audio disponible:
            // el juego sigue igual, solo que sin ese efecto. Se captura
            // Throwable y no Exception porque un audio ausente puede fallar
            // tambien con un Error de carga de clases.
        }
    }

    // ------------------------------------------------------------------
    // Musica de fondo
    // ------------------------------------------------------------------

    /** Pone en bucle la pista indicada. Si ya esta sonando, no la reinicia. */
    public static void musica(String archivo)
    {
        if (archivo.equals(pistaActual) && musica != null && musica.isPlaying()) return;
        detenerMusica();
        try
        {
            musica = new GreenfootSound(archivo);
            musica.setVolume(silencio ? 0 : VOLUMEN_MUSICA);
            musica.playLoop();
            pistaActual = archivo;
        }
        catch (Throwable e)
        {
            musica = null;
            pistaActual = "";
        }
    }

    public static void detenerMusica()
    {
        if (musica != null)
        {
            try { musica.stop(); } catch (Throwable e) { }
        }
        musica = null;
        pistaActual = "";
    }

    // ------------------------------------------------------------------
    // Silencio
    // ------------------------------------------------------------------
    public static void alternarSilencio()
    {
        silencio = !silencio;
        if (musica != null)
        {
            try { musica.setVolume(silencio ? 0 : VOLUMEN_MUSICA); } catch (Throwable e) { }
        }
    }

    public static boolean estaSilenciado()
    {
        return silencio;
    }
}
