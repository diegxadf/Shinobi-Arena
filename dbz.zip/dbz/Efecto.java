import greenfoot.*;

/**
 * Efecto de un solo uso basado en un sprite (impacto, destello de energia).
 *
 * Concern atendido: FEEDBACK INMEDIATO.
 * Marca el instante exacto del golpe con la misma estetica que los peleadores.
 * Si el archivo no existe no se crea nada: las particulas dibujadas por codigo
 * siguen cubriendo el mismo papel.
 */
public class Efecto extends Actor
{
    private final GreenfootImage base;
    private int vida;
    private final int vidaTotal;
    private final double crecimiento;

    private Efecto(GreenfootImage sprite, int vida, double crecimiento)
    {
        this.base = sprite;
        this.vida = vida;
        this.vidaTotal = vida;
        this.crecimiento = crecimiento;
        setImage(new GreenfootImage(sprite));
    }

    /**
     * Crea el efecto en el mundo si el sprite existe.
     * @param archivo     nombre del png en images/
     * @param crecimiento cuanto crece durante su vida (0 = tamano fijo)
     */
    public static void lanzar(World mundo, String archivo, int x, int y,
                              int vida, double crecimiento)
    {
        if (!Config.AYUDAS_VISUALES) return;
        GreenfootImage sprite = Recursos.cargar(archivo);
        if (sprite == null) return;
        mundo.addObject(new Efecto(sprite, vida, crecimiento), x, y);
    }

    public void act()
    {
        vida--;
        if (vida <= 0)
        {
            getWorld().removeObject(this);
            return;
        }
        double p = 1.0 - (double) vida / vidaTotal;      // 0 -> 1
        GreenfootImage img = new GreenfootImage(base);
        if (crecimiento > 0)
        {
            double f = 1.0 + crecimiento * p;
            img.scale(Math.max(1, (int) (base.getWidth() * f)),
                      Math.max(1, (int) (base.getHeight() * f)));
        }
        img.setTransparency((int) (255 * (1.0 - p * p)));
        setImage(img);
    }
}
