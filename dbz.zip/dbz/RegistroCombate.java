import greenfoot.*;

/**
 * Renglon de narracion del combate ("Goku usa Kamehameha. CRITICO: 72 de dano").
 *
 * Concern atendido: COMPRENSIBILIDAD.
 * Las animaciones muestran QUE paso; este texto explica POR QUE paso, que es lo
 * que permite entender una derrota en vez de sentirla arbitraria. Tambien
 * cubre el caso del usuario que mira la pantalla despues del golpe.
 */
public class RegistroCombate extends Actor
{
    private static final int ANCHO = 660;
    private static final int ALTO  = 34;

    private String mensaje = "";
    private Color  color   = Config.BLANCO;

    public RegistroCombate()
    {
        pintar();
    }

    public void mostrar(String mensaje, Color color)
    {
        this.mensaje = mensaje;
        this.color = color;
        pintar();
    }

    private void pintar()
    {
        GreenfootImage img = FabricaImagenes.panel(ANCHO, ALTO, 10,
                                 new Color(14, 16, 24, 190),
                                 Config.conAlfa(color, 160), 2);
        if (!mensaje.isEmpty())
        {
            FabricaImagenes.textoCentrado(img, mensaje, 16, color, ANCHO / 2, 6);
        }
        setImage(img);
    }
}
