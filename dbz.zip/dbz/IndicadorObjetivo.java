import greenfoot.*;

/**
 * Paso 19 de la guia: el halo que marca a quien se le va a pegar.
 *
 * Concern atendido: CLARIDAD DEL OBJETIVO.
 * Con un solo rival es feedback; en un combate 2 contra 2 (desafio de la
 * seccion 28) este mismo halo pasa a ser el mecanismo de seleccion. Por eso se
 * implementa como actor independiente y no como un dibujo dentro del enemigo.
 */
public class IndicadorObjetivo extends Actor
{
    private final Unidad objetivo;
    private boolean visible = false;
    private int fase = 0;

    public IndicadorObjetivo(Unidad objetivo)
    {
        this.objetivo = objetivo;
        setImage(new GreenfootImage(1, 1));
    }

    public void act()
    {
        setLocation(objetivo.getX(), objetivo.getY() + 20);
        if (!visible || !Config.AYUDAS_VISUALES)
        {
            setImage(new GreenfootImage(1, 1));
            return;
        }
        fase++;
        if (fase % 2 == 0) setImage(FabricaImagenes.halo(150, fase));
    }

    public void setVisible(boolean valor)
    {
        visible = valor;
    }
}
