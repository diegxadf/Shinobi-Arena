import greenfoot.*;

/**
 * Constantes de ajuste del combate y de la interfaz.
 *
 * Driver atendido: MANTENIBILIDAD y BALANCE.
 * Todo lo que la guia pide "experimentar" esta aqui: si se quiere repetir el
 * Experimento A (quitar ayudas visuales), B (cambiar tasas de acierto),
 * C (alargar animaciones) o D (permitir acciones durante ANIMANDO), se cambia
 * una constante de esta clase y NO se toca la logica del juego.
 */
public class Config
{
    // ------------------------------------------------------------------
    // Tamano del escenario
    // ------------------------------------------------------------------
    public static final int ANCHO = 960;
    public static final int ALTO  = 640;

    /** Linea del suelo de la arena. */
    public static final int SUELO = 408;

    /** Posiciones de combate. */
    public static final int X_JUGADOR = 255;
    public static final int X_ENEMIGO = 705;
    /**
     * Altura del centro del peleador: se calcula para que sus PIES queden
     * sobre la linea del suelo, sea cual sea el sprite que se cargue.
     */
    public static final int Y_PELEA   = SUELO - Recursos.ALTURA_PIES;

    // ------------------------------------------------------------------
    // Interruptores de los experimentos de laboratorio (seccion 26 de la guia)
    // ------------------------------------------------------------------
    /** Experimento A: en false se apagan indicador, pulso, halo y textos. */
    public static final boolean AYUDAS_VISUALES = true;

    /** Experimento D: en false se puede clicar durante ANIMANDO (inconsistencias). */
    public static final boolean VALIDAR_ESTADO = true;

    /** Experimento C: duracion de las animaciones en ciclos de act(). */
    public static final int CICLOS_FISICO   = 18;
    public static final int CICLOS_KI       = 34;
    public static final int CICLOS_GUARDIA  = 16;
    public static final int CICLOS_TRANSFOR = 46;

    // ------------------------------------------------------------------
    // Reglas de combate
    // ------------------------------------------------------------------
    /** Probabilidad de golpe critico (desafio de extension de la guia). */
    public static final int    PROB_CRITICO      = 10;
    public static final double MULT_CRITICO      = 2.0;
    /** La guardia reduce a la mitad el siguiente dano recibido. */
    public static final double REDUCCION_GUARDIA = 0.5;
    /** Ki con el que empieza cada peleador. */
    public static final int    KI_INICIAL        = 40;

    // ------------------------------------------------------------------
    // Paleta de la interfaz
    // ------------------------------------------------------------------
    public static final Color NARANJA   = new Color(255, 146, 30);
    public static final Color NARANJA_O = new Color(196,  92,  10);
    public static final Color AZUL_KI   = new Color( 90, 190, 255);
    public static final Color AZUL_O    = new Color( 20,  90, 170);
    public static final Color DORADO    = new Color(255, 214,  50);
    public static final Color ROJO      = new Color(230,  60,  50);
    public static final Color VERDE     = new Color( 70, 205,  90);
    public static final Color MORADO    = new Color(170,  90, 220);
    public static final Color GRIS      = new Color( 88,  92, 104);
    public static final Color NEGRO     = new Color( 22,  24,  32);
    public static final Color BLANCO    = new Color(245, 248, 255);

    /** Pequena utilidad: aclara un color un porcentaje dado. */
    public static Color aclarar(Color c, double factor)
    {
        int r = (int) Math.min(255, c.getRed()   + (255 - c.getRed())   * factor);
        int g = (int) Math.min(255, c.getGreen() + (255 - c.getGreen()) * factor);
        int b = (int) Math.min(255, c.getBlue()  + (255 - c.getBlue())  * factor);
        return new Color(r, g, b);
    }

    /** Pequena utilidad: oscurece un color un porcentaje dado. */
    public static Color oscurecer(Color c, double factor)
    {
        int r = (int) Math.max(0, c.getRed()   * (1 - factor));
        int g = (int) Math.max(0, c.getGreen() * (1 - factor));
        int b = (int) Math.max(0, c.getBlue()  * (1 - factor));
        return new Color(r, g, b);
    }

    /** El mismo color con transparencia. */
    public static Color conAlfa(Color c, int alfa)
    {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), alfa);
    }
}
