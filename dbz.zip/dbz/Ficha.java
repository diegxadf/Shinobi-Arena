import greenfoot.*;

/**
 * Datos de un peleador: quien es, cuanto aguanta y que sabe hacer.
 *
 * Driver atendido: MANTENIBILIDAD y MODULARIDAD.
 * El jugador y el enemigo se construyen con la MISMA estructura, asi que
 * cambiar de rival (o convertir a Vegeta en jugable) no exige clases nuevas.
 */
public class Ficha
{
    public final String  nombre;
    public final String  apodo;
    /** Prefijo de sus archivos en images/ (goku_idle.png, goku_ataque.png...). */
    public final String  prefijo;
    public final int     hpMaximo;
    public final int     kiMaximo;
    public final Estilo  estilo;
    public final AccionCombate[] acciones;

    /** Nombre que toma el peleador al transformarse (null si no se transforma). */
    public final String  nombreTransformado;
    /** Multiplicador de dano mientras esta transformado. */
    public final double  multiplicadorTransformacion;
    /** % de HP por debajo del cual la IA decide transformarse. */
    public final int     umbralTransformacion;
    /** Dificultad mostrada en el menu (1 a 3). */
    public final int     dificultad;

    public Ficha(String nombre, String apodo, String prefijo, int hpMaximo, int kiMaximo,
                 Estilo estilo, AccionCombate[] acciones, String nombreTransformado,
                 double multiplicadorTransformacion, int umbralTransformacion,
                 int dificultad)
    {
        this.nombre = nombre;
        this.apodo = apodo;
        this.prefijo = prefijo;
        this.hpMaximo = hpMaximo;
        this.kiMaximo = kiMaximo;
        this.estilo = estilo;
        this.acciones = acciones;
        this.nombreTransformado = nombreTransformado;
        this.multiplicadorTransformacion = multiplicadorTransformacion;
        this.umbralTransformacion = umbralTransformacion;
        this.dificultad = dificultad;
    }

    /** Devuelve la accion de transformacion de este peleador, o null. */
    public AccionCombate accionTransformacion()
    {
        for (AccionCombate a : acciones)
        {
            if (a.getTipo() == AccionCombate.Tipo.TRANSFORMACION) return a;
        }
        return null;
    }
}
