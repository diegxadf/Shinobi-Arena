# SAGA Z — combate por turnos (proyecto Greenfoot)

Juego de **combate por turnos estilo Dragon Ball** desarrollado sobre la guía
**"Juego de Combate por Turnos en Greenfoot — drivers arquitectónicos,
animaciones activas, HP y acciones con distintas tasas de acierto"**.

En lugar de los dos soldados de infantería medieval del enunciado, el combate es
**Goku contra Vegeta, Freezer o Cell**. La arquitectura es la misma que pide la
guía (gestor de estados, unidades con HP, acciones como objetos, animaciones
ligadas al estado); lo que cambia es el tema y las tres reglas que agregamos
encima: **ki**, **guardia** y **transformación**.

El juego usa **sprites de Dragon Ball** y **música y efectos de sonido propios**.
Si faltara algún archivo, `Recursos` y `Sonidos` recurren al dibujo por código de
`FabricaImagenes` y al silencio, así que el escenario abre igual.

---

## 1. Cómo abrirlo

1. Abrir Greenfoot 3.9.
2. `Scenario > Open...` y elegir la carpeta `dbz`.
3. Botón **Run**. Arranca el menú de selección de rival.
4. Hacer clic sobre el mundo antes de usar el teclado.

En `pruebas/` hay capturas de cómo se ve el menú, el combate y los cuatro
peleadores (`menu.png`, `combate.png`, `personajes.png`).

## 2. Controles

| Entrada | Acción |
|---|---|
| Clic sobre una técnica | Ejecutarla (solo si el botón está encendido) |
| Teclas **1** a **6** | Lo mismo, por teclado |
| Teclas **1** a **3** en el menú | Elegir rival |
| **R** | Volver al menú / revancha |
| **M** | Silenciar o reactivar el sonido |

## 3. El juego en 30 segundos

```
TU TURNO -> eliges técnica -> animación -> tirada de acierto -> daño -> HP -> turno del rival
```

Tres recursos se mueven a la vez:

- **HP**: cuando llega a 0, se acaba el combate.
- **KI**: los golpes cuerpo a cuerpo y la guardia lo **cargan**; las técnicas de
  energía lo **gastan**. Sin ki no hay Kamehameha.
- **Transformación**: cuesta 55 de ki, se usa **una sola vez** y multiplica por
  1.5 todo el daño posterior.

Gana quien deja al otro en 0 HP.

## 4. Técnicas de Goku y su esperanza de daño

`E[D] = P(acierto) × D` es la fórmula de la sección 4.1 de la guía, y aparece
escrita en cada botón dentro del juego.

| # | Técnica | Daño | Acierto | Ki | E[D] | Para qué sirve |
|---|---|---|---|---|---|---|
| 1 | Puño del Kame | 9 | 92% | +14 | **8.3** | Golpe seguro que carga ki |
| 2 | Patada ascendente | 14 | 78% | +10 | **10.9** | Equilibrada, 20% de aturdir |
| 3 | Ráfaga de Ki | 20 | 72% | −22 | **14.4** | Daño medio a distancia |
| 4 | Kamehameha | 36 | 55% | −48 | **19.8** | Mucho daño, mucho riesgo |
| 5 | Guardia y carga | — | — | +30 | — | Parte el próximo golpe a la mitad |
| 6 | Super Saiyajin | — | — | −55 | — | ×1.5 de daño para el resto del combate |

Ningún ataque domina a los demás: el de mayor daño nominal tiene la peor
precisión **y** exige un ki que solo se consigue peleando de cerca o
defendiendo. Elegir siempre el Kamehameha es una mala estrategia.

Los rivales tienen sus propias tablas en `Fichas.java`:

| Rival | HP | Se transforma en | Dificultad | Particularidad |
|---|---|---|---|---|
| Vegeta | 115 | Super Vegeta (×1.45) | ● | Resplandor Final: 34 de daño |
| Freezer | 135 | Freezer Final (×1.5) | ●● | Supernova: 38 de daño; su cola aturde |
| Cell | 145 | Cell Perfecto (×1.5) | ●●● | **Se regenera** 22 HP: hay que superar su curación |

## 5. Sprites y sonido

### 5.1 Sprites

Los personajes son sprites recortados de hojas de Dragon Ball (ver créditos al
final). Cada peleador usa estos archivos de `images/`:

| Archivo | Cuándo se usa |
|---|---|
| `<nombre>_idle.png` | quieto, esperando su turno |
| `<nombre>_ataque.png` | mientras ejecuta un golpe |
| `<nombre>_carga.png` | mientras acumula ki |
| `<nombre>_t_idle.png` | ya transformado |
| `<nombre>_t_ataque.png` | atacando transformado |

Solo `_idle` es obligatorio: `Recursos` va degradando (ataque → idle,
transformado → normal) y, si no encuentra nada, dibuja la figura por código.
Por eso agregar un peleador nuevo es dejar un `.png` en la carpeta, sin tocar
una línea de Java.

Todos los sprites se componen sobre un **lienzo del mismo tamaño alineado por
los pies** (`Recursos.sobreLienzo`). Así Goku (159 px), Vegeta (123 px) y Cell
Perfecto (186 px) pisan exactamente la misma línea de suelo y el gestor no
necesita saber cuánto mide cada uno. Los archivos miran todos a la derecha; el
espejo del enemigo lo hace `Recursos`, no el artista.

### 5.2 Sonido

La música y los efectos se **sintetizaron para este proyecto** (chiptune de
arcade, sin material con derechos). `Sonidos` controla dos cosas: una pista en
bucle por mundo y un efecto por animación.

| Momento | Sonido |
|---|---|
| Menú | `menu.wav` en bucle |
| Combate | `combate.wav` en bucle |
| Elegir técnica | `boton.wav` |
| Golpe cuerpo a cuerpo | `golpe.wav` |
| Acumular ki | `carga.wav` |
| Ráfaga / Kamehameha | `rafaga.wav` / `kamehameha.wav` |
| Impacto | `impacto.wav` |
| Crítico | `critico.wav` |
| Fallo | `fallo.wav` |
| Guardia | `guardia.wav` |
| Regeneración | `cura.wav` |
| Transformación | `transformacion.wav` |
| Victoria / derrota | `victoria.wav` / `derrota.wav` (la música se corta) |

El criterio es el mismo que la guía pide para las animaciones: **cada sonido
identifica un evento distinto del combate**. El turno del enemigo se puede
seguir de oído sin leer el cartel, porque un golpe, una carga de ki y un
bloqueo suenan diferente. Con **M** se silencia todo.

## 6. Mapa: paso de la guía → clase del proyecto

| Paso de la guía | Clase aquí | Cambios respecto del enunciado |
|---|---|---|
| Paso 1: crear el mundo | `JuegoTurnos` | 960×640 y fondo de arena dibujado por código |
| Paso 2: dibujar al personaje | `Recursos` + `FabricaImagenes` | Sprites de Dragon Ball, con respaldo dibujado por código |
| Paso 3: clase base `Unidad` | `Unidad` | Agrega ki, guardia, aturdimiento y transformación |
| Paso 4: los dos combatientes | `GuerreroJugador`, `GuerreroEnemigo` | Se construyen desde una `Ficha` |
| Paso 5: acción como objeto | `AccionCombate` | Agrega costo de ki, aturdimiento, curación y tipo |
| Paso 6: gestor y estados | `GestorCombate` | Misma máquina de 5 estados de la guía |
| Paso 7-8: botones | `BotonAccion` | Muestran daño, acierto, ki y E[D] |
| Paso 9: indicador de turno | `IndicadorTurno` | Late solo cuando el usuario puede actuar |
| Paso 10: seleccionar sin romper el turno | `GestorCombate.seleccionarAccion` | Igual que la guía |
| Paso 11: barra de HP | `BarraHP` | Color por tramos y estela roja del daño reciente |
| Paso 12: texto flotante | `TextoFlotante` | Distingue fallo, daño normal y crítico |
| Paso 13-18: máquina de estados y resolución | `GestorCombate` | Animación distinta según el tipo de acción |
| Paso 19: halo de objetivo | `IndicadorObjetivo` | Anillo pulsante detrás del rival |

Clases nuevas que no estaban en la guía: `Config`, `Estilo`, `Ficha`, `Fichas`,
`Recursos`, `BarraKi`, `Aura`, `OndaKi`, `Particula`, `Destello`, `Efecto`,
`Cartel`, `RegistroCombate`, `MenuWorld`, `BotonMenu`, `Sonidos`.

## 7. Drivers arquitectónicos

| Driver | Necesidad | Decisión de diseño | Dónde vive |
|---|---|---|---|
| Claridad del turno | Saber si puedo actuar o debo esperar | Estado explícito + cartel que late solo en mi turno | `GestorCombate.Estado`, `IndicadorTurno` |
| Comprensión de acciones | Distinguir riesgo y recompensa | Cada botón muestra daño, acierto, ki y E[D] | `BotonAccion`, `AccionCombate` |
| Feedback inmediato | Entender qué pasó después de elegir | Movimiento + proyectil + partículas + número + registro escrito | `animar()`, `TextoFlotante`, `RegistroCombate` |
| Prevención de errores | No actuar dos veces en un turno | Estado `ANIMANDO_*` y botones apagados | `seleccionarAccion()` |
| Consistencia | La interfaz debe reflejar el estado real | Barras y botones **leen** de `Unidad`, no guardan copias | `BarraHP`, `BarraKi` |
| Mantenibilidad | Agregar ataques debe ser simple | Un ataque nuevo es una línea en `Fichas` | `AccionCombate`, `Fichas` |
| Modularidad | Reglas, personajes e interfaz evolucionan aparte | Gestor / Unidad / FabricaImagenes separados | todo el proyecto |
| Balance | Un ataque más fuerte no debe ser siempre mejor | Trade-off daño ↔ acierto ↔ costo de ki | `Fichas`, `Config` |
| Portabilidad | Que abra en cualquier máquina | Sin archivos de imagen ni de sonido obligatorios | `FabricaImagenes`, `Sonidos` |

## 8. Concerns y tensiones

**7.1 Daño contra probabilidad.** Ver la tabla de la sección 4. La decisión no
es "cuál pega más" sino "cuál conviene con el ki y el HP que tengo ahora".

**7.2 Ayuda visual contra sobrecarga visual.** Cada animación responde una
pregunta concreta del usuario; si no responde ninguna, no está.

| Pregunta del usuario | Ayuda visual |
|---|---|
| ¿Es mi turno? | Cartel verde que late |
| ¿Qué puedo hacer? | Botones encendidos y latiendo |
| ¿Por qué ese botón está apagado? | Barra de ki + leyenda "KI INSUFICIENTE" |
| ¿A quién voy a atacar? | Halo amarillo detrás del rival |
| ¿Se ejecutó mi acción? | El personaje avanza o carga aura |
| ¿Acerté? | Texto de daño, "FALLO" o "CRÍTICO" |
| ¿Cuánta vida queda? | Barra de HP con color y estela |
| ¿Qué pasó exactamente? | Renglón de registro bajo la arena |

**7.3 Interactividad contra consistencia.** El estado `ANIMANDO` es la barrera:
mientras dura, `seleccionarAccion()` rechaza cualquier clic o tecla.

```
TURNO_JUGADOR -> ANIMANDO_JUGADOR -> TURNO_ENEMIGO -> ANIMANDO_ENEMIGO -> ...
                                                                  \-> FIN
```

Las reglas que agregamos (ki, crítico, guardia, aturdimiento, transformación)
**no agregaron estados nuevos**: el tipo de la acción elegida decide cómo se
anima y cómo se resuelve. Eso mantiene la máquina tan simple como en la guía.

## 9. Qué aporta cada animación

| Animación | Información que comunica | Concern |
|---|---|---|
| Cartel pulsante | Cuándo puede actuar el usuario | Visibility of system status |
| Botones pulsantes | Qué acciones son seleccionables | Affordance / error prevention |
| Botón apagado con ki rojo | Por qué **no** puede usarse | Comprensibilidad |
| Halo de objetivo | Dónde se aplicará la acción | Claridad |
| Avance del atacante | La acción fue aceptada | Feedback |
| Carga de aura y partículas | La técnica es cara y tarda | Anticipación |
| Rayo o esfera de ki | Dirección y tipo del ataque | Claridad |
| Texto de daño / FALLO / CRÍTICO | Resultado cuantitativo | Feedback |
| Destello de pantalla | Evento importante (crítico, transformación) | Jerarquía del feedback |
| Barra de HP con estela | Estado acumulado y cuánto se perdió recién | Observabilidad |
| Cambio de pose del sprite | Está golpeando / está cargando ki | Feedback |
| Efecto de sonido propio | Qué tipo de acción ocurrió, sin mirar | Feedback multicanal |

## 10. Experimentos de laboratorio

Todos se activan cambiando **una constante de `Config.java`** y volviendo a
compilar. No hay que tocar la lógica.

| Experimento | Qué cambiar | Qué se observa |
|---|---|---|
| **A — quitar ayudas visuales** | `AYUDAS_VISUALES = false` | El juego sigue siendo *funcional* pero se vuelve difícil de entender: no se sabe de quién es el turno ni cuánto daño se hizo. Funcionalidad ≠ usabilidad |
| **B — cambiar tasas de acierto** | Editar los números en `Fichas.java` | Si se sube el Kamehameha a 24/40% su E[D] baja a 9.6 y deja de convenir; si se lo sube a 24/70% domina a todo lo demás y el juego pierde decisión |
| **C — demasiada animación** | `CICLOS_FISICO` y `CICLOS_KI` de 18/34 a 40/80 | El feedback se vuelve claro pero el combate se hace lento: tensión claridad visual ↔ velocidad de interacción |
| **D — permitir acciones durante ANIMANDO** | `VALIDAR_ESTADO = false` | Haciendo varios clics se encadenan acciones en el mismo turno, se gasta ki de más y el HP baja varias veces seguidas: exactamente la inconsistencia que el estado `ANIMANDO` evita |

## 11. Actividad de razonamiento arquitectónico

| Driver / Concern | Problema | Decisión | Elemento de código |
|---|---|---|---|
| Claridad de turno | El usuario no sabe si puede actuar | Estado explícito + indicador que late solo en su turno | `Estado`, `IndicadorTurno.mostrar(..., latir)` |
| Feedback | No se entiende qué produjo el cambio de HP | Cadena movimiento → impacto → número → registro escrito | `animar()`, `resolver()`, `RegistroCombate` |
| Prevención de errores | Dos acciones en el mismo turno | Guardia de estado en la selección + botones apagados | `seleccionarAccion()`, `actualizarBotones()` |
| Mantenibilidad | Agregar técnicas obliga a tocar todo | Acción como objeto con fábricas estáticas | `AccionCombate.fisico/ki/especial/...` |
| Balance | El ataque más fuerte sería siempre el mejor | Trade-off daño/acierto + costo de ki + E[D] visible | `Fichas`, `AccionCombate.esperanzaDanio()` |
| Consistencia | La interfaz podría mostrar datos viejos | La interfaz no guarda estado: siempre lee de `Unidad` | `BarraHP.actualizar()`, `BarraKi.actualizar()` |

## 12. Desafíos de extensión de la guía

| Desafío | Estado | Dónde |
|---|---|---|
| **Defender**: reducir 50% el siguiente daño | Implementado | `Unidad.defendiendo`, técnica "Guardia y carga". El estado vive en la `Unidad` (no en el gestor) porque es una propiedad del peleador, y se consume con el primer golpe recibido |
| **Ataque crítico**: P=10%, daño ×2 | Implementado | `AccionCombate.esCritico()`, `Config.PROB_CRITICO`, con destello y texto propios |
| **Estados temporales** | Implementado | Aturdimiento (`Unidad.aturdir`, la Patada ascendente y la cola de Freezer lo aplican), guardia y transformación |
| **Combate 2 vs 2** | No implementado | Preparado: `IndicadorObjetivo` ya es un actor independiente que apunta a una `Unidad`, que es lo que haría falta para convertir el halo en mecanismo de selección |

## 13. Balance medido

El proyecto se probó con un simulador que juega combates completos usando la
misma lógica del juego (elige la mejor E[D] que puede pagar). Se corrieron
**tres tandas de 450 combates** (1350 en total):

| Rival | Victorias del jugador | Rango entre tandas | Turnos por combate |
|---|---|---|---|
| Vegeta | 76.7% | 72.7 – 80.7 | 9.0 |
| Freezer | 68.2% | 66.7 – 70.0 | 10.4 |
| Cell | 56.5% | 52.0 – 60.7 | 12.6 |

El rango importa: con 150 combates por rival el azar mueve cada cifra hasta
ocho puntos, así que una sola tanda no alcanza para afirmar que el balance es
el correcto. Lo que sí se sostiene en las tres es el **orden de dificultad**:
Vegeta es el rival de entrada, Freezer pega más fuerte y Cell es el combate
más largo porque se regenera.

Además, en esas tres tandas (se repitieron después de agregar sprites y sonido,
porque ninguno de los dos toca las reglas):

- **0** acciones aceptadas fuera de `TURNO_JUGADOR` (la barrera de consistencia
  funciona incluso forzando la selección en cada ciclo de animación);
- **0** casos de HP negativo o de ki fuera del rango `[0, máximo]`;
- **0** combates sin terminar.

## 14. Estructura de clases

```
MenuWorld ── BotonMenu
JuegoTurnos
  └── GestorCombate            reglas, turnos y resolución
        ├── Unidad (abstracta) HP, ki, guardia, aturdimiento, transformación
        │     ├── GuerreroJugador
        │     └── GuerreroEnemigo   IA por prioridades
        ├── AccionCombate      daño, acierto, costo de ki, tipo
        ├── BotonAccion        selección e información de riesgo
        ├── IndicadorTurno     estado del combate
        ├── IndicadorObjetivo  halo sobre el objetivo
        ├── BarraHP / BarraKi  estado acumulado
        ├── RegistroCombate    narración de lo que ocurrió
        └── efectos: Aura · OndaKi · Particula · Destello · TextoFlotante · Cartel

Datos:    Ficha · Fichas · Estilo · Config
Gráficos: Recursos (sprites) · FabricaImagenes (respaldo dibujado)
Audio:    Sonidos
```

## 15. Conclusión

La cadena de razonamiento de la guía se mantiene intacta:

```
Driver -> Concern -> Estado -> Interacción -> Feedback
```

- Claridad del turno → indicador animado
- Prevención de errores → deshabilitar acciones durante la animación
- Comprensión del riesgo → mostrar daño, acierto y E[D] en el botón
- Comprensión del recurso → barra de ki que explica por qué un botón está apagado
- Feedback → movimiento + proyectil + texto de daño + barra + registro escrito

**Animación ≠ decoración.** El aura no está porque quede bonita: está porque
dice "este peleador está cargando energía" y "este peleador está transformado".
Cuando una animación está atada al estado del sistema, orienta, informa, previene
errores y reduce la incertidumbre del usuario; por eso las ayudas visuales se
diseñaron junto con las reglas del combate y no después.

---

## 16. Créditos de los recursos

**Sprites.** Recortados de hojas de sprites de fans de Dragon Ball, usados aquí
con fines educativos para un trabajo de clase:

- Goku y los efectos de energía: hoja *Ultimate LSW* — sprites de qsab101,
  omegasuper, xbae12, tougarashi635, kaval2003, mrruben7; bases ULSW de bite035,
  dyandisel y derkanimations; hoja armada por 2ruffles.
- Vegeta, Freezer y Cell: *Sprite Collection* de **Que** (Ultimate LSW), que pide
  expresamente que se lo acredite si se usan sus sprites.

Dragon Ball y sus personajes son propiedad de Akira Toriyama, Shueisha y Toei
Animation. Este proyecto es un trabajo académico sin fin comercial.

**Música y efectos de sonido.** Compuestos y sintetizados para este proyecto
(ondas cuadradas, triangulares y ruido, estilo chiptune de arcade). No contienen
material con derechos de autor.
