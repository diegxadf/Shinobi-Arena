import greenfoot.*;

/**
 * Fogonazo que cubre la pantalla al transformarse o al recibir un critico.
 *
 * Concern atendido: JERARQUIA DEL FEEDBACK.
 * No todos los eventos valen lo mismo. Un golpe normal se comunica con un
 * texto; un cambio de estado grande (transformacion, critico, final del
 * combate) merece un evento visual que no se pueda pasar por alto.
 */
public class Destello extends Actor
{
    private int vida;
    private final int vidaTotal;
    private final Color color;

    public Destello(Color color, int vida)
    {
        this.color = color;
        this.vida = vida;
        this.vidaTotal = vida;
        pintar();
    }

    public void act()
    {
        vida--;
        if (vida <= 0)
        {
            getWorld().removeObject(this);
            return;
        }
        pintar();
    }

    private void pintar()
    {
        GreenfootImage img = new GreenfootImage(Config.ANCHO, Config.ALTO);
        img.setColor(color);
        img.fill();
        img.setTransparency((int) (190.0 * vida / vidaTotal));
        setImage(img);
    }
}
