import greenfoot.*;

/**
 * Proyectil de energia: esfera que viaja o rayo tipo Kamehameha.
 *
 * Concern atendido: FEEDBACK y CLARIDAD DEL OBJETIVO.
 * El proyectil viaja del atacante al objetivo, asi que la direccion del ataque
 * se ve. Es puramente visual: el dano NO lo decide este actor sino el gestor,
 * de modo que las reglas del combate no dependen de la animacion.
 */
public class OndaKi extends Actor
{
    private final Color color;
    private final boolean esRayo;
    private final int direccion;
    private final int largoFinal;
    private final int velocidad;

    private int fase = 0;
    private int vida;

    /** Esfera que vuela hacia el rival. */
    public OndaKi(Color color, int direccion, int tam, int velocidad, int vida)
    {
        this.color = color;
        this.esRayo = false;
        this.direccion = direccion;
        this.velocidad = velocidad;
        this.largoFinal = tam;
        this.vida = vida;
        setImage(FabricaImagenes.esferaKi(color, tam, 0));
    }

    /** Rayo que se estira desde el atacante hasta el objetivo. */
    public static OndaKi rayo(Color color, int direccion, int largo, int vida)
    {
        return new OndaKi(color, direccion, largo, vida);
    }

    private OndaKi(Color color, int direccion, int largo, int vida)
    {
        this.color = color;
        this.esRayo = true;
        this.direccion = direccion;
        this.velocidad = 0;
        this.largoFinal = largo;
        this.vida = vida;
        setImage(new GreenfootImage(1, 1));
    }

    /** Posicion fija del extremo del rayo (donde nace, junto al atacante). */
    private int xOrigen = -1;

    protected void addedToWorld(World mundo)
    {
        xOrigen = getX();
    }

    public void act()
    {
        fase++;
        vida--;

        if (esRayo)
        {
            // Crece los primeros ciclos y luego se mantiene y se apaga.
            double p = Math.min(1.0, fase / 8.0);
            int largo = Math.max(4, (int) (largoFinal * p));
            GreenfootImage img = imagenRayo(largo);
            if (vida < 8) img.setTransparency(Math.max(0, vida * 30));
            setImage(img);
            setLocation(xOrigen + direccion * largo / 2, getY());
        }
        else
        {
            setLocation(getX() + direccion * velocidad, getY());
            setImage(imagenEsfera());
            if (getWorld() != null)
            {
                Particula.carga(getWorld(), getX(), getY() - 60, color);
            }
        }

        if (vida <= 0 && getWorld() != null)
        {
            getWorld().removeObject(this);
        }
    }

    /**
     * El rayo usa el sprite kamehameha.png si esta disponible, recortado al
     * largo que lleva la animacion; si no, se dibuja por codigo.
     */
    private GreenfootImage imagenRayo(int largo)
    {
        GreenfootImage sprite = Recursos.cargar("kamehameha.png");
        if (sprite == null) return FabricaImagenes.rayoKi(color, largo, 26, fase);

        int alto = sprite.getHeight();
        GreenfootImage img = new GreenfootImage(largo, alto);
        // Se dibuja desde la punta: el frente del rayo es el que avanza.
        int desplazamiento = direccion > 0 ? largo - sprite.getWidth() : 0;
        img.drawImage(sprite, desplazamiento, 0);
        if (direccion < 0) img.mirrorHorizontally();
        return img;
    }

    private GreenfootImage imagenEsfera()
    {
        GreenfootImage sprite = Recursos.cargar("esfera_ki.png");
        if (sprite == null) return FabricaImagenes.esferaKi(color, largoFinal, fase);
        GreenfootImage img = new GreenfootImage(sprite);
        if (fase % 6 < 3) img.setTransparency(225);
        return img;
    }
}
