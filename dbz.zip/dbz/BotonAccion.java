import greenfoot.*;

/**
 * Pasos 7 y 8 de la guia, ampliados.
 *
 * Concerns atendidos: AFFORDANCE, ERROR PREVENTION y COMPRENSION DEL RIESGO.
 * Cada boton dice su dano, su probabilidad de acierto y lo que cuesta de ki,
 * asi que la decision se toma con informacion y no a ciegas. El boton late
 * SOLO cuando se puede pulsar: la pulsacion no es decoracion, es el mensaje
 * "esta accion esta disponible ahora".
 *
 * Tres aspectos distintos, tres significados distintos:
 *   - latiendo y con color -> disponible;
 *   - apagado en gris      -> no es tu turno;
 *   - apagado con KI rojo  -> es tu turno pero no te alcanza el ki.
 */
public class BotonAccion extends Actor
{
    public static final int ANCHO = 288;
    public static final int ALTO  = 72;

    private final AccionCombate accion;
    private final GestorCombate gestor;
    private final int numeroTecla;

    private boolean habilitado = true;
    private boolean pagable    = true;
    private boolean disponible = true;   // false si ya se uso (transformacion)
    private int pulso = 0;

    public BotonAccion(AccionCombate accion, GestorCombate gestor, int numeroTecla)
    {
        this.accion = accion;
        this.gestor = gestor;
        this.numeroTecla = numeroTecla;
        actualizarImagen();
    }

    public void act()
    {
        if (habilitado && Config.AYUDAS_VISUALES)
        {
            pulso = (pulso + 1) % 24;
            if (pulso % 4 == 0) actualizarImagen();
        }
        if ((habilitado || !Config.VALIDAR_ESTADO) && Greenfoot.mouseClicked(this))
        {
            gestor.seleccionarAccion(accion);
        }
    }

    /**
     * @param turnoDelJugador estado == TURNO_JUGADOR
     * @param pagable         el jugador tiene ki suficiente
     * @param disponible      la accion todavia se puede usar
     */
    public void setEstado(boolean turnoDelJugador, boolean pagable, boolean disponible)
    {
        this.pagable = pagable;
        this.disponible = disponible;
        boolean nuevo = turnoDelJugador && pagable && disponible;
        if (nuevo != habilitado) pulso = 0;
        this.habilitado = nuevo;
        actualizarImagen();
    }

    public AccionCombate getAccion() { return accion; }
    public boolean estaHabilitado()  { return habilitado; }

    private void actualizarImagen()
    {
        Color acento = habilitado ? accion.getColor() : Config.GRIS;
        Color borde  = acento;
        if (habilitado && Config.AYUDAS_VISUALES && pulso >= 12)
        {
            borde = Config.aclarar(acento, 0.55);
        }

        GreenfootImage img = FabricaImagenes.panel(ANCHO, ALTO, 12,
                                 new Color(24, 26, 38, 235), borde, 3);

        // Franja de color de la accion.
        FabricaImagenes.redondeado(img, 10, 12, 8, ALTO - 24, 4, acento);

        // Atajo de teclado.
        FabricaImagenes.redondeado(img, 24, 12, 24, 24, 6,
                                   Config.conAlfa(acento, habilitado ? 190 : 90));
        FabricaImagenes.textoCentrado(img, String.valueOf(numeroTecla), 15,
                                      habilitado ? Config.NEGRO : new Color(210, 210, 220),
                                      36, 12);

        // Nombre.
        Color colorTexto = habilitado ? Config.BLANCO : new Color(170, 174, 188);
        img.drawImage(FabricaImagenes.texto(accion.getNombre(), 19, colorTexto), 56, 8);

        // Linea de datos: dano, acierto y ki.
        Color colorDatos = new Color(196, 202, 218);
        if (!pagable)      colorDatos = new Color(255, 120, 110);
        if (!disponible)   colorDatos = new Color(140, 144, 158);
        String linea = accion.descripcionCorta();
        if (!disponible)    linea = "YA UTILIZADA";
        else if (!pagable)  linea = "KI INSUFICIENTE  -  necesitas " + accion.getCostoKi();
        img.drawImage(FabricaImagenes.texto(linea, 14, colorDatos), 56, 38);

        // Cinta con la esperanza de dano E[D], la formula de la seccion 4.1.
        if (accion.esOfensiva() && Config.AYUDAS_VISUALES)
        {
            String ed = String.format("E[D] %.1f", accion.esperanzaDanio());
            GreenfootImage t = FabricaImagenes.texto(ed, 12,
                                   habilitado ? new Color(230, 235, 250) : new Color(150, 154, 168));
            int x = ANCHO - 12 - t.getWidth();
            FabricaImagenes.redondeado(img, x - 6, 10, t.getWidth() + 12, 18, 9,
                                       Config.conAlfa(acento, habilitado ? 70 : 40));
            img.drawImage(t, x, 9);
        }

        if (!habilitado) img.setTransparency(175);
        setImage(img);
    }
}
