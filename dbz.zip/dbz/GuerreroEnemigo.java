import greenfoot.*;

/**
 * Paso 4 de la guia (lado de la maquina) + Paso 16 mejorado.
 *
 * La guia original elegia la accion enemiga con un random puro. Aqui la IA
 * razona con las mismas reglas que se le piden al jugador:
 *
 *   1. se transforma cuando esta contra las cuerdas o cuando tiene el ki lleno;
 *   2. remata si un golpe alcanza para ganar;
 *   3. se cura o se defiende si esta herido y sin ki;
 *   4. si no, elige la mejor ESPERANZA de dano E[D] = P(acierto) * D
 *      entre las acciones que puede pagar, con algo de azar para no ser
 *      predecible.
 *
 * Driver atendido: BALANCE. Si el enemigo eligiera siempre su ataque mas
 * fuerte, la tension "dano contra probabilidad" de la seccion 4.1 se perderia.
 */
public class GuerreroEnemigo extends Unidad
{
    public GuerreroEnemigo(Ficha ficha)
    {
        super(ficha, false);   // mira hacia la izquierda, donde esta el jugador
    }

    public AccionCombate elegirAccion(Unidad rival)
    {
        AccionCombate[] acciones = getAcciones();

        // ---- 1. transformacion ----
        AccionCombate transformacion = getFicha().accionTransformacion();
        if (transformacion != null && puedeTransformarse() && puedePagar(transformacion)
            && (proporcionVida() * 100 <= getFicha().umbralTransformacion
                || proporcionKi() >= 0.95))
        {
            return transformacion;
        }

        // ---- 2. remate ----
        AccionCombate remate = null;
        for (AccionCombate a : acciones)
        {
            if (!a.esOfensiva() || !puedePagar(a)) continue;
            if (a.getDanio() * multiplicadorDanio() < rival.getHP()) continue;
            if (remate == null
                || a.getProbabilidadAcierto() > remate.getProbabilidadAcierto())
            {
                remate = a;
            }
        }
        if (remate != null && Greenfoot.getRandomNumber(100) < 85) return remate;

        // ---- 3. curacion ----
        if (proporcionVida() < 0.45)
        {
            for (AccionCombate a : acciones)
            {
                if (a.getTipo() == AccionCombate.Tipo.CURA && puedePagar(a)
                    && Greenfoot.getRandomNumber(100) < 70)
                {
                    return a;
                }
            }
        }

        // ---- 4. guardia defensiva ----
        if (proporcionVida() < 0.4 && proporcionKi() < 0.45
            && Greenfoot.getRandomNumber(100) < 45)
        {
            for (AccionCombate a : acciones)
            {
                if (a.getTipo() == AccionCombate.Tipo.GUARDIA) return a;
            }
        }

        // ---- 5. mejor esperanza de dano, con ruido ----
        AccionCombate mejor = null;
        double mejorValor = -1;
        for (AccionCombate a : acciones)
        {
            if (!a.esOfensiva() || !puedePagar(a)) continue;
            double valor = a.esperanzaDanio();
            // Si el ki esta bajo, los golpes que lo cargan valen mas.
            if (proporcionKi() < 0.35) valor += a.getGananciaKi() * 0.45;
            valor += Greenfoot.getRandomNumber(5);   // ruido: no ser predecible
            if (valor > mejorValor) { mejorValor = valor; mejor = a; }
        }

        // Siempre hay al menos un ataque fisico de costo cero.
        return mejor != null ? mejor : acciones[0];
    }
}
