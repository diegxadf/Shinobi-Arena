import greenfoot.*;

/**
 * Cartel grande de VICTORIA o DERROTA.
 *
 * Concern atendido: CIERRE. El estado FIN tiene que leerse sin ambiguedad y
 * decir ademas COMO se sigue (volver a pelear o volver al menu).
 */
public class Cartel extends Actor
{
    private final String titulo;
    private final String pie;
    private final Color  color;
    private int fase = 0;

    public Cartel(String titulo, String pie, Color color)
    {
        this.titulo = titulo;
        this.pie = pie;
        this.color = color;
        pintar();
    }

    public void act()
    {
        fase++;
        if (fase % 4 == 0) pintar();
    }

    private void pintar()
    {
        GreenfootImage t = FabricaImagenes.texto(titulo, 56, color);
        GreenfootImage p = FabricaImagenes.texto(pie, 18, Config.BLANCO);
        int ancho = Math.max(t.getWidth(), p.getWidth()) + 90;
        int alto  = t.getHeight() + p.getHeight() + 34;

        Color borde = (fase % 24 < 12) ? color : Config.aclarar(color, 0.5);
        GreenfootImage img = FabricaImagenes.panel(ancho, alto, 18,
                                 new Color(12, 14, 22, 235), borde, 4);
        img.drawImage(t, (ancho - t.getWidth()) / 2, 12);
        img.drawImage(p, (ancho - p.getWidth()) / 2, 16 + t.getHeight());
        setImage(img);
    }
}
