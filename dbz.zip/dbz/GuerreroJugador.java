import greenfoot.*;

/**
 * Paso 4 de la guia (lado del usuario): el peleador que controla la persona.
 *
 * No decide nada por su cuenta; solo existe y se deja mirar. Las decisiones
 * llegan desde BotonAccion -> GestorCombate, que es quien valida el turno.
 */
public class GuerreroJugador extends Unidad
{
    public GuerreroJugador(Ficha ficha)
    {
        super(ficha, true);   // mira hacia la derecha, donde esta el rival
    }
}
