import greenfoot.*;

/**
 * Paso 12 de la guia: el numero que sube desde el golpeado.
 *
 * Concern atendido: FEEDBACK COMPRENSIBLE.
 * La barra de HP dice el estado acumulado; este texto dice QUE acaba de pasar.
 * Un critico se dibuja mas grande y con borde para que se note que no fue un
 * golpe cualquiera.
 */
public class TextoFlotante extends Actor
{
    private int vida;
    private final int vidaTotal;
    private final GreenfootImage base;

    public TextoFlotante(String texto, Color color, int tam)
    {
        this(texto, color, tam, 50);
    }

    public TextoFlotante(String texto, Color color, int tam, int vida)
    {
        this.vida = vida;
        this.vidaTotal = vida;

        GreenfootImage t = FabricaImagenes.texto(texto, tam, color);
        base = new GreenfootImage(t.getWidth() + 18, t.getHeight() + 10);
        FabricaImagenes.redondeado(base, 0, 0, base.getWidth(), base.getHeight(), 9,
                                   new Color(12, 14, 20, 170));
        base.drawImage(t, 9, 5);
        setImage(new GreenfootImage(base));
    }

    public void act()
    {
        if (!Config.AYUDAS_VISUALES) { getWorld().removeObject(this); return; }

        setLocation(getX(), getY() - 1);
        vida--;
        if (vida <= 0)
        {
            getWorld().removeObject(this);
            return;
        }
        if (vida < vidaTotal / 2)
        {
            GreenfootImage img = new GreenfootImage(base);
            img.setTransparency((int) (255.0 * vida / (vidaTotal / 2.0)));
            setImage(img);
        }
    }
}
