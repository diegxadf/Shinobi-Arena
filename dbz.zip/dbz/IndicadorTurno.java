import greenfoot.*;

/**
 * Paso 9 de la guia: el cartel que responde "¿es mi turno?".
 *
 * Concern atendido: VISIBILITY OF SYSTEM STATUS.
 * El cartel late solo cuando el jugador PUEDE actuar. Si esta quieto, el juego
 * esta ocupado resolviendo algo y hay que esperar. El color refuerza el mismo
 * mensaje: verde = te toca, amarillo = animando, rojo = turno enemigo.
 */
public class IndicadorTurno extends Actor
{
    private String texto = "";
    private Color  color = Config.BLANCO;
    private boolean latir = false;
    private int pulso = 0;

    public IndicadorTurno()
    {
        actualizar();
    }

    public void act()
    {
        if (!latir || !Config.AYUDAS_VISUALES) return;
        pulso = (pulso + 1) % 24;
        if (pulso % 3 == 0) actualizar();
    }

    /** @param latir true solo cuando el usuario puede actuar. */
    public void mostrar(String texto, Color color, boolean latir)
    {
        this.texto = texto;
        this.color = color;
        this.latir = latir;
        actualizar();
    }

    private void actualizar()
    {
        if (!Config.AYUDAS_VISUALES)
        {
            setImage(new GreenfootImage(1, 1));   // Experimento A
            return;
        }

        GreenfootImage t = FabricaImagenes.texto(texto, 22, Config.BLANCO);
        int ancho = t.getWidth() + 52;
        int alto  = 40;

        Color borde = (latir && pulso >= 12) ? Config.aclarar(color, 0.5) : color;
        GreenfootImage img = FabricaImagenes.panel(ancho, alto, 14,
                                 new Color(18, 20, 28, 230), borde, 3);

        // Punto de estado a la izquierda del texto.
        img.setColor(color);
        img.fillOval(16, alto / 2 - 7, 14, 14);
        if (latir && pulso >= 12)
        {
            img.setColor(Config.conAlfa(color, 120));
            img.fillOval(11, alto / 2 - 12, 24, 24);
        }

        img.drawImage(t, 38, (alto - t.getHeight()) / 2);
        setImage(img);
    }
}
