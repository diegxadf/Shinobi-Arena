import greenfoot.*;

/**
 * Aura de ki que rodea a un peleador.
 *
 * Concern atendido: VISIBILITY OF SYSTEM STATUS aplicado al PERSONAJE.
 * El aura no es adorno: su presencia significa "este peleador esta
 * transformado" y su llamarada significa "esta cargando energia ahora mismo".
 * Se enciende y se apaga de forma gradual para que el ojo siga el cambio.
 */
public class Aura extends Actor
{
    private final Unidad duenio;
    private double intensidad = 0;
    private int llamarada = 0;
    private int fase = 0;

    public Aura(Unidad duenio)
    {
        this.duenio = duenio;
        setImage(new GreenfootImage(1, 1));
    }

    public void act()
    {
        setLocation(duenio.getX(), duenio.getY() + 6);
        fase++;

        // Si el sprite transformado ya trae su propia aura dibujada, esta aura
        // solo aparece al cargar energia: dos auras superpuestas ensucian.
        double base = (duenio.estaTransformada() && !duenio.auraEnSprite()) ? 0.55 : 0.0;
        double objetivo = base;
        if (llamarada > 0) { objetivo = duenio.auraEnSprite() ? 0.75 : 1.0; llamarada--; }
        intensidad += (objetivo - intensidad) * 0.16;

        if (!Config.AYUDAS_VISUALES && !duenio.estaTransformada())
        {
            setImage(new GreenfootImage(1, 1));
            return;
        }

        if (intensidad < 0.04)
        {
            setImage(new GreenfootImage(1, 1));
            return;
        }

        if (fase % 2 == 1) return;   // redibujar cada dos ciclos alcanza

        int ancho = (int) (230 * (0.82 + 0.35 * intensidad));
        int alto  = (int) (300 * (0.82 + 0.35 * intensidad));
        GreenfootImage img = FabricaImagenes.aura(duenio.getColorAura(), fase, ancho, alto);
        img.setTransparency((int) (110 + 145 * Math.min(1.0, intensidad)));
        setImage(img);
    }

    /** Enciende el aura al maximo durante unos ciclos (carga de ki). */
    public void encender(int ciclos)
    {
        llamarada = Math.max(llamarada, ciclos);
    }
}
