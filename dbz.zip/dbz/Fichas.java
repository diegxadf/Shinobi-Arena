import greenfoot.*;

/**
 * Tabla de balance del juego: aqui viven TODOS los numeros de los peleadores.
 *
 * Driver atendido: BALANCE (seccion 4.1 de la guia).
 * El Experimento B ("cambiar las tasas de acierto y recalcular E[D]") se hace
 * editando este archivo y nada mas.
 *
 *   Accion            Dano  Acierto  E[D] = P * D   Costo KI
 *   Puno del Kame        9     92%       8.3          0  (+14 KI)
 *   Patada ascendente   14     78%      10.9          0  (+10 KI, 20% aturde)
 *   Rafaga de Ki        20     72%      14.4         22
 *   Kamehameha          36     55%      19.8         48
 *
 * Ninguna accion domina a las demas: la mas fuerte tiene la peor precision Y
 * exige ki que solo se consigue peleando cuerpo a cuerpo o defendiendo.
 */
public class Fichas
{
    // ------------------------------------------------------------------
    // JUGADOR
    // ------------------------------------------------------------------
    public static Ficha goku()
    {
        AccionCombate[] acciones = {
            AccionCombate.fisico("Puno del Kame",     9, 92, 14,  0, Config.NARANJA),
            AccionCombate.fisico("Patada ascendente",14, 78, 10, 20, Config.NARANJA),
            AccionCombate.ki    ("Rafaga de Ki",     20, 72, 22,     Config.AZUL_KI),
            AccionCombate.especial("Kamehameha",     36, 55, 48,     new Color(120, 210, 255)),
            AccionCombate.guardia("Guardia y carga", 30,               Config.VERDE),
            AccionCombate.transformacion("Super Saiyajin", 55,         Config.DORADO)
        };
        return new Ficha("Goku", "el saiyajin criado en la Tierra", "goku",
                         120, 100, Estilo.goku(), acciones,
                         "Goku SSJ", 1.5, 0, 0);
    }

    // ------------------------------------------------------------------
    // RIVALES
    // ------------------------------------------------------------------

    /** Rival 1: equilibrado, pega fuerte pero tiene poca vida. */
    public static Ficha vegeta()
    {
        AccionCombate[] acciones = {
            AccionCombate.fisico("Golpe orgulloso",  10, 88, 14,  0, new Color(90, 130, 220)),
            AccionCombate.fisico("Rodillazo",        15, 76, 10, 15, new Color(90, 130, 220)),
            AccionCombate.ki    ("Galick-Ho",        19, 74, 22,     Config.MORADO),
            AccionCombate.especial("Resplandor Final",34, 55, 46,    new Color(255, 240, 120)),
            AccionCombate.guardia("Guardia saiyajin",28,             Config.VERDE),
            AccionCombate.transformacion("Super Vegeta", 52,         Config.DORADO)
        };
        return new Ficha("Vegeta", "el principe de los saiyajin", "vegeta",
                         115, 100, Estilo.vegeta(), acciones,
                         "Super Vegeta", 1.45, 45, 1);
    }

    /** Rival 2: mucha vida y un especial demoledor. */
    public static Ficha freezer()
    {
        AccionCombate[] acciones = {
            AccionCombate.fisico("Cola latigo",       9, 92, 14, 18, Config.MORADO),
            AccionCombate.fisico("Codazo helado",    13, 80, 10,  0, Config.MORADO),
            AccionCombate.ki    ("Rayo de la muerte",18, 76, 20,     new Color(255, 120, 180)),
            AccionCombate.especial("Supernova",      38, 50, 52,     new Color(255, 150,  60)),
            AccionCombate.guardia("Barrera",         26,             Config.VERDE),
            AccionCombate.transformacion("Forma Final", 50,          new Color(220, 150, 255))
        };
        return new Ficha("Freezer", "el emperador del universo", "freezer",
                         135, 100, Estilo.freezer(), acciones,
                         "Freezer Final", 1.5, 50, 2);
    }

    /** Rival 3: se regenera, asi que hay que superar su curacion. */
    public static Ficha cell()
    {
        AccionCombate[] acciones = {
            AccionCombate.fisico("Golpe bio",        11, 86, 12,  0, new Color(120, 200, 110)),
            AccionCombate.ki    ("Kamehameha bio",   20, 70, 24,     new Color(140, 255, 160)),
            AccionCombate.especial("Kamehameha solar",35, 55, 48,    new Color(200, 255, 120)),
            AccionCombate.cura  ("Regeneracion",     22, 30,         Config.VERDE),
            AccionCombate.guardia("Caparazon",       24,             Config.VERDE),
            AccionCombate.transformacion("Cell Perfecto", 54,        new Color(255, 230, 120))
        };
        return new Ficha("Cell", "el androide biologico", "cell",
                         145, 100, Estilo.cell(), acciones,
                         "Cell Perfecto", 1.5, 45, 3);
    }

    /** Los rivales en el orden en que aparecen en el menu. */
    public static Ficha[] rivales()
    {
        return new Ficha[] { vegeta(), freezer(), cell() };
    }
}
